function updateCanvasSize(){
    document.getElementById('canvas').width = window.innerWidth - document.getElementById('right-sidebar').offsetWidth - 400 - 26;
    document.getElementById('canvas').height = window.innerHeight - 100;
    
    canvas.width = window.innerWidth - document.getElementById('right-sidebar').offsetWidth - 400 - 26;
    canvas.height = window.innerHeight - 100;
    
}

function resetFormInputs() {
    $('#wing-opening-mode').parent().parent().hide(150);
    $('#wing-opening-side').parent().parent().hide(150);
    $('#wing-frame-type').parent().parent().hide(150);
    $('#wing-hinge').parent().parent().hide(150);
    $('#wing-fittings').parent().parent().hide(150);
    $('#wing-handle').parent().parent().hide(150);
    $('#divider-position').parent().parent().hide(150);
    $('#wing-divider-position').parent().parent().hide(150);
    $('#kfny-divider-position').parent().parent().hide(150);
    $('#glass-type').parent().parent().hide(150);
    $('#glass-width').parent().parent().hide(150);
    $('#glass-frame').parent().parent().hide(150);
    $('#frame-type').parent().parent().hide(150);

    $('#wing-title').hide(150);
    $('#glass-title').hide(150);
}

function updateHistoryButtons(historyLength, historyIndex) {
    if (historyIndex > 0) {
        $('#back-in-history-button').prop('disabled', false);
    } else {
        $('#back-in-history-button').prop('disabled', true);
    }

    if (historyIndex == historyLength - 1) {
        $('#forward-in-history-button').prop('disabled', true);
    } else {
        $('#forward-in-history-button').prop('disabled', false);
    }
}

function updateDoorwindowInputs(currentWidth, currentHeight, minimumWidth, minimumHeight) {
    $('#doorwindow-width').val(currentWidth / 100);
    $('#doorwindow-height').val(currentHeight / 100);

    $('#doorwindow-width').attr('old-value', currentWidth / 100);
    $('#doorwindow-height').attr('old-value', currentHeight / 100);

    $('#doorwindow-width').attr('minimum-value', minimumWidth / 100);
    $('#doorwindow-height').attr('minimum-value', minimumHeight / 100);
}

function updateDividerInput(currentPosition, minimumPosition, maximumPosition) {
    $('#divider-position').val(currentPosition / 100);
    $('#divider-position').attr('data-old-position', currentPosition);
    $('#divider-position').attr('data-minimum-position', minimumPosition);
    $('#divider-position').attr('data-maximum-position', maximumPosition);

    // update input form visibility
    $('#divider-position').parent().parent().show(150);
    
    $('#wing-opening-mode').parent().parent().hide(150);
    $('#wing-opening-side').parent().parent().hide(150);
    $('#kfny-divider-position').parent().parent().hide(150);
    $('#glass-type').parent().parent().hide(150);
    $('#glass-width').parent().parent().hide(150);
    $('#glass-frame').parent().parent().hide(150);
    $('#wing-frame-type').parent().parent().hide(150);
    $('#wing-hinge').parent().parent().hide(150);
    $('#wing-fittings').parent().parent().hide(150);
    $('#wing-handle').parent().parent().hide(150);

    $('#wing-title').hide(150);
    $('#glass-title').hide(150);
}

function updateWingDividerInput(currentPosition, minimumPosition, maximumPosition) {
    $('#wing-divider-position').val(currentPosition / 100);
    $('#wing-divider-position').attr('data-old-position', currentPosition);
    $('#wing-divider-position').attr('data-minimum-position', minimumPosition);
    $('#wing-divider-position').attr('data-maximum-position', maximumPosition);

    // update input form visibility
    $('#wing-divider-position').parent().parent().show(150);
    
    $('#wing-opening-mode').parent().parent().hide(150);
    $('#wing-opening-side').parent().parent().hide(150);
    $('#kfny-divider-position').parent().parent().hide(150);
    $('#glass-type').parent().parent().hide(150);
    $('#glass-width').parent().parent().hide(150);
    $('#glass-frame').parent().parent().hide(150);
    $('#wing-frame-type').parent().parent().hide(150);
    $('#wing-hinge').parent().parent().hide(150);
    $('#wing-fittings').parent().parent().hide(150);
    $('#wing-handle').parent().parent().hide(150);

    $('#wing-title').hide(150);
    $('#glass-title').hide(150);
}

function hideGlassInput() {
    $('#glass-type').parent().parent().hide(150);
    $('#glass-width').parent().parent().hide(150);
    $('#glass-frame').parent().parent().hide(150);
    
    $('#glass-title').hide(150);
}

function updateGlassInput(glass) {
    $('#glass-type').val(glass.glassType);
    $('#glass-width').val(glass.glassWidth);
    $('#glass-frame').val(glass.glassFrame);
    
    $('#glass-type').parent().parent().show(150);
    $('#glass-width').parent().parent().show(150);

    if (glass.glassType == 'Stadur') {
        $('#glass-frame').parent().parent().hide(300);
    } else {
        $('#glass-frame').parent().parent().show(300);
    }

    $('#glass-title').show(150);
}

function updateWingInput(wing) {
    $('#wing-opening-mode').val(wing.openingMode);
    $('#wing-opening-side').val(wing.openingSide);
    $('#wing-frame-type').val(wing.frameType);
    $('#wing-hinge').val(wing.hingeType);
    $('#wing-fittings').val(wing.fittings);
    $('#wing-handle').val(wing.handle.type);

    // update input form visibility
    $('#wing-opening-mode').parent().parent().show(150);
    $('#divider-position').parent().parent().hide(150);
    $('#wing-divider-position').parent().parent().hide(150);
    $('#wing-frame-type').parent().parent().show(150);
    $('#wing-hinge').parent().parent().show(150);
    $('#wing-fittings').parent().parent().show(150);
    $('#wing-handle').parent().parent().show(150);
    $('#wing-title').show(150);

    if (wing.openingMode == 'Fix' || wing.openingMode == 'Bukó') {
        $('#wing-opening-side').parent().parent().hide(150);
    } else {
        $('#wing-opening-side').parent().parent().show(150);
    }

    if (wing.openingMode == 'KFNY' || wing.openingMode == 'KFNY-BNY') {
        $('#kfny-divider-position').val(wing.kfnyDivider / 100);
        $('#kfny-divider-position').attr('data-old-position', wing.kfnyDivider);    

        var kfnyDividerPositionLimits = wing.getKfnyPositionLimits();

        $('#kfny-divider-position').attr('data-minimum-position', kfnyDividerPositionLimits[0] + wing.dividerWidth + wing.frameWidth);
        $('#kfny-divider-position').attr('data-maximum-position', kfnyDividerPositionLimits[1] - wing.dividerWidth - wing.frameWidth);
        $('#kfny-divider-position').parent().parent().show(150);
    } else {
        $('#kfny-divider-position').parent().parent().hide(150);
    }
}

function updateDeleteButton(deletable) {
    $('#delete-divider-button').prop('disabled', !deletable);
}

function updateProfit(profit, firstLoad = false) {
    var manualSetting = $('#manual-price-calculation').prop('checked');
    if (manualSetting && !firstLoad) {
        return;
    }

    $('#profit').val(profit);
}

function togglePriceSettings() {
    var checked = $(this).prop('checked');
    if (checked) {
        $('#topbar-prices').show();
    } else {
        $('#topbar-prices').hide();
    }
}

function updateFittingsPrice(fittingsPrice, firstLoad = false) {
    var manualSetting = $('#manual-price-calculation').prop('checked');
    if (manualSetting && !firstLoad) {
        return;
    }

    $('#fittings-price').val(fittingsPrice);
}

function updateWorkFee(workFee, firstLoad = false) {
    var manualSetting = $('#manual-price-calculation').prop('checked');
    if (manualSetting && !firstLoad) {
        return;
    }

    $('#wage').val(workFee);
}

function updateDoorstep(doorstep) {
    $('#doorwindow-doorstep').val(doorstep);
}

function updateDoorwindowQuantityInput(quantity) {
    $('#doorwindow-quantity').val(quantity);
}

function updateDoorwindowCommentInput(comment) {
    var formatedComment = comment.split('<br>').join("\r\n");
    $('#doorwindow-comment').val(formatedComment);
}

function updateDoorwindowFrameTypeInput(doorwindowType) {

    if (doorwindowType == 'Ablak') {
        $('option.window-only').show();
    } else {
        $('option.window-only').hide();
    }

    $('#doorwindow-type').val(doorwindowType);
}

function updateDoorwindowColorInput(color) {
    $('#doorwindow-color').val(color);
}

function doorwindowQuantityChanged() {
    quantity = parseInt($(this).val());
    canvas.doorWindow.setDoorwindowQuantity(quantity);
}

function doorwindowCommentChanged() {
    var comment = $(this).val();
    canvas.doorWindow.comment = comment.split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
    canvas.doorWindow.changed();
}

function doorwindowTypeChanged() {
    var doorwindowType = $('#doorwindow-type').val();
    canvas.doorWindow.setDoorwindowType(doorwindowType);

    if (doorwindowType == 'Ablak') {
        $('#wing-frame-type').val('Ablak');
        $('#doorwindow-doorstep').val('Tok küszöb');
        $('#wing-opening-mode').val('Bukó-nyíló');
        $('#wing-frame-type').change();
        $('#doorwindow-doorstep').change();
        $('#wing-opening-mode').change();

        //vasalat, pánt, kilincs és szárny legyen ablak + bukónyíló
    } else {
        $('#wing-frame-type').val('Bejárati ajtó');
        $('#doorwindow-doorstep').val('Alu küszöb bekötővel');
        $('#wing-opening-mode').val('Nyíló');
        $('#wing-frame-type').change();
        $('#doorwindow-doorstep').change();
        $('#wing-opening-mode').change();

        canvas.doorWindow.unselectAllWingsAndDividersAndExtensions();
        canvas.doorWindow.setAllGlassAttributes('Panel üveggel', '24mm', 'alukeret');
    }
}

function doorwindowDoorstepChanged() {
    canvas.doorWindow.setDoorwindowDoorstep($('#doorwindow-doorstep').val());
}

function doorwindowColorChanged() {
    canvas.doorWindow.setDoorwindowColor($('#doorwindow-color').val());
}

function doorwindowSizeChanged() {
    var newDoorWindowWidth = parseInt(100 * parseFloat($('#doorwindow-width').val()));
    var newDoorWindowHeight = parseInt(100 * parseFloat($('#doorwindow-height').val()));

    canvas.doorWindow.setSize(newDoorWindowWidth, newDoorWindowHeight);
}

function deleteSelectedObject() {
    canvas.doorWindow.deleteSelectedObject();
    canvas.doorWindow.checkDeletableSelectedObjects();
}

function selectedDividerPositionChanged() {
    var newPosition = parseInt(100 * parseFloat($(this).val()));
    var oldPosition = parseInt($(this).attr('data-old-position'));
    var minimumPosition = parseInt($(this).attr('data-minimum-position'));
    var maximumPosition = parseInt($(this).attr('data-maximum-position'));

    if (newPosition < minimumPosition || newPosition > maximumPosition) {
        dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Túl nagy, vagy túl kicsi érték!'});
        $(this).val(oldPosition / 100);
        return;
    }

    canvas.doorWindow.repositionSelectedDivider(oldPosition, newPosition);
    $(this).attr('data-old-position', newPosition);
}

function selectedWingDividerPositionChanged() {
    var newPosition = parseInt(100 * parseFloat($(this).val()));
    var oldPosition = parseInt($(this).attr('data-old-position'));
    var minimumPosition = parseInt($(this).attr('data-minimum-position'));
    var maximumPosition = parseInt($(this).attr('data-maximum-position'));
    if (newPosition < minimumPosition || newPosition > maximumPosition) {
        dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Túl nagy, vagy túl kicsi érték!'});
        $(this).val(oldPosition);
        return;
    }

    canvas.doorWindow.setSelectedWingDividerPosition(oldPosition, newPosition);
    $(this).attr('data-old-position', newPosition);
}

function selectedWingOpeningModeChanged() {
    var openingMode = $(this).val();
    canvas.doorWindow.setSelectedWingOpeningMode(openingMode);

    if (openingMode == 'Bukó-toló') {
        $('#wing-fittings').val('Bukó-toló');
        $('#wing-hinge').val('Bukó-toló');
        $('#wing-handle').val('Toló-ajtó');
        $('#wing-handle').change();
        $('#wing-fittings').change();
        $('#wing-hinge').change();
    }
}

function selectedWingOpeningSideChanged() {
    var openingSide = $(this).val();
    canvas.doorWindow.setSelectedWingOpeningSide(openingSide);
}

function selectedWingKfnyPositionChanged() {
    var newPosition = parseInt(100 * parseFloat($(this).val()));
    var oldPosition = parseInt($(this).attr('data-old-position')) / 100;
    var minimumPosition = parseInt($(this).attr('data-minimum-position'));
    var maximumPosition = parseInt($(this).attr('data-maximum-position'));

    if (newPosition < minimumPosition || newPosition > maximumPosition) {
        dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Túl nagy, vagy túl kicsi érték!'});
        $(this).val(oldPosition);
        return;
    }

    canvas.doorWindow.setSelectedWingKfnyDividerPosition(newPosition);
    $(this).attr('data-old-position', newPosition);
}

function selectedGlassTypeOrWidthChanged() {
    var glassType = $('#glass-type').val();
    var glassWidth = $('#glass-width').val();
    var glassFrame = $('#glass-frame').val();

    if (glassType == 'Stadur') {
        $('#glass-frame').parent().parent().hide(300);
    } else {
        $('#glass-frame').parent().parent().show(300);
    }

    canvas.doorWindow.setSelectedGlassAttributes(glassType, glassWidth, glassFrame);
}

function selectedWingFrameTypeChanged() {
    var wingFrameType = $(this).val();

    if (wingFrameType == 'Ablak') {
        $('#wing-hinge').val('Ablak');
        $('#wing-handle').val('Ablak');
        $('#wing-fittings').val('Ablak');
        $('#doorwindow-doorstep').val('Tok küszöb');

        $('#wing-hinge').change();
        $('#wing-handle').change();
        $('#wing-fittings').change();
        $('#doorwindow-doorstep').change();
    }

    if (wingFrameType == 'Bejárati ajtó') {
        $('#wing-hinge').val('Ajtó-iq');
        $('#wing-handle').val('Ajtó');
        $('#wing-fittings').val('Ajtó - 5pont');
        $('#doorwindow-doorstep').val('Alu küszöb bekötővel');

        $('#wing-hinge').change();
        $('#wing-handle').change();
        $('#wing-fittings').change();
        $('#doorwindow-doorstep').change();
    }

    canvas.doorWindow.setSelectedWingFrameType(wingFrameType);
}

function addCurrentDoorwindowToHistory() {
    canvas.addToChangeHistory();
}

function stepBackInChangeHistory() {
    canvas.stepBackInChangeHistory();
}

function stepForwardInChangeHistory() {
    canvas.stepForwardInChangeHistory();
}

function selectedWingHingeChanged() {
    canvas.doorWindow.setSelectedWingHinge($(this).val());
}

function selectedWingFittingsChanged() {
    canvas.doorWindow.setSelectedWingFittings($(this).val());
}

function selectedWingHandleChanged() {
    canvas.doorWindow.setSelectedWingHandle($(this).val());
}

function profitChanged() {
    var profit = parseInt($(this).val());

    if (isNaN(profit) || profit < 0) {
        profit = 0;
        $(this).val(profit);
    }

    canvas.doorWindow.setProfit(profit);
}

function wageChanged() {
    var wage = parseInt($(this).val());

    if (isNaN(wage) || wage < 0) {
        wage = 0;
        $(this).val(wage);
    }

    canvas.doorWindow.setWage(wage);
}

function fittingsPriceChanged() {
    var fittingsPrice = parseInt($(this).val());

    if (isNaN(fittingsPrice) || fittingsPrice < 0) {
        fittingsPrice = 0;
        $(this).val(fittingsPrice);
    }

    canvas.doorWindow.setFittingsPrice(fittingsPrice);
}

function manualPriceSettingChanged() {
    var manualSetting = $('#manual-price-calculation').prop('checked');
    canvas.doorWindow.setManualPriceCalculation(manualSetting);

    if (manualSetting) {
        $('#profit').prop('disabled', false);
        $('#wage').prop('disabled', false);
        $('#fittings-price').prop('disabled', false);
    } else {
        $('#profit').prop('disabled', true);
        $('#wage').prop('disabled', true);
        $('#fittings-price').prop('disabled', true);
        canvas.doorWindow.setFittingsPrice(canvas.doorWindow.getFittingsPrice());
        canvas.doorWindow.setWage(canvas.doorWindow.getWorkFees());
        canvas.doorWindow.setProfit(canvas.doorWindow.getProfit());
        canvas.doorWindow.changed();
    }
}

function updateManualPriceSettingState(state) {
    $('#manual-price-calculation').prop('checked', state);
    $('#profit').prop('disabled', !state);
    $('#wage').prop('disabled', !state);
    $('#fittings-price').prop('disabled', !state)
}

function toggleNewWingDirection() {
    if ($(this).hasClass('vertical')) {
        $(this).removeClass('vertical');
        $(this).attr('data-direction', 'vertical');
    } else {
        $(this).addClass('vertical');
        $(this).attr('data-direction', 'horizontal');
    }
}

function updateDoorwindowSaveButtonState() {
    $('#save-doorwindow-button').prop('disabled', canvas.doorWindow.isSaved);
}

function updateDoorwindowSumPrice() {
    var commissionFee = parseInt($('#doorwindow-sum-price').attr('data-commission-fee')) / 100 + 1;
    var unitPrice = Math.round(canvas.doorWindow.sumPrice / canvas.doorWindow.quantity * commissionFee);
    var before = unitPrice * canvas.doorWindow.quantity;
    var after = Math.round(before * 0.27) + before;
    
    $('#doorwindow-sum-price').html(formatCurrency(before) + ' Ft / ' + formatCurrency(after) + ' Ft');
}

function hideRightSideBar() {
    $('#right-sidebar').hide();
    $('#canvas').css('width', 'calc(100% - 426px)');
    updateCanvasSize();
}

function showAdditionalParts() {
    $('#right-sidebar').show();
    $('#canvas').css('width', 'calc(100% - 776px)');
    updateCanvasSize();
}

function updateDoorwindowAdditionalParts() {
    doorwindowAdditionalPartsList = canvas.doorWindow.additionalParts;
    $('#doorwindow-additional-parts').html('');

    for (var i = 0; i < doorwindowAdditionalPartsList.length; i ++) {
        var name = doorwindowAdditionalPartsList[i].name;
        var sizeText = doorwindowAdditionalPartsList[i].sizeText;
        var price = doorwindowAdditionalPartsList[i].price;

        $('#doorwindow-additional-parts').append('<div class="doorwindow-additional-part" data-index="' + i + 
        '" data-name="' + name + '">' + name + sizeText + ' ' + price + 'Ft</div>');
    }
}

function loadAdditionalParts() {
    var additionalParts = ipcRenderer.sendSync('load-additional-parts');
    for (var i = 0; i < additionalParts.length; i ++) {
            $('#additional-parts-list').append('<div class="additional-part" data-type="' + additionalParts[i].type + '" data-has-size="' + 
            additionalParts[i].hasSize + '" data-default-size="' + additionalParts[i].defaultSize + '">' + additionalParts[i].name + '</div>');
    }

    $('.additional-part').hide();
    $('.additional-part[data-type=kiegészítő]').show();
}

function additionalPartsCategoryButton() {
    var type = $(this).attr('data-menu');
    
    $('.additional-part').hide();
    $('.additional-part').removeClass('selected');
    $('.additional-part[data-type=' + type + ']').show();
    $('#additional-part-length-box').hide();
    $('#additional-part-size-box').hide();
    $('#additional-part-quantity').val(1);
    $('#additional-part-price').val(0);
    $('#additional-part-division').val(10);
    $('#additional-part-price').attr('title', '');
}

function selectAdditionalPart() {
    $('#additional-part-quantity').val(1);
    $('.additional-part').removeClass('selected');
    $(this).addClass('selected');

    var type = $(this).attr('data-type');
    var hasSize = parseInt($(this).attr('data-has-size'));
    var defaultSize = parseInt($(this).attr('data-default-size'));
    
    if (type == 'kiegészítő' && hasSize) {
        $('#additional-part-length').val(defaultSize);
        $('#additional-part-length-box').show();
        $('#additional-part-size-box').hide();
        $('#additional-part-division-box').hide();
        $('#additional-part-quantity').val(canvas.doorWindow.quantity);
    }

    if (type == 'kiegészítő' && !hasSize) {
        $('#additional-part-length').val(1000);
        $('#additional-part-length-box').hide();
        $('#additional-part-size-box').hide();
        $('#additional-part-division-box').hide();
        $('#additional-part-quantity').val(canvas.doorWindow.quantity);
    }

    if (type == 'szúnyogháló' && hasSize) {
        $('#additional-part-length').val(defaultSize);
        $('#additional-part-length-box').hide();
        $('#additional-part-size-box').show();
        $('#additional-part-division-box').hide();
        $('#additional-part-width').val(canvas.doorWindow.width / 100);
        $('#additional-part-height').val(canvas.doorWindow.height / 100);
        $('#additional-part-quantity').val(canvas.doorWindow.quantity);

        if (canvas.doorWindow.dividers) {
            var firstDivider = canvas.doorWindow.width;
            for (var i = 0; i < canvas.doorWindow.dividers.length; i++) {
                
                // if a divider is not vertical
                if (canvas.doorWindow.dividers[i][0] !== canvas.doorWindow.dividers[i][2]) {
                    return;
                }

                if (canvas.doorWindow.dividers[i][0] < firstDivider) {
                    firstDivider = canvas.doorWindow.dividers[i][0];
                }
            }
        }

        $('#additional-part-width').val(firstDivider / 100);
    }

    if (type == 'szúnyogháló' && !hasSize) {
        $('#additional-part-length').val(defaultSize);
        $('#additional-part-length-box').hide();
        $('#additional-part-size-box').hide();
        $('#additional-part-division-box').hide();
        $('#additional-part-width').val(canvas.doorWindow.width / 100);
        $('#additional-part-height').val(canvas.doorWindow.height / 100);
        $('#additional-part-quantity').val(canvas.doorWindow.quantity);
    }

    if (type == 'redőny' && hasSize) {
        // calculate size with extensions for additional part
        // withouth "párkányfogadó"
        var calculatedWidth = canvas.doorWindow.width;
        var calculatedHeight = canvas.doorWindow.height;
        var extensions = canvas.doorWindow.extensions;

        for (var i = 0; i < extensions.top.length; i++) {
            if (extensions.top[i].name.indexOf('Párkányfogadó') !== -1) {
                continue;
            }

            calculatedHeight += extensions.top[i].size;
        }

        for (var i = 0; i < extensions.right.length; i++) {
            if (extensions.right[i].name.indexOf('Párkányfogadó') !== -1) {
                continue;
            }

            calculatedWidth += extensions.right[i].size;
        }

        for (var i = 0; i < extensions.bottom.length; i++) {
            if (extensions.bottom[i].name.indexOf('Párkányfogadó') !== -1) {
                continue;
            }

            calculatedHeight += extensions.bottom[i].size;
        }

        for (var i = 0; i < extensions.left.length; i++) {
            if (extensions.left[i].name.indexOf('Párkányfogadó') !== -1) {
                continue;
            }

            calculatedWidth += extensions.left[i].size;
        }

        $('#additional-part-length').val(defaultSize);
        $('#additional-part-length-box').hide();
        $('#additional-part-size-box').show();
        $('#additional-part-division-box').show();
        $('#additional-part-division').val(0);
        $('#additional-part-width').val(calculatedWidth / 100);
        $('#additional-part-height').val(calculatedHeight / 100);
        $('#additional-part-quantity').val(canvas.doorWindow.quantity);
    }
    if (type == 'redőny' && !hasSize) {
        $('#additional-part-length').val(defaultSize);
        $('#additional-part-length-box').hide();
        $('#additional-part-size-box').hide();
        $('#additional-part-division-box').hide();
        $('#additional-part-division').val(0);
        $('#additional-part-width').val(canvas.doorWindow.width / 100);
        $('#additional-part-height').val(canvas.doorWindow.height / 100);
        $('#additional-part-quantity').val(canvas.doorWindow.quantity);
    }

    if (type == 'párkány') {
        $('#additional-part-length').val(canvas.doorWindow.width / 100);
        $('#additional-part-length-box').show();
        $('#additional-part-size-box').hide();
        $('#additional-part-division-box').hide();
        $('#additional-part-quantity').val(canvas.doorWindow.quantity);
    }
    
    calculateAdditionalPartPrice();
}

function selectDoorwindowAdditionalPart() {
    $('.doorwindow-additional-part').removeClass('selected');
    $(this).addClass('selected');

    $('#delete-additional-part-button').prop('disabled', false);
}

function calculateAdditionalPartPrice() {
    if (!$('.additional-part.selected').length) {
        return;
    }

    var priceSettings = ipcRenderer.sendSync('load-price-settings');
    var hasSize = parseInt($('.additional-part.selected').attr('data-has-size'));
    var type = $('.additional-part.selected').attr('data-type');
    var quantity = parseInt($('#additional-part-quantity').val());
    var size = (parseInt($('#additional-part-length').val()) / 1000).toFixed(1);
    var name = $('.additional-part.selected').html();
    var price = 0;

    if (type == 'kiegészítő') {
        if (hasSize) {
            price = Math.round(getPriceByPartName(priceSettings, name) * size) * quantity;
        } else {
            price = Math.round(getPriceByPartName(priceSettings, name)) * quantity;
        }
    }

    if (type == 'szúnyogháló') {
        var width = parseInt($('#additional-part-width').val());
        var height = parseInt($('#additional-part-height').val());
        var size = (width * height / 1000000).toFixed(1);

        if (size < 1) {
            size = 1;
        }

        if (hasSize) {
            price = Math.round(getPriceByPartName(priceSettings, name) * size) * quantity;
        } else {
            price = Math.round(getPriceByPartName(priceSettings, name)) * quantity;
        }
    }

    if (type == 'redőny') {
        var width = parseInt($('#additional-part-width').val());
        var height = parseInt($('#additional-part-height').val());
        var division = parseInt($('#additional-part-division').val());

        var size = (width * height / 1000000).toFixed(1);
        if (!hasSize) {
            price = Math.round(getPriceByPartName(priceSettings, name)) * quantity;
        } else {
            if (division) {
                if (division < 10 || division > width) {
                    $('#additional-part-price').val(0);
                    $('#additional-part-price').attr('title', '!');
                    dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Nem megfelelő osztás méret.'});
                    return;
                }

                size = ((width - division) * height / 1000000).toFixed(1);
                var size2 = ((width - (width - division)) * height / 1000000).toFixed(1);
                
                if (size < 1.3) {
                    size = 1.3;
                }
                
                if (size2 < 1.3) {
                    size2 = 1.3;
                }

                price = Math.round(getPriceByPartName(priceSettings, name) * size) * quantity;
                price += Math.round(getPriceByPartName(priceSettings, name) * size2) * quantity;
            } else {
                if (size < 1.3) {
                    size = 1.3;
                }

                price = Math.round(getPriceByPartName(priceSettings, name) * size) * quantity;
            }
        }
    }

    if (type == 'párkány') {
        price = Math.round(getPriceByPartName(priceSettings, name) * size) * quantity;
    }

    $('#additional-part-price').val(price);
}

function addSelectedAdditionalPart() {
    var hasSize = parseInt($('.additional-part.selected').attr('data-has-size'));
    var additionalPart = {
        type: $('.additional-part.selected').attr('data-type'),
        name: $('.additional-part.selected').html(),
        quantity: parseInt($('#additional-part-quantity').val()),
        price: parseInt($('#additional-part-price').val()),
        size: -1,
    }

    if (additionalPart.type == 'kiegészítő' && hasSize) {
        additionalPart.size = parseInt($('#additional-part-length').val());
        additionalPart.sizeText = ' (' + (additionalPart.size / 1000)  + 'm) ' + additionalPart.quantity + 'db';
    }

    if (additionalPart.type == 'kiegészítő' && !hasSize) {
        additionalPart.sizeText = ' ' + additionalPart.quantity + 'db';
    }

    if (additionalPart.type == 'szúnyogháló' && hasSize) {
        additionalPart.width = parseInt($('#additional-part-width').val());
        additionalPart.height = parseInt($('#additional-part-height').val());
        
        var size = additionalPart.width * additionalPart.height / 1000000;
        if (size < 1) {
            size = 1;
        }

        additionalPart.sizeText = ' (' + size.toFixed(1)  + 'm²) ' + additionalPart.quantity + 'db';
    }

    if (additionalPart.type == 'szúnyogháló' && !hasSize) {
        additionalPart.width = -1;
        additionalPart.height = -1;
        additionalPart.sizeText = ' ' + additionalPart.quantity + 'db';
    }

    if (additionalPart.type == 'redőny' && hasSize) {
        additionalPart.width = parseInt($('#additional-part-width').val());
        additionalPart.height = parseInt($('#additional-part-height').val());
        additionalPart.division = parseInt($('#additional-part-division').val());
        if (additionalPart.division) {
            additionalPart.price += 2362;
        }

        if (additionalPart.division) {
            var size1 = ((additionalPart.width - additionalPart.division) * additionalPart.height / 1000000).toFixed(1);
            var size2 = ((additionalPart.width - (additionalPart.width - additionalPart.division)) * additionalPart.height / 1000000).toFixed(1);

            if (size1 < 1.3) {
                size1 = 1.3;
            }

            if (size2 < 1.3) {
                size2 = 1.3;
            }

            additionalPart.sizeText = ' (' + size1 + 'm², ' + size2 + 'm²) ' + additionalPart.quantity + 'db';

        } else {
            var size = additionalPart.width * additionalPart.height / 1000000;
            if (size < 1.3) {
                size = 1.3;
            }

            additionalPart.sizeText = ' (' + size.toFixed(1)  + 'm²) ' + additionalPart.quantity + 'db';
        }
    }

    if (additionalPart.type == 'redőny' && !hasSize) {
        additionalPart.width = -1;
        additionalPart.height = -1;
        additionalPart.division = -1;
        additionalPart.sizeText = ' ' + additionalPart.quantity + 'db';
    }
    
    if (additionalPart.type == 'párkány' && !hasSize) {
        additionalPart.size = parseInt($('#additional-part-length').val());
        additionalPart.sizeText = ' (' + (additionalPart.size / 1000)  + 'm) ' + additionalPart.quantity + 'db';
    }

    console.log(additionalPart);
    canvas.doorWindow.additionalParts.push(additionalPart);
    updateDoorwindowAdditionalParts();
    canvas.doorWindow.changed();
}

function deleteSelectedDoorwindowAdditionalPart() {
    var index = parseInt($('.doorwindow-additional-part.selected').attr('data-index'));
    canvas.doorWindow.additionalParts.splice(index, 1);
    $(this).prop('disabled', true);
    
    updateDoorwindowAdditionalParts();
    canvas.doorWindow.changed();
}