class Handle {
    constructor(frameDirection, handleDirection, type) {
        // direction can be H or V
        this.frameDirection = frameDirection;

        // direction can be HL HR VD
        this.handleDirection = handleDirection;

        this.type = type;
    }

    drawout(g, x, y) {
        // handle frame drawout
        if (this.frameDirection == 'H') {
            g.fillRect(x - mmToPixel(5000), y, mmToPixel(10000), mmToPixel(3000));
            g.strokeRect(x - mmToPixel(5000), y, mmToPixel(10000), mmToPixel(3000));
        } else {
            g.fillRect(x, y - mmToPixel(4000), mmToPixel(3000), mmToPixel(10000));
            g.strokeRect(x, y - mmToPixel(4000), mmToPixel(3000), mmToPixel(10000));
        }

        // draw out door lock
        if (this.type == 'Ajtó') {
            g.beginPath();
            g.arc(x + mmToPixel(1400), y + mmToPixel(4000), mmToPixel(800), 0, 2 * Math.PI);
            g.stroke();
        }

        // handle drawout based on direction
        if (this.frameDirection == 'H') {
            if (this.handleDirection == 'R') {
                g.fillRect(x, y + mmToPixel(500), mmToPixel(10000), mmToPixel(2000));
                g.strokeRect(x, y + mmToPixel(500), mmToPixel(10000), mmToPixel(2000));
            }
        } else {
            if (this.handleDirection == 'R') {
                g.fillRect(x + mmToPixel(1000), y - mmToPixel(1500), mmToPixel(10000), mmToPixel(3000));
                g.strokeRect(x + mmToPixel(1000), y - mmToPixel(1500), mmToPixel(10000), mmToPixel(3000));
            } else if (this.handleDirection == 'L') {
                g.fillRect(x - mmToPixel(9000), y - mmToPixel(1500), mmToPixel(10000), mmToPixel(3000));
                g.strokeRect(x - mmToPixel(9000), y - mmToPixel(1500), mmToPixel(10000), mmToPixel(3000));
            } else if (this.handleDirection == 'D') {
                g.fillRect(x + mmToPixel(500), y, mmToPixel(2000), mmToPixel(10000));
                g.strokeRect(x + mmToPixel(500), y, mmToPixel(2000), mmToPixel(10000));
            }
        }
    }
}