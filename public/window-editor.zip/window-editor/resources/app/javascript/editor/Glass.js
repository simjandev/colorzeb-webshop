class Glass {
    constructor(x, y, width, height, glassType = 'Üveg', glassWidth = '24mm', glassFrame = 'alukeret') {
        this.x = x;
        this.y = y;

        this.width = width;
        this.height = height;

        this.selected = false;

        this.glassType = glassType;
        this.glassWidth = glassWidth;
        this.glassFrame = glassFrame;

        this.dividerPosition = -1;
        this.dividerDirection = 'horizontal';
    }

    load(glassString) {
        
        var data = glassString.split('|');

        this.x = parseInt(data[0]);
        this.y = parseInt(data[1]);
        this.width = parseInt(data[2]);
        this.height = parseInt(data[3]);
        this.glassType = data[4];
        this.glassWidth = data[5];

        if (data.length > 6) {
            this.glassFrame = data[6];
        } else {
            this.glassFrame = 'alukeret';
        }

    }

    getSaveString() {
        var saveString = '';

        saveString += this.x + '|';
        saveString += this.y + '|';
        saveString += this.width + '|';
        saveString += this.height + '|';
        saveString += this.glassType + '|';
        saveString += this.glassWidth + '|';
        saveString += this.glassFrame;

        return saveString;
    }

    drawout(g, offsetX, offsetY) {
        
        g.fillStyle = '#ffffff';
        g.fillRect(offsetX + mmToPixel(this.x), offsetY + mmToPixel(this.y), mmToPixel(this.width), mmToPixel(this.height));

        // colorize glass if selected
        if (this.selected) {
            var blinking = (new Date().getTime() / 1.1) % 2000 / 1000.0;
            if (blinking > 1) {
                blinking = 2 - blinking;
            }

            blinking = blinking / 2.0 + 0.5;
            g.fillStyle = "rgba(0, 100, 255, " + blinking + ")";
        } else {
            g.fillStyle = "rgb(255, 255, 255)";
        }

        g.fillRect(offsetX + mmToPixel(this.x), offsetY + mmToPixel(this.y), mmToPixel(this.width), mmToPixel(this.height));

        // draw out drag over new wing divider
        if (this.dividerPosition !== -1) {
            g.strokeStyle = "rgb(0, 100, 255)";
            g.lineCap = 'square';
            g.beginPath();

            if (this.dividerDirection == 'horizontal')
            {
                g.moveTo(offsetX + mmToPixel(this.x), offsetY + mmToPixel(this.y + this.dividerPosition));
                g.lineTo(offsetX + mmToPixel(this.x + this.width), offsetY + mmToPixel(this.y + this.dividerPosition));
                g.stroke();
            } else {
                g.moveTo(offsetX + mmToPixel(this.x + this.dividerPosition), offsetY + mmToPixel(this.y));
                g.lineTo(offsetX + mmToPixel(this.x + this.dividerPosition), offsetY + mmToPixel(this.y + this.height));
                g.stroke();
            }

            g.strokeStyle = "rgb(0, 0, 0)";
        }

        // draw out symbol for stadur
        g.strokeStyle = "rgb(0, 0, 0)";
        var x1 = 0;
        var y1 = 0;
        var x2 = 0;
        var y2 = 0;
        var stripeWidth = 20000;
        if (this.glassType == 'Stadur') {
            for (x2 = 0; x2 <= this.width; x2+= stripeWidth) {
                g.moveTo(offsetX + mmToPixel(this.x + x1), offsetY + mmToPixel(this.y + y1));
                g.lineTo(offsetX + mmToPixel(this.x + x2), offsetY + mmToPixel(this.y + y2));
                g.stroke();

                y1 += stripeWidth;
                while (y1 > this.height) {
                    y1 --;
                    x1 ++;
                }
            }

            while(x2 > this.width) {
                x2 --;
                y2 ++;
            }
            
            for (y2 = y2; y2 <= this.height; y2+= stripeWidth) {
                g.moveTo(offsetX + mmToPixel(this.x + x1), offsetY + mmToPixel(this.y + y1));
                g.lineTo(offsetX + mmToPixel(this.x + x2), offsetY + mmToPixel(this.y + y2));
                g.stroke();

                y1 += stripeWidth;
                while (y1 > this.height) {
                    y1 --;
                    x1 ++;
                }
                
            }
        }
    }

    wingDividerDragOver(x, y, dividerDirection) {
        this.dividerDirection = dividerDirection;
        if (dividerDirection == 'horizontal') {
            this.dividerPosition = y;
        } else {
            this.dividerPosition = x;
        }
    }
}