class DoorWindow {
    constructor(width = null, height = null, isInEditor = false) {
        this.manualPriceCalculation = false;
        this.x = 7500;
        this.y = 7500;

        this.width = width ? width : 20000;
        this.height = height ? height : 20000;

        this.additionalParts = [];

        this.comment = '';

        // if doorwindow isn't in an editor, it doesn't necessary
        // to update input forms
        this.isInEditor = isInEditor;

        this.fileName = 'default.dw';
        this.displayName = this.width / 100 + 'x' + this.height / 100 + ' Nyíló Bal';
        this.isSaved = true;

        this.quantity = 1;

        this.frameType = 'Ablak';

        this.doorstepType = 'Tok küszöb';
        updateDoorstep(this.doorstepType);

        this.color = '#ffffff';

        // extension drag over
        // 0 top 1 right 2 bottom 3 left
        this.extensionDragSide = -1;
        this.extensionDragSize = -1;
        this.extensionIsInSize = -1;

        this.extensions = {
            top: [],
            right: [],
            bottom: [],
            left: [],
        };

        // distance between 2 divider symbols in pixels
        this.dividerSymbolDistance = 25;

        this.frameWidth = 6150;
        this.doorstepWidth = 2500;
        
        this.wings = [];
        this.selectedWingIndex = -1;

        // contains a collection of wing dividers
        // an element is an other array containing coordinates
        // [x1, y1, x2, y2]
        this.dividers = [];
        
        // divider's width in mm
        this.dividerWidth = global.settings.dividerWidth;
        this.selectedDividerIndex = -1;

        this.wings.push(new Wing('Bukó-nyíló', 'Bal', 0, 0, this.width, this.height));
        this.recalculateFrameSpacingAndFrameWidth();

        if (this.isInEditor) {
            this.updateDoorwindowSizeInputValues();
        }

        this.profit = this.getProfit();
        this.wage = this.getWorkFees();
        this.fittingsPrice = this.getFittingsPrice();

        updateFittingsPrice(this.getFittingsPrice());
        updateWorkFee(this.getWorkFees());
        updateProfit(this.getProfit());

        // sum price is being calculated at every change
        this.sumPrice = 0;
        this.setSumPrice();

        if (this.isInEditor) {
            updateDoorwindowFrameTypeInput(this.frameType);
        }
    }

    // whenever the doorwindow being edited, this function being called
    // it updates save button and updates back/forward backlog
    changed() {
        this.isSaved = false;
        if (this.isInEditor) {
            updateDoorwindowSaveButtonState();

            var manualPriceCalculation = $('#manual-price-calculation').prop('checked') ? 1 : 0;
            if (!manualPriceCalculation) {
                this.profit = this.getProfit();
                this.wage = this.getWorkFees();
                this.fittingsPrice = this.getFittingsPrice();
            }
        }

        

        this.setSumPrice();
        
        if (this.isInEditor) {
            updateDoorwindowSumPrice();
        }

        if (this.wings.length > 1) {
            this.displayName = this.width / 100 + 'x' + this.height / 100 + ' tokosztott'; 
        } else {
            this.displayName = this.width / 100 + 'x' + this.height / 100 + ' ' + this.wings[0].openingMode;
            if (this.wings[0].openingMode !== 'Fix') {
                this.displayName += ' ' + this.wings[0].openingSide
            }
        }

        if (this.isInEditor) {
            addCurrentDoorwindowToHistory();
            updateFittingsPrice(this.getFittingsPrice());
            updateWorkFee(this.getWorkFees());
            updateProfit(this.getProfit());
        }
    }

    // loads a doorwindow from a save string
    load(doorwindowString) {
        var priceSettings = ipcRenderer.sendSync('load-price-settings');
        this.wings = [];
        this.dividers = [];
        this.additionalParts = [];

        this.extensions = {
            top: [],
            right: [],
            bottom: [],
            left: [],
        };
        
        var lines = doorwindowString.split("\r\n");

        var data = lines[0].split('|');
        
        this.displayName = data[0];
        this.width = parseInt(data[2]);
        this.height = parseInt(data[3]);
        this.profit = parseInt(data[4]);
        this.wage = parseInt(data[5]);
        this.fittingsPrice = parseInt(data[6]);
        this.color = data[7];
        this.doorstepType = data[8];
        this.quantity = parseInt(data[9]);
        this.x = parseInt(data[10]);
        this.y = parseInt(data[11]);
        this.dividerWidth = parseInt(data[12]);

        if (data.length > 13) {
            this.comment = data[13];
            updateDoorwindowCommentInput(data[13]);
        }

        if (data.length > 14) {
            this.manualPriceCalculation = parseInt(data[14]) ? true : false;
        } else {
            this.manualPriceCalculation = true;
        }

        if (this.isInEditor) {
            updateManualPriceSettingState(this.manualPriceCalculation);
        }

        var wings = doorwindowString.split('START-OF-WINGS')[1].split('END-OF-WINGS')[0].split("\r\n");
        for(var i = 0; i < wings.length; i++) {
            var wing = new Wing('', '', 0, 0, 0, 0);
            wing.load(wings[i]);
            this.wings.push(wing);
        }

        var dividers = doorwindowString.split('START-OF-DIVIDERS')[1].split('END-OF-DIVIDERS')[0].split("\r\n");
        if (dividers[0] != '') {
            for (var i = 0; i < dividers.length; i++) {
                var dividerData = dividers[i].split('|');
                var divider = [
                    parseInt(dividerData[0]),
                    parseInt(dividerData[1]),
                    parseInt(dividerData[2]),
                    parseInt(dividerData[3])
                ];

                this.dividers.push(divider);
            }
        }

        var extensionData = doorwindowString.split('START-OF-EXTENSIONS')[1].split('END-OF-EXTENSIONS')[0].split('||');
        var topExtensions = extensionData[0].split('|');
        if (topExtensions[0] !== '') {
            for (var i = 0; i < topExtensions.length; i++) {
                var size = parseInt(topExtensions[i].split(';')[0]);
                var name = topExtensions[i].split(';')[1];
                this.extensions.top.push({size: size, name: name, position: 'felső', selected: false});
            }
        }

        var rightExtensions = extensionData[1].split('|');
        if (rightExtensions[0] !== '') {
            for (var i = 0; i < rightExtensions.length; i++) {
                var size = parseInt(rightExtensions[i].split(';')[0]);
                var name = rightExtensions[i].split(';')[1];
                this.extensions.right.push({size: size, name: name, position: 'jobb', selected: false});
            }
        }

        var bottomExtensions = extensionData[2].split('|');
        if (bottomExtensions[0] !== '') {
            for (var i = 0; i < bottomExtensions.length; i++) {
                var size = parseInt(bottomExtensions[i].split(';')[0]);
                var name = bottomExtensions[i].split(';')[1];
                this.extensions.bottom.push({size: size, name: name, position: 'alsó', selected: false});
            }
        }

        var leftExtensions = extensionData[3].split('|');
        if (leftExtensions[0] !== '') {
            for (var i = 0; i < leftExtensions.length; i++) {
                var size = parseInt(leftExtensions[i].split(';')[0]);
                var name = leftExtensions[i].split(';')[1];
                this.extensions.left.push({size: size, name: name, position: 'bal', selected: false});
            }
        }

        if (doorwindowString.split('START-OF-ADDITIONAL-PARTS').length > 1) {
        var additionalParts = doorwindowString.split('START-OF-ADDITIONAL-PARTS')[1].split('END-OF-ADDITIONAL-PARTS')[0].split("\r\n");
            if (additionalParts[0] != '') {
                for (var i = 0; i < additionalParts.length; i ++) {
                    var additionalPartData = additionalParts[i].split('|');
                    var type = additionalPartData[0];

                    if (type == 'kiegészítő' || type == 'párkány') {
                        var additionalPart = {
                            type: type,
                            name: additionalPartData[1],
                            size: parseInt(additionalPartData[2]),
                            quantity: parseInt(additionalPartData[3]),
                        }

                        if (additionalPartData.length > 4) {
                            additionalPart.price = parseInt(additionalPartData[4]);
                        } else {
                            additionalPart.price = Math.round(getPriceByPartName(priceSettings, additionalPart.name) * (additionalPart.size / 1000)) * additionalPart.quantity;
                        }

                        if (additionalPartData.length > 5) {
                            additionalPart.sizeText = additionalPartData[5];
                        } else {
                            additionalPart.sizeText = ' (' + (additionalPart.size / 1000)  + 'm) ' + additionalPart.quantity + 'db';
                        }

                        if (additionalPartData[2] == '-1') {
                            additionalPart.size = -1;
                        }
                    }

                    if (type == 'szúnyogháló') {
                        var additionalPart = {
                            type: type,
                            name: additionalPartData[1],
                            size: parseInt(additionalPartData[2]),
                            quantity: parseInt(additionalPartData[3]),
                            price: parseInt(additionalPartData[4]),
                            sizeText: additionalPartData[5],
                            width: parseInt(additionalPartData[6]),
                            height: parseInt(additionalPartData[7]),
                        }

                        if (additionalPartData[2] == '-1') {
                            additionalPart.size = -1;
                        }
                    }

                    if (type == 'redőny') {
                        var additionalPart = {
                            type: type,
                            name: additionalPartData[1],
                            size: parseInt(additionalPartData[2]),
                            quantity: parseInt(additionalPartData[3]),
                            price: parseInt(additionalPartData[4]),
                            sizeText: additionalPartData[5],
                            width: parseInt(additionalPartData[6]),
                            height: parseInt(additionalPartData[7]),
                            division: parseInt(additionalPartData[8]),
                        }

                        if (additionalPartData[2] == '-1') {
                            additionalPart.size = -1;
                        }
                    }

                    this.additionalParts.push(additionalPart);
                }
            }
        }

        this.recalculateFrameSpacingAndFrameWidth();
        this.setDoorwindowType(data[1]);
        this.updateDoorwindowSizeInputValues();
        this.setDividerSize(global.settings.dividerWidth);

        if (this.isInEditor) {
            updateDoorwindowFrameTypeInput(this.frameType);
            updateDoorwindowColorInput(this.color);
            updateDoorwindowQuantityInput(this.quantity);

            updateFittingsPrice(this.fittingsPrice, true);
            updateWorkFee(this.wage, true);
            updateProfit(this.profit, true);
            updateDoorstep(this.doorstepType);
        }

        this.setSumPrice();

        this.isSaved = true;
    }

    getSaveString() {
        var saveString = '';
        var manualPriceCalculation = this.manualPriceCalculation ? 1 : 0;

        // doorwindow's attributes
        saveString += this.displayName + '|';
        saveString += this.frameType + '|';
        saveString += this.width + '|';
        saveString += this.height + '|';
        saveString += this.profit + '|';
        saveString += this.wage + '|';
        saveString += this.fittingsPrice + '|';
        saveString += this.color + '|';
        saveString += this.doorstepType + '|';
        saveString += this.quantity + '|';
        saveString += this.x + '|';
        saveString += this.y + '|';
        saveString += this.dividerWidth + '|';
        saveString += this.comment + '|';
        saveString += manualPriceCalculation + "\r\nSTART-OF-WINGS";

        // wings
        for (var i = 0; i < this.wings.length; i++) {
            saveString += this.wings[i].getSaveString();
            if (i !== this.wings.length - 1) {
                saveString += "\r\n";
            }
        }

        saveString += "END-OF-WINGS\r\n";
        saveString += "START-OF-DIVIDERS";
        // dividers
        for (var i = 0; i < this.dividers.length; i++) {
            saveString += this.dividers[i][0] + '|';
            saveString += this.dividers[i][1] + '|';
            saveString += this.dividers[i][2] + '|';
            saveString += this.dividers[i][3];

            if (i !== this.dividers.length - 1) {
                saveString += "\r\n";
            }
        }

        saveString += "END-OF-DIVIDERS\r\n";
        saveString += "START-OF-EXTENSIONS";
        for (var i = 0; i < this.extensions.top.length; i++) {
            saveString += this.extensions.top[i].size + ';' + this.extensions.top[i].name;
            if (i !== this.extensions.top.length - 1) {
                saveString += '|';
            }
        }

        saveString += '||';
        for (var i = 0; i < this.extensions.right.length; i++) {
            saveString += this.extensions.right[i].size + ';' + this.extensions.right[i].name;
            if (i !== this.extensions.right.length - 1) {
                saveString += '|';
            }
        }

        saveString += '||';
        for (var i = 0; i < this.extensions.bottom.length; i++) {
            saveString += this.extensions.bottom[i].size + ';' + this.extensions.bottom[i].name;
            if (i !== this.extensions.bottom.length - 1) {
                saveString += '|';
            }
        }

        saveString += '||';
        for (var i = 0; i < this.extensions.left.length; i++) {
            saveString += this.extensions.left[i].size + ';' + this.extensions.left[i].name;
            if (i !== this.extensions.left.length - 1) {
                saveString += '|';
            }
        }

        saveString += "END-OF-EXTENSIONS";

        saveString += "START-OF-ADDITIONAL-PARTS";
        for (var i = 0; i < this.additionalParts.length; i++) {
            if (this.additionalParts[i].type == 'kiegészítő' || this.additionalParts[i].type == 'párkány') {
                saveString += this.additionalParts[i].type + '|' + this.additionalParts[i].name + '|' + this.additionalParts[i].size + '|' +
                this.additionalParts[i].quantity + '|' + this.additionalParts[i].price + '|' + this.additionalParts[i].sizeText;
            }

            if (this.additionalParts[i].type == 'szúnyogháló') {
                saveString += this.additionalParts[i].type + '|' + this.additionalParts[i].name + '|' + this.additionalParts[i].size + '|' +
                this.additionalParts[i].quantity + '|' + this.additionalParts[i].price + '|' + this.additionalParts[i].sizeText  + '|' + 
                this.additionalParts[i].width + '|' + this.additionalParts[i].height;
            }

            if (this.additionalParts[i].type == 'redőny') {
                saveString += this.additionalParts[i].type + '|' + this.additionalParts[i].name + '|' + this.additionalParts[i].size + '|' +
                this.additionalParts[i].quantity + '|' + this.additionalParts[i].price + '|' + this.additionalParts[i].sizeText  + '|' + 
                this.additionalParts[i].width + '|' + this.additionalParts[i].height + '|' + this.additionalParts[i].division;
            }

            if (i !== this.additionalParts.length - 1) {
                saveString += "\r\n";
            }
        }

        saveString += "END-OF-ADDITIONAL-PARTS";

        return saveString;
    }

    drawout(g) {
        // draw color
        g.fillStyle = this.color;

        g.beginPath();
        g.fillRect(mmToPixel(this.x), mmToPixel(this.y), mmToPixel(this.width), mmToPixel(this.frameWidth));
        g.fillRect(mmToPixel(this.x), mmToPixel(this.y), mmToPixel(this.frameWidth), mmToPixel(this.height));
        g.fillRect(mmToPixel(this.x + this.width - this.frameWidth), this.y, mmToPixel(this.frameWidth), mmToPixel(this.height));

        if (this.doorstepType == 'Tok küszöb') {
            g.fillRect(mmToPixel(this.x), mmToPixel(this.y + this.height - this.frameWidth), mmToPixel(this.width), mmToPixel(this.frameWidth));
        }

        // draw out inner frame line
        g.beginPath();
        if (this.doorstepType == 'Tok küszöb') {
            g.moveTo(mmToPixel(this.x + this.frameWidth), mmToPixel(this.y + this.height) - mmToPixel(this.frameWidth));
        } else {
            g.moveTo(mmToPixel(this.x + this.frameWidth), mmToPixel(this.y + this.height));
        }

        g.lineTo(mmToPixel(this.x + this.frameWidth), mmToPixel(this.y + this.frameWidth));
        g.lineTo(mmToPixel(this.x + this.width) - mmToPixel(this.frameWidth), mmToPixel(this.y + this.frameWidth));

        if (this.doorstepType == 'Tok küszöb') {
            g.lineTo(mmToPixel(this.x + this.width) - mmToPixel(this.frameWidth), mmToPixel(this.y + this.height) - mmToPixel(this.frameWidth));
            g.lineTo(mmToPixel(this.x + this.frameWidth), mmToPixel(this.y + this.height) - mmToPixel(this.frameWidth));
        } else {
            g.lineTo(mmToPixel(this.x + this.width) - mmToPixel(this.frameWidth), mmToPixel(this.y + this.height));
        }

        g.stroke();

        // draw out doorstep
        if (this.doorstepType == 'Alu küszöb bekötővel') {
            g.beginPath();
            g.fillRect(mmToPixel(this.x), mmToPixel(this.y + this.height - this.doorstepWidth), mmToPixel(this.width), mmToPixel(this.doorstepWidth));

            g.beginPath();
            g.moveTo(mmToPixel(this.x), mmToPixel(this.y + this.height));
            g.lineTo(mmToPixel(this.x + this.width), mmToPixel(this.y + this.height));
            g.stroke();
        }
        
        // draw out corner lines
        // top left
        g.beginPath();
        g.moveTo(mmToPixel(this.x), mmToPixel(this.y));
        g.lineTo(mmToPixel(this.x + this.frameWidth), mmToPixel(this.y + this.frameWidth));
        g.stroke();

        // top right
        g.beginPath();
        g.moveTo(mmToPixel(this.x + this.width), mmToPixel(this.y));
        g.lineTo(mmToPixel(this.x + this.width - this.frameWidth), mmToPixel(this.y + this.frameWidth));
        g.stroke();

        if (this.doorstepType == 'Tok küszöb') {
            // bottom left
            g.beginPath();
            g.moveTo(mmToPixel(this.x), mmToPixel(this.y + this.height));
            g.lineTo(mmToPixel(this.x + this.frameWidth), mmToPixel(this.y + this.height - this.frameWidth));
            g.stroke();

            // bottom right
            g.beginPath();
            g.moveTo(mmToPixel(this.x + this.width), mmToPixel(this.y + this.height));
            g.lineTo(mmToPixel(this.x + this.width - this.frameWidth), mmToPixel(this.y + this.height - this.frameWidth));
            g.stroke();
        }

        if (this.doorstepType == 'Alu küszöb bekötővel') {
            // bottom left
            g.beginPath();
            g.moveTo(mmToPixel(this.x), mmToPixel(this.y + this.height - this.doorstepWidth));
            g.lineTo(mmToPixel(this.x + this.frameWidth), mmToPixel(this.y + this.height - this.doorstepWidth));
            g.stroke();

            // bottom left
            g.beginPath();
            g.moveTo(mmToPixel(this.x + this.width - this.frameWidth), mmToPixel(this.y + this.height - this.doorstepWidth));
            g.lineTo(mmToPixel(this.x + this.width), mmToPixel(this.y + this.height - this.doorstepWidth));
            g.stroke();
        }

        // draw out dividers
        for (var i = 0; i < this.dividers.length; i++) {
            var dividerWidth = this.dividers[i][2] - this.dividers[i][0];
            var dividerHeight = this.dividers[i][3] - this.dividers[i][1];
            
            // set different background color for selected divider
            if (i == this.selectedDividerIndex) {
                var blinking = (new Date().getTime() / 1.1) % 2000 / 1000.0;
                if (blinking > 1) {
                    blinking = 2 - blinking;
                }

                blinking = blinking / 2.0 + 0.5;
                g.fillStyle = "rgba(0, 100, 255, " + blinking + ")";
            } else {
                g.fillStyle = this.color;
            }

            if (dividerHeight == 0) {
                // horizontal
                g.fillRect(mmToPixel(this.x + this.dividers[i][0]), mmToPixel(this.y + this.dividers[i][1] - this.dividerWidth / 2), mmToPixel(dividerWidth), mmToPixel(this.dividerWidth));
                g.strokeRect(mmToPixel(this.x + this.dividers[i][0]), mmToPixel(this.y + this.dividers[i][1] - this.dividerWidth / 2), mmToPixel(dividerWidth), mmToPixel(this.dividerWidth));
            } else {
                // vertical
                g.fillRect(mmToPixel(this.x + this.dividers[i][0] - this.dividerWidth / 2), mmToPixel(this.y + this.dividers[i][1]), mmToPixel(this.dividerWidth), mmToPixel(dividerHeight));
                g.strokeRect(mmToPixel(this.x + this.dividers[i][0] - this.dividerWidth / 2), mmToPixel(this.y + this.dividers[i][1]), mmToPixel(this.dividerWidth), mmToPixel(dividerHeight));
            }
        }

        // setup default size with divider symbols
        this.widthWithDividerSizeSymbols = mmToPixel(this.width) + this.dividerSymbolDistance * 2 + 5 + 10;
        this.heightWithDividerSizeSymbols = mmToPixel(this.height) + this.dividerSymbolDistance * 2 + 5 + 10;

        var topExtensionSumSize = mmToPixel(this.getExtensionsSumSize('top'));
        var rightExtensionSumSize = mmToPixel(this.getExtensionsSumSize('right'));
        var bottomExtensionSumSize = mmToPixel(this.getExtensionsSumSize('bottom'));
        var leftExtensionSumSize = mmToPixel(this.getExtensionsSumSize('left'));

        // setup font
        g.textAlign = 'center';
        g.font = '12px Arial';
        g.fillStyle = 'black';
        
        // DOORWINDOW HEIGHT SYMBOL START
        var verticalSymbolsBeforeDividers = 1;
        var horizontalSymbolsBeforeDividers = 1;

        g.beginPath();
        g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance, mmToPixel(this.y) - topExtensionSumSize);
        g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance, bottomExtensionSumSize + mmToPixel(this.y + this.height));
        g.stroke();
        
        // top symbol
        g.beginPath();
        g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance - 5, mmToPixel(this.y) - topExtensionSumSize);
        g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance + 5, mmToPixel(this.y) - topExtensionSumSize);
        g.stroke();

        // height text
        g.save();
        g.translate(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance - 5, mmToPixel(this.y) - topExtensionSumSize + (topExtensionSumSize + bottomExtensionSumSize + mmToPixel(this.height)) / 2);
        g.rotate(270 * Math.PI / 180);
        g.fillText((this.height + this.getExtensionsSumSize('top') + this.getExtensionsSumSize('bottom')) / 100 + "mm", 0, 0);
        g.restore();

        // bottom symbol
        g.beginPath();
        g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance - 5, bottomExtensionSumSize + mmToPixel(this.y + this.height));
        g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance + 5, bottomExtensionSumSize + mmToPixel(this.y + this.height));
        g.stroke();
        // DOORWINDOW HEIGHT SYMBOL END
        
        // top and bottom extension symbols
        var extensionSumSize = 0;
        if (topExtensionSumSize + bottomExtensionSumSize) {
            verticalSymbolsBeforeDividers = 2;
            
            g.beginPath();
            g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2, mmToPixel(this.y) - topExtensionSumSize);
            g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2, bottomExtensionSumSize + mmToPixel(this.y + this.height));
            g.stroke();

            // top symbol
            g.beginPath();
            g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 - 5, mmToPixel(this.y));
            g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 + 5, mmToPixel(this.y));
            g.stroke();

            // draw out top extensions' symbols
            extensionSumSize = 0;
            for (var i = 0; i < this.extensions.top.length; i++) {
                extensionSumSize += mmToPixel(this.extensions.top[i].size);

                g.beginPath();
                g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 - 5, mmToPixel(this.y) - extensionSumSize);
                g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 + 5, mmToPixel(this.y) - extensionSumSize);
                g.stroke();
            }
            
            // draw out bottom extensions' symbols
            extensionSumSize = 0;
            for (var i = 0; i < this.extensions.bottom.length; i++) {
                extensionSumSize += mmToPixel(this.extensions.bottom[i].size);

                g.beginPath();
                g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 - 5, mmToPixel(this.y + this.height) + extensionSumSize);
                g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 + 5, mmToPixel(this.y + this.height) + extensionSumSize);
                g.stroke();
            }

            // height text
            g.save();
            g.translate(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 - 5, mmToPixel(this.y + this.height / 2));
            g.rotate(270 * Math.PI / 180);
            g.fillText(this.height / 100 + "mm", 0, 0);
            g.restore();
            
            // bottom symbol
            g.beginPath();
            g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 - 5, mmToPixel(this.y + this.height));
            g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + this.dividerSymbolDistance * 2 + 5, mmToPixel(this.y + this.height));
            g.stroke();
        }

        // DOORWINDOW WIDTH SYMBOL START
        g.beginPath();
        g.moveTo(mmToPixel(this.x) - leftExtensionSumSize, bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance);
        g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance);
        g.stroke();
        
        // left symbol
        g.beginPath();
        g.moveTo(mmToPixel(this.x) - leftExtensionSumSize, bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance - 5);
        g.lineTo(mmToPixel(this.x) - leftExtensionSumSize, bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance + 5);
        g.stroke();

        // width text
        g.fillText((this.width + this.getExtensionsSumSize('left') + this.getExtensionsSumSize('right')) / 100 + "mm", mmToPixel(this.x) - leftExtensionSumSize + (leftExtensionSumSize + rightExtensionSumSize + mmToPixel(this.width)) / 2, bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance - 5);

        // right symbol
        g.beginPath();
        g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance - 5);
        g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance + 5);
        g.stroke();
        // DOORWINDOW WIDTH SYMBOL END

        // left and right extension symbols
        var extensionSumSize = 0;
        if (leftExtensionSumSize + rightExtensionSumSize) {
            horizontalSymbolsBeforeDividers = 2;

            g.beginPath();
            g.moveTo(mmToPixel(this.x) - leftExtensionSumSize, bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2);
            g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2);
            g.stroke();
            
            // left symbol
            g.beginPath();
            g.moveTo(mmToPixel(this.x), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 - 5);
            g.lineTo(mmToPixel(this.x), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 + 5);
            g.stroke();
            
            // draw out left extensions' symbols
            extensionSumSize = 0;
            for (var i = 0; i < this.extensions.left.length; i++) {
                extensionSumSize += mmToPixel(this.extensions.left[i].size);

                g.beginPath();
                g.moveTo(mmToPixel(this.x) - extensionSumSize, bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 - 5);
                g.lineTo(mmToPixel(this.x) - extensionSumSize, bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 + 5);
                g.stroke();
            }

            // width text
            g.fillText(this.width / 100 + "mm", mmToPixel(this.x + this.width / 2), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 - 5);

            // draw out right extensions' symbols
            extensionSumSize = 0;
            for (var i = 0; i < this.extensions.right.length; i++) {
                extensionSumSize += mmToPixel(this.extensions.right[i].size);

                g.beginPath();
                g.moveTo(extensionSumSize + mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 - 5);
                g.lineTo(extensionSumSize + mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 + 5);
                g.stroke();
            }

            // right symbol
            g.beginPath();
            g.moveTo(mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 - 5);
            g.lineTo(mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + this.dividerSymbolDistance * 2 + 5);
            g.stroke();
        }

        var uniqueXSymbolPositions = this.getUniqueSymbolPositions()[0];
        var uniqueYSymbolPositions = this.getUniqueSymbolPositions()[1];

        // draw out horizontal divider symbols
        for (var i = 0; i < uniqueYSymbolPositions.length; i++) {
            g.beginPath();
            g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1), mmToPixel(this.y));
            g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1), mmToPixel(this.y + this.height));
            g.stroke();

            // start position symbol
            g.beginPath();
            g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1) - 5, mmToPixel(this.y));
            g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1) + 5, mmToPixel(this.y));
            g.stroke();

            // first text
            g.save();
            g.translate(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1) - 5, mmToPixel(this.y + uniqueYSymbolPositions[i] / 2));
            g.rotate(270 * Math.PI / 180);
            g.fillText(uniqueYSymbolPositions[i] / 100 + "mm", 0, 0);
            g.restore();

            // second text
            g.save();
            g.translate(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1) - 5, mmToPixel(this.y + uniqueYSymbolPositions[i]) + mmToPixel(this.height - uniqueYSymbolPositions[i]) / 2);
            g.rotate(270 * Math.PI / 180);
            g.fillText((this.height - uniqueYSymbolPositions[i]) / 100 + "mm", 0, 0);
            g.restore();

            // divider position symbol
            g.beginPath();
            g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1) - 5, mmToPixel(this.y + uniqueYSymbolPositions[i]));
            g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1) + 5, mmToPixel(this.y + uniqueYSymbolPositions[i]));
            g.stroke();

            // end position symbol
            g.beginPath();
            g.moveTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1) - 5, mmToPixel(this.y + this.height));
            g.lineTo(rightExtensionSumSize + mmToPixel(this.x + this.width) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (verticalSymbolsBeforeDividers + 1) + 5, mmToPixel(this.y + this.height));
            g.stroke();
        }

        // draw out vertical divider symbols
        for (var i = 0; i < uniqueXSymbolPositions.length; i++) {
            g.beginPath();
            g.moveTo(mmToPixel(this.x), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1));
            g.lineTo(mmToPixel(this.x) + mmToPixel(this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1));
            g.stroke();

            // start position symbol
            g.beginPath();
            g.moveTo(mmToPixel(this.x), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1) - 5);
            g.lineTo(mmToPixel(this.x), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1) + 5);
            g.stroke();

            // first text
            g.fillText(uniqueXSymbolPositions[i] / 100 + "mm", mmToPixel(this.x + uniqueXSymbolPositions[i] / 2), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1) - 5);

            // second text
            g.fillText((this.width - uniqueXSymbolPositions[i]) / 100 + "mm", mmToPixel(this.x + uniqueXSymbolPositions[i]) + mmToPixel(this.width - uniqueXSymbolPositions[i]) / 2, bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1) - 5);

            // divider position symbol
            g.beginPath();
            g.moveTo(mmToPixel(this.x + uniqueXSymbolPositions[i]), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1) - 5);
            g.lineTo(mmToPixel(this.x + uniqueXSymbolPositions[i]), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1) + 5);
            g.stroke();

            // end position symbol
            g.beginPath();
            g.moveTo(mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1) - 5);
            g.lineTo(mmToPixel(this.x + this.width), bottomExtensionSumSize + mmToPixel(this.y + this.height) + i * this.dividerSymbolDistance + this.dividerSymbolDistance * (horizontalSymbolsBeforeDividers + 1) + 5);
            g.stroke();
        }

        g.fillStyle = 'rgb(0, 100, 255)';
        if (this.extensionDragSide == 0) {
            g.fillRect(mmToPixel(this.x) - leftExtensionSumSize, mmToPixel(this.y - this.extensionDragSize) - topExtensionSumSize, mmToPixel(this.width) + leftExtensionSumSize + rightExtensionSumSize, mmToPixel(this.extensionDragSize));
            g.strokeRect(mmToPixel(this.x) - leftExtensionSumSize, mmToPixel(this.y - this.extensionDragSize) - topExtensionSumSize, mmToPixel(this.width) + leftExtensionSumSize + rightExtensionSumSize, mmToPixel(this.extensionDragSize));
        }

        if (this.extensionDragSide == 1) {
            g.fillRect(mmToPixel(this.x + this.width) + rightExtensionSumSize, mmToPixel(this.y), mmToPixel(this.extensionDragSize), mmToPixel(this.height));
            g.strokeRect(mmToPixel(this.x + this.width) + rightExtensionSumSize, mmToPixel(this.y), mmToPixel(this.extensionDragSize), mmToPixel(this.height));
        }

        if (this.extensionDragSide == 2) {
            g.fillRect(mmToPixel(this.x) - leftExtensionSumSize, mmToPixel(this.y + this.height) + bottomExtensionSumSize, mmToPixel(this.width) + leftExtensionSumSize + rightExtensionSumSize, mmToPixel(this.extensionDragSize));
            g.strokeRect(mmToPixel(this.x) - leftExtensionSumSize, mmToPixel(this.y + this.height) + bottomExtensionSumSize, mmToPixel(this.width) + leftExtensionSumSize + rightExtensionSumSize, mmToPixel(this.extensionDragSize));
        }

        if (this.extensionDragSide == 3) {
            g.fillRect(mmToPixel(this.x - this.extensionDragSize) - leftExtensionSumSize, mmToPixel(this.y), mmToPixel(this.extensionDragSize), mmToPixel(this.height));
            g.strokeRect(mmToPixel(this.x - this.extensionDragSize) - leftExtensionSumSize, mmToPixel(this.y), mmToPixel(this.extensionDragSize), mmToPixel(this.height));
        }

        g.fillStyle = this.color;

        // top extensions
        extensionSumSize = 0;
        for (var i = 0; i < this.extensions.top.length; i++) {
            if (this.extensions.top[i].selected) {
                g.fillStyle = "rgb(0, 100, 255)";
            } else {
                g.fillStyle = this.color;
            }

            var currentExtensionSize = this.extensions.top[i].size;
            extensionSumSize += this.extensions.top[i].size;

            g.fillRect(mmToPixel(this.x) - leftExtensionSumSize, mmToPixel(this.y - extensionSumSize), mmToPixel(this.width) + leftExtensionSumSize + rightExtensionSumSize, mmToPixel(currentExtensionSize));
            g.strokeRect(mmToPixel(this.x) - leftExtensionSumSize, mmToPixel(this.y - extensionSumSize), mmToPixel(this.width) + leftExtensionSumSize + rightExtensionSumSize, mmToPixel(currentExtensionSize));
        }
        
        // right extensions
        extensionSumSize = 0;
        for (var i = 0; i < this.extensions.right.length; i++) {
            if (this.extensions.right[i].selected) {
                g.fillStyle = "rgb(0, 100, 255)";
            } else {
                g.fillStyle = this.color;
            }

            var currentExtensionSize = this.extensions.right[i].size;

            g.fillRect(mmToPixel(this.x + this.width + extensionSumSize), mmToPixel(this.y), mmToPixel(currentExtensionSize), mmToPixel(this.height));
            g.strokeRect(mmToPixel(this.x + this.width + extensionSumSize), mmToPixel(this.y), mmToPixel(currentExtensionSize), mmToPixel(this.height));
            
            extensionSumSize += this.extensions.right[i].size;
        }

        // bottom extensions
        extensionSumSize = 0;
        for (var i = 0; i < this.extensions.bottom.length; i++) {
            var currentExtensionSize = this.extensions.bottom[i].size;
            if (this.extensions.bottom[i].selected) {
                g.fillStyle = "rgb(0, 100, 255)";
            } else {
                if (this.extensions.bottom[i].name.indexOf('Párkányfogadó') == -1) {
                    g.fillStyle = 'rgb(255, 255, 255)';
                } else {
                    g.fillStyle = 'rgb(175, 175, 175)';
                }
            }

            g.fillRect(mmToPixel(this.x) - leftExtensionSumSize, mmToPixel(this.y + this.height + extensionSumSize), mmToPixel(this.width) + leftExtensionSumSize + rightExtensionSumSize, mmToPixel(currentExtensionSize));
            g.strokeRect(mmToPixel(this.x) - leftExtensionSumSize, mmToPixel(this.y + this.height + extensionSumSize), mmToPixel(this.width) + leftExtensionSumSize + rightExtensionSumSize, mmToPixel(currentExtensionSize));
            g.fillStyle = 'rgb(255, 255, 255)';

            extensionSumSize += this.extensions.bottom[i].size;
        }

        // left extensions
        extensionSumSize = 0;this.getDoorWindowSizeWithSymbolsInPixels(global.zoom)[0] / 2
        for (var i = 0; i < this.extensions.left.length; i++) {
            if (this.extensions.left[i].selected) {
                g.fillStyle = "rgb(0, 100, 255)";
            } else {
                g.fillStyle = this.color;
            }

            var currentExtensionSize = this.extensions.left[i].size;
            extensionSumSize += this.extensions.left[i].size;

            g.fillRect(mmToPixel(this.x - extensionSumSize), mmToPixel(this.y), mmToPixel(currentExtensionSize), mmToPixel(this.height));
            g.strokeRect(mmToPixel(this.x - extensionSumSize), mmToPixel(this.y), mmToPixel(currentExtensionSize), mmToPixel(this.height));
        }

        // draw out wings
        for (var i = 0; i < this.wings.length; i++) {
            this.wings[i].drawout(g, mmToPixel(this.x), mmToPixel(this.y), this.dividerWidth, this.color);
        }

        // draw out outer frame line
        g.beginPath();
        g.moveTo(mmToPixel(this.x), mmToPixel(this.y + this.height));
        g.lineTo(mmToPixel(this.x), mmToPixel(this.y));
        g.lineTo(mmToPixel(this.x) + mmToPixel(this.width), mmToPixel(this.y));
        g.lineTo(mmToPixel(this.x) + mmToPixel(this.width), mmToPixel(this.y + this.height));
        
        if (this.doorstepType == 'Tok küszöb') {
            g.lineTo(mmToPixel(this.x), mmToPixel(this.y + this.height));
        }

        g.stroke();
    }

    setSize(newWidth, newHeight) {
        var widthDifference = newWidth / this.width;
        var heightDifference = newHeight / this.height;

        for (var i = 0; i < this.dividers.length; i++) {
            var extendedDivider = extendDividerToMatchWings(this.dividers[i], this.dividerWidth, this.frameWidth, this.width, this.height);            
            if (this.height !== newHeight && this.dividers[i][1] == this.dividers[i][3]) {
                // horizontal divider
                var dividerYPosition = this.dividers[i][1];

                // search connected wings
                for(var j = 0; j < this.wings.length; j++) {

                    if (this.wings[j].x > extendedDivider[2] || this.wings[j].x + this.wings[j].width < extendedDivider[0]) {
                        continue;
                    }

                    if (this.wings[j].y + this.wings[j].height == dividerYPosition) {
                        this.wings[j].setSize(this.wings[j].width, parseInt(dividerYPosition * heightDifference) - this.wings[j].y);
                    }

                    if (this.wings[j].y == dividerYPosition) {
                        this.wings[j].setSize(this.wings[j].width, this.wings[j].height - parseInt(dividerYPosition * heightDifference) + this.wings[j].y);
                        this.wings[j].setPosition(this.wings[j].x, parseInt(dividerYPosition * heightDifference));
                    }
                }

                // search connected vertical dividers
                for (var j = 0; j < this.dividers.length; j++) {
                    if (this.dividers[j][0] > extendedDivider[2] || this.dividers[j][2] < extendedDivider[0]
                        || this.dividers[j][0] != this.dividers[j][2]) {
                        continue;
                    }

                    if (this.dividers[j][1] == dividerYPosition + this.dividerWidth / 2) {
                        this.dividers[j][1] = parseInt(dividerYPosition * heightDifference) + this.dividerWidth / 2 ;
                    }

                    if (this.dividers[j][3] == dividerYPosition - this.dividerWidth / 2) {
                        this.dividers[j][3] = parseInt(dividerYPosition * heightDifference) - this.dividerWidth / 2 ;
                    }
                }

                this.dividers[i][1] = this.dividers[i][3] = parseInt(dividerYPosition * heightDifference);
            }

            if (this.width !== newWidth && this.dividers[i][0] == this.dividers[i][2]) {
                // vertical divider
                var dividerXPosition = this.dividers[i][0];

                // search connected wings
                for(var j = 0; j < this.wings.length; j++) {

                    if (this.wings[j].y > extendedDivider[3] || this.wings[j].y + this.wings[j].height < extendedDivider[1]) {
                        continue;
                    }

                    if (this.wings[j].x + this.wings[j].width == dividerXPosition) {
                        this.wings[j].setSize(parseInt(dividerXPosition * widthDifference) - this.wings[j].x, this.wings[j].height);
                    }

                    if (this.wings[j].x == dividerXPosition) {
                        this.wings[j].setSize(this.wings[j].width - parseInt(dividerXPosition * widthDifference) + this.wings[j].x, this.wings[j].height);
                        this.wings[j].setPosition(parseInt(dividerXPosition * widthDifference), this.wings[j].y);
                    }
                }

                // search connected horizontal dividers
                for (var j = 0; j < this.dividers.length; j++) {
                    if (this.dividers[j][1] > extendedDivider[3] || this.dividers[j][3] < extendedDivider[1]
                        || this.dividers[j][1] != this.dividers[j][3]) {
                        continue;
                    }

                    if (this.dividers[j][0] == dividerXPosition + this.dividerWidth / 2) {
                        this.dividers[j][0] = parseInt(dividerXPosition * widthDifference) + this.dividerWidth / 2 ;
                    }

                    if (this.dividers[j][2] == dividerXPosition - this.dividerWidth / 2) {
                        this.dividers[j][2] = parseInt(dividerXPosition * widthDifference) - this.dividerWidth / 2 ;
                    }
                }

                this.dividers[i][0] = this.dividers[i][2] = parseInt(dividerXPosition * widthDifference);
            }

            // resize divider if it's at the bottom edge of the doorwindow
            if (heightDifference !== 1 && this.dividers[i][0] == this.dividers[i][2] && this.dividers[i][3] == this.height - this.frameWidth) {
                this.dividers[i][3] = newHeight - this.frameWidth;
            }

            // resize divider if it's at the right edge of the doorwindow
            if (widthDifference !== 1 && this.dividers[i][1] == this.dividers[i][3] && this.dividers[i][2] == this.width - this.frameWidth) {
                this.dividers[i][2] = newWidth - this.frameWidth;
            }
        }

        // check for wings at bottom or right side of the doorwidow
        for (var i = 0; i < this.wings.length; i++) {
            if (heightDifference !== 1 && this.wings[i].y + this.wings[i].height == this.height) {
                this.wings[i].setSize(this.wings[i].width, newHeight - this.wings[i].y);

            }

            if (widthDifference !== 1 && this.wings[i].x + this.wings[i].width == this.width) {
                this.wings[i].setSize(newWidth - this.wings[i].x, this.wings[i].height);
            }
        }

        this.alignDividersToMm();
        // set new size for doorwindow
        this.width = newWidth;
        this.height = newHeight;
        this.changed();

        if (this.selectedWingIndex !== -1) {
            updateWingInput(this.wings[this.selectedWingIndex]);
        }
    }

    setDividerSize(newSize) {
        var oldSpace = this.dividerWidth / 2;
        var newSpace = newSize / 2;

        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical

                // check for connected horizontal dividers
                for (var j = 0; j < this.dividers.length; j++) {
                    if (this.dividers[j][1] == this.dividers[j][3] &&
                        this.dividers[j][1] > this.dividers[i][1] &&
                        this.dividers[j][3] < this.dividers[i][3]) {
                        if (this.dividers[j][0] == this.dividers[i][0] + oldSpace) {
                            this.dividers[j][0] = this.dividers[i][0] + newSpace;
                        }

                        if (this.dividers[j][2] == this.dividers[i][0] - oldSpace) {
                            this.dividers[j][2] = this.dividers[i][0] - newSpace;
                        }
                    }
                }
            } else {
                // horizontal

                // check for connected vertical dividers
                for (var j = 0; j < this.dividers.length; j++) {
                    if (this.dividers[j][0] == this.dividers[j][2] &&
                        this.dividers[j][0] > this.dividers[i][0] &&
                        this.dividers[j][2] < this.dividers[i][2]) {
                        if (this.dividers[j][1] == this.dividers[i][1] + oldSpace) {
                            this.dividers[j][1] = this.dividers[i][1] + newSpace;
                        }

                        if (this.dividers[j][3] == this.dividers[i][1] - oldSpace) {
                            this.dividers[j][3] = this.dividers[i][1] - newSpace;
                        }
                    }
                }
            }
        }

        this.dividerWidth = newSize;
    }

    autoPositionDividers() {
        var dividersCount = this.dividers.length;

        if (!dividersCount) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Nincsenek tokosztók a nyílászáróban.'});
            return;
        }

        // check if all dividers are horizontal or vertical
        var isAllVertical = true;
        var isAllHorizontal = true;
        var containsWingDivider = false;

        for (var i = 0; i < dividersCount; i++) {
            if (this.dividers[i][0] !== this.dividers[i][2]) {
                isAllVertical = false;
            }

            if (this.dividers[i][1] !== this.dividers[i][3]) {
                isAllHorizontal = false;
            }
        }

        for (var i = 0; i < this.wings.length; i ++) {
            if (this.wings[i].dividers.length) {
                containsWingDivider = true;
            }
        }

        if (!isAllVertical && !isAllHorizontal) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Ez a funkció csak azokra nyílászárókra alkalmazható, amelyekben kizárólag vízszintes vagy függőleges tokosztók vannak.'});
            return;
        }

        if (containsWingDivider) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Ez a funkció csak azokra nyílászárókra alkalmazható, amelyekben nincs szárnyosztó.'});
            return;
        }

        var glassesSumWidth = 0;
        var glassesSumHeight = 0;
        var glassesSizeBeforeLastOne = 0;
        for (var i = 0; i < this.wings.length; i ++) {
            var glassesSumSize = this.wings[i].getGlassesSumSize();
            glassesSumWidth += glassesSumSize[0];
            glassesSumHeight += glassesSumSize[1];
        }
        
        var singleGlassSize = parseInt(glassesSumHeight / (dividersCount + 1));
        if (isAllVertical) {
            singleGlassSize = parseInt(glassesSumWidth / (dividersCount + 1));
        }

        // reposition all dividers and wings to get same sized wings
        for (var i = 0; i < this.wings.length; i++) {
            if (isAllVertical) {
                //reposition wings
                if (i == this.wings.length - 1) {
                    singleGlassSize = glassesSumWidth - glassesSizeBeforeLastOne;
                }

                while (this.wings[i].getGlassesSumSize()[0] !== singleGlassSize) {
                    var difference = -1;

                    if (this.wings[i].getGlassesSumSize()[0] < singleGlassSize) {
                        difference = 1;
                    }

                    // reposition dividers after wing
                    for (var j = 0; j < this.dividers.length; j ++) {
                        if (this.dividers[j][0] < this.wings[i].x + this.wings[i].width) {
                            continue;
                        }
    
                        this.dividers[j][0] += difference;
                        this.dividers[j][2] += difference;
                    }

                    // reposition wings after the current wing
                    for (var j = 0; j < this.wings.length; j ++) {
                        if (this.wings[j].x < this.wings[i].x + this.wings[i].width) {
                            continue;
                        }
    
                        this.wings[j].setPosition(this.wings[j].x + difference, this.wings[j].y);
                    }

                    this.wings[i].setSize(this.wings[i].width + difference, this.wings[i].height);
                }

                glassesSizeBeforeLastOne += this.wings[i].getGlassesSumSize()[0];
            } else {
                //reposition wings
                if (i == this.wings.length - 1) {
                    singleGlassSize = glassesSumHeight - glassesSizeBeforeLastOne;
                }

                while (this.wings[i].getGlassesSumSize()[1] !== singleGlassSize) {
                    var difference = -1;

                    if (this.wings[i].getGlassesSumSize()[1] < singleGlassSize) {
                        difference = 1;
                    }

                    // reposition dividers after wing
                    for (var j = 0; j < this.dividers.length; j ++) {
                        if (this.dividers[j][1] < this.wings[i].y + this.wings[i].height) {
                            continue;
                        }
    
                        this.dividers[j][1] += difference;
                        this.dividers[j][3] += difference;
                    }

                    // reposition wings after the current wing
                    for (var j = 0; j < this.wings.length; j ++) {
                        if (this.wings[j].y < this.wings[i].y + this.wings[i].height) {
                            continue;
                        }
    
                        this.wings[j].setPosition(this.wings[j].x, this.wings[j].y + difference);
                    }

                    this.wings[i].setSize(this.wings[i].width, this.wings[i].height + difference);
                }

                glassesSizeBeforeLastOne += this.wings[i].getGlassesSumSize()[1];
            }
        }

        this.alignDividersToMm();
        this.unselectAllWingsAndDividersAndExtensions();
        this.changed();
    }

    autoPositionDividersByDividerDistance() {
        var dividersCount = this.dividers.length;

        if (!dividersCount) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Nincsenek tokosztók a nyílászáróban.'});
            return;
        }

        // check if all dividers are horizontal or vertical
        var isAllVertical = true;
        var isAllHorizontal = true;
        var containsWingDivider = false;

        for (var i = 0; i < dividersCount; i++) {
            if (this.dividers[i][0] !== this.dividers[i][2]) {
                isAllVertical = false;
            }

            if (this.dividers[i][1] !== this.dividers[i][3]) {
                isAllHorizontal = false;
            }
        }

        for (var i = 0; i < this.wings.length; i ++) {
            if (this.wings[i].dividers.length) {
                containsWingDivider = true;
            }
        }

        if (!isAllVertical && !isAllHorizontal) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Ez a funkció csak azokra nyílászárókra alkalmazható, amelyekben kizárólag vízszintes vagy függőleges tokosztók vannak.'});
            return;
        }

        if (containsWingDivider) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Ez a funkció csak azokra nyílászárókra alkalmazható, amelyekben nincs szárnyosztó.'});
            return;
        }

        var wingsSumSizeBeforeLastOne = 0;

        // reposition all dividers and wings to get same sized wings
        for (var i = 0; i < this.wings.length; i++) {
            if (isAllVertical) {
                var newWingSize = parseInt((this.width / (dividersCount + 1)) / 100) * 100;
                //reposition wings
                if (i == this.wings.length - 1) {
                    newWingSize = this.width - wingsSumSizeBeforeLastOne;
                }

                while (this.wings[i].width !== newWingSize) {
                    var difference = -1;

                    if (this.wings[i].width < newWingSize) {
                        difference = 1;
                    }

                    // reposition dividers after wing
                    for (var j = 0; j < this.dividers.length; j ++) {
                        if (this.dividers[j][0] < this.wings[i].x + this.wings[i].width) {
                            continue;
                        }
    
                        this.dividers[j][0] += difference;
                        this.dividers[j][2] += difference;
                    }

                    // reposition wings after the current wing
                    for (var j = 0; j < this.wings.length; j ++) {
                        if (this.wings[j].x < this.wings[i].x + this.wings[i].width) {
                            continue;
                        }
    
                        this.wings[j].setPosition(this.wings[j].x + difference, this.wings[j].y);
                    }

                    this.wings[i].setSize(this.wings[i].width + difference, this.wings[i].height);
                }

                wingsSumSizeBeforeLastOne += this.wings[i].width;
            } else {
                var newWingSize = parseInt((this.height / (dividersCount + 1)) / 100) * 100;
                //reposition wings
                if (i == this.wings.length - 1) {
                    newWingSize = this.height - wingsSumSizeBeforeLastOne;
                }

                while (this.wings[i].height !== newWingSize) {
                    var difference = -1;

                    if (this.wings[i].height < newWingSize) {
                        difference = 1;
                    }

                    // reposition dividers after wing
                    for (var j = 0; j < this.dividers.length; j ++) {
                        if (this.dividers[j][1] < this.wings[i].y + this.wings[i].height) {
                            continue;
                        }
    
                        this.dividers[j][1] += difference;
                        this.dividers[j][3] += difference;
                    }

                    // reposition wings after the current wing
                    for (var j = 0; j < this.wings.length; j ++) {
                        if (this.wings[j].y < this.wings[i].y + this.wings[i].height) {
                            continue;
                        }
    
                        this.wings[j].setPosition(this.wings[j].x, this.wings[j].y + difference);
                    }

                    this.wings[i].setSize(this.wings[i].width, this.wings[i].height + difference);
                }

                wingsSumSizeBeforeLastOne += this.wings[i].height;
            }
        }

        this.alignDividersToMm();
        this.unselectAllWingsAndDividersAndExtensions();
        this.changed();
    }

    autoPositionWingDividers() {
        if (this.selectedWingIndex == -1) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Nincs szárny kiválasztva.'});
            return;
        }

        if (this.wings[this.selectedWingIndex].autoPositionWingDividers()) {
            this.unselectAllWingsAndDividersAndExtensions();
            this.changed();
        };
    }

    alignDividersToMm() {
        for (var i = 0; i < this.dividers.length; i++) {
            this.selectedDividerIndex = i;
            if (this.dividers[i][0] == this.dividers[i][2]) {
                var difference = this.dividers[i][0] % 100;
                if (difference < 50) {
                    this.repositionSelectedDivider(this.dividers[i][0], this.dividers[i][0] - difference);
                } else {
                    difference = 100 - difference;
                    this.repositionSelectedDivider(this.dividers[i][0], this.dividers[i][0] + difference);
                }
            } else {
                var difference = this.dividers[i][1] % 100;
                if (difference < 50) {
                    this.repositionSelectedDivider(this.dividers[i][1], this.dividers[i][1] - difference);
                } else {
                    difference = 100 - difference;
                    this.repositionSelectedDivider(this.dividers[i][1], this.dividers[i][1] + difference);
                }
            }
        }

        for (var i = 0; i < this.wings.length; i++) {
            this.wings[i].alignDividersToMm();
        }
    }

    selectWingUnderMouse(mouseX, mouseY) {
        hideGlassInput();
        for (var i = 0; i < this.wings.length; i++) {
            var wingXPositionInPixels = mmToPixel(this.x + this.wings[i].x + this.wings[i].frameSpacing[3]);
            var wingYPositionInPixels = mmToPixel(this.y + this.wings[i].y + this.wings[i].frameSpacing[0]);
            var wingWidthInPixels = mmToPixel(this.wings[i].width - this.wings[i].frameSpacing[3] - this.wings[i].frameSpacing[1]);
            var wingHeightInPixels = mmToPixel(this.wings[i].height - this.wings[i].frameSpacing[0] - this.wings[i].frameSpacing[2]);
            
            // check if mouse under wing
            if (mouseX >= wingXPositionInPixels && mouseX <= wingXPositionInPixels + wingWidthInPixels 
                && mouseY >= wingYPositionInPixels && mouseY <= wingYPositionInPixels + wingHeightInPixels) {
                    this.wings[i].selected = true;
                    this.selectedWingIndex = i;
                    if (this.isInEditor) {
                        updateWingInput(this.wings[i]);
                    }
            }

            this.wings[i].selectGlassUnderMouse(pixelToMm(mouseX) - this.x, pixelToMm(mouseY) - this.y);
            
            this.wings[i].selectWingDividerUnderMouse(pixelToMm(mouseX) - this.x, pixelToMm(mouseY) - this.y);
        }
    }

    selectDividerUnderMouse(mouseX, mouseY) {
        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][1] == this.dividers[i][3]) {
                // horizontal
                if (mouseY > mmToPixel(this.y + this.dividers[i][1] - this.dividerWidth / 2) &&
                    mouseY < mmToPixel(this.y + this.dividers[i][1] + this.dividerWidth / 2) &&
                    mouseX > mmToPixel(this.x + this.dividers[i][0]) &&
                    mouseX < mmToPixel(this.x + this.dividers[i][2])) {
                        
                    // if mouse is under divider
                    this.selectedDividerIndex = i;
                    break;
                }
            } else {
                // vertical
                if (mouseX > mmToPixel(this.x + this.dividers[i][0] - this.dividerWidth / 2) &&
                    mouseX < mmToPixel(this.x + this.dividers[i][0] + this.dividerWidth / 2) &&
                    mouseY > mmToPixel(this.y + this.dividers[i][1]) &&
                    mouseY < mmToPixel(this.y + this.dividers[i][3])) {
                        
                    // if mouse is under divider
                    this.selectedDividerIndex = i;
                    break;
                }
            }
        }

        if (this.isInEditor) {
            this.updateDividerInputValues();
        }
    }

    selectExtensionUnderMouse(mouseX, mouseY) {
        var leftExtensionsSumSize = this.getExtensionsSumSize('left');
        var rightExtensionsSumSize = this.getExtensionsSumSize('right');
        var sumExtensionSize = 0;
        
        // top extensions
        for (var i = 0; i < this.extensions.top.length; i ++) {
            if (mouseX >= mmToPixel(this.x - leftExtensionsSumSize) && mouseX <= mmToPixel(this.x + this.width + rightExtensionsSumSize) &&
                mouseY >= mmToPixel(this.y - sumExtensionSize - this.extensions.top[i].size) &&
                mouseY <= mmToPixel(this.y - sumExtensionSize)) {
                    this.extensions.top[i].selected = true;
            }

            sumExtensionSize += this.extensions.top[i].size;
        }

        // bottom extensions
        sumExtensionSize = 0;
        for (var i = 0; i < this.extensions.bottom.length; i ++) {
            if (mouseX >= mmToPixel(this.x - leftExtensionsSumSize) && mouseX <= mmToPixel(this.x + this.width + rightExtensionsSumSize) &&
                mouseY >= mmToPixel(this.y + this.height + sumExtensionSize) &&
                mouseY <= mmToPixel(this.y + this.height + sumExtensionSize + this.extensions.bottom[i].size)) {
                    this.extensions.bottom[i].selected = true;
            }

            sumExtensionSize += this.extensions.bottom[i].size;
        }

        // right extensions
        sumExtensionSize = 0;
        for (var i = 0; i < this.extensions.right.length; i ++) {
            if (mouseY >= mmToPixel(this.y) && mouseY <= mmToPixel(this.y + this.height) &&
                mouseX >= mmToPixel(this.x + this.width + sumExtensionSize) &&
                mouseX <= mmToPixel(this.x + this.width + sumExtensionSize + this.extensions.right[i].size)) {
                    this.extensions.right[i].selected = true;
            }

            sumExtensionSize += this.extensions.right[i].size;
        }

        // left extensions
        sumExtensionSize = 0;
        for (var i = 0; i < this.extensions.left.length; i ++) {
            if (mouseY >= mmToPixel(this.y) && mouseY <= mmToPixel(this.y + this.height) &&
                mouseX >= mmToPixel(this.x - sumExtensionSize - this.extensions.left[i].size) &&
                mouseX <= mmToPixel(this.x - sumExtensionSize)) {
                    this.extensions.left[i].selected = true;
            }

            sumExtensionSize += this.extensions.left[i].size;
        }
    }

    checkDeletableSelectedObjects() {
        var isDeletable = false;

        // check doorwindow dividers
        if (this.selectedDividerIndex !== -1) {
            var isDoorwindowDividerDeletable = true;
            if (this.dividers[this.selectedDividerIndex][0] == this.dividers[this.selectedDividerIndex][2]) {
                // vertical
                for (var i = 0; i < this.dividers.length; i ++) {
                    if (this.dividers[i][1] == this.dividers[i][3] &&
                        this.dividers[i][1] >= this.dividers[this.selectedDividerIndex][1] &&
                        this.dividers[i][1] <= this.dividers[this.selectedDividerIndex][3] && (
                        this.dividers[i][0] == this.dividers[this.selectedDividerIndex][0] + this.dividerWidth / 2 ||
                        this.dividers[i][2] == this.dividers[this.selectedDividerIndex][0] - this.dividerWidth / 2)) {
                            isDoorwindowDividerDeletable = false;
                    }
                }
            } else {
                // horizontal
                for (var i = 0; i < this.dividers.length; i ++) {
                    if (this.dividers[i][0] == this.dividers[i][2] &&
                        this.dividers[i][0] >= this.dividers[this.selectedDividerIndex][0] &&
                        this.dividers[i][0] <= this.dividers[this.selectedDividerIndex][2] && (
                        this.dividers[i][1] == this.dividers[this.selectedDividerIndex][1] + this.dividerWidth / 2 ||
                        this.dividers[i][3] == this.dividers[this.selectedDividerIndex][1] - this.dividerWidth / 2)) {
                            isDoorwindowDividerDeletable = false;
                    }
                }
            }

            if (isDoorwindowDividerDeletable) {
                isDeletable = true;
            }
        }

        // check wing dividers
        for (var i = 0; i < this.wings.length; i++) {
            if (this.wings[i].isSelectedDividerDeletable()) {
                isDeletable = true;
            }
        }

        // check extensions
        for (var i = 0; i < this.extensions.top.length; i++) {
            if (this.extensions.top[i].selected) {
                isDeletable = true;
            }
        }

        for (var i = 0; i < this.extensions.right.length; i++) {
            if (this.extensions.right[i].selected) {
                isDeletable = true;
            }
        }

        for (var i = 0; i < this.extensions.bottom.length; i++) {
            if (this.extensions.bottom[i].selected) {
                isDeletable = true;
            }
        }

        for (var i = 0; i < this.extensions.left.length; i++) {
            if (this.extensions.left[i].selected) {
                isDeletable = true;
            }
        }
        
        updateDeleteButton(isDeletable);
    }

    deleteSelectedObject() {
        for (var i = 0; i < this.wings.length; i ++) {
            this.wings[i].deleteSelectedObject();
        }

        // delete extension
        var extensionDeleted = false;
        for (var i = 0; i < this.extensions.top.length; i++) {
            if (this.extensions.top[i].selected) {
                this.extensions.top.splice(i, 1);
            }
        }

        for (var i = 0; i < this.extensions.right.length; i++) {
            if (this.extensions.right[i].selected) {
                this.extensions.right.splice(i, 1);
            }
        }

        for (var i = 0; i < this.extensions.bottom.length; i++) {
            if (this.extensions.bottom[i].selected) {
                this.extensions.bottom.splice(i, 1);
            }
        }

        for (var i = 0; i < this.extensions.left.length; i++) {
            if (this.extensions.left[i].selected) {
                this.extensions.left.splice(i, 1);
            }
        }

        // delete doorwindow divider
        if (this.selectedDividerIndex == -1) {
            this.changed();
            return;
        }

        var selectedDividerExtended = extendDividerToMatchWings(this.dividers[this.selectedDividerIndex], this.dividerWidth, this.frameWidth, this.width, this.height);
        if (this.dividers[this.selectedDividerIndex][0] == this.dividers[this.selectedDividerIndex][2]) {
            // vertical
            var deletedWingWidth = 0;
            // delete second wing
            for (var i = 0; i < this.wings.length; i++) {
                if (this.wings[i].x == selectedDividerExtended[0] + this.dividerWidth / 2 &&
                    this.wings[i].y == selectedDividerExtended[1] &&
                    this.wings[i].y + this.wings[i].height == selectedDividerExtended[3]) {
                        deletedWingWidth = this.wings[i].width;
                        this.wings.splice(i, 1);
                    }
            }

            // extend first wing
            for (var i = 0; i < this.wings.length; i++) {
                if (this.wings[i].x + this.wings[i].width == selectedDividerExtended[0] + this.dividerWidth / 2 &&
                    this.wings[i].y == selectedDividerExtended[1] &&
                    this.wings[i].y + this.wings[i].height == selectedDividerExtended[3]) {
                        this.wings[i].setSize(this.wings[i].width + deletedWingWidth, this.wings[i].height);
                    }
            }

            this.dividers.splice(this.selectedDividerIndex, 1);
            this.selectedDividerIndex = -1;
        } else {
            // horizontal
            var deletedWingHeight = 0;
            // delete second wing
            for (var i = 0; i < this.wings.length; i++) {
                if (this.wings[i].y == selectedDividerExtended[1] + this.dividerWidth / 2 &&
                    this.wings[i].x == selectedDividerExtended[0] &&
                    true) {
                        
                        deletedWingHeight = this.wings[i].height;
                        this.wings.splice(i, 1);
                    }
            }

            // extend first wing
            for (var i = 0; i < this.wings.length; i++) {
                if (this.wings[i].y + this.wings[i].height == selectedDividerExtended[1] + this.dividerWidth / 2 &&
                    this.wings[i].x == selectedDividerExtended[0] &&
                    this.wings[i].x + this.wings[i].width == selectedDividerExtended[2]) {
                        this.wings[i].setSize(this.wings[i].width, this.wings[i].height + deletedWingHeight);
                    }
            }

            this.dividers.splice(this.selectedDividerIndex, 1);
            this.selectedDividerIndex = -1;
        }

        this.selectedDividerIndex = this.selectedWingIndex = -1;
        this.recalculateFrameSpacingAndFrameWidth();
        this.changed();
    }

    setAdditionalParts(additionalParts) {
        this.additionalParts = additionalParts;
        this.changed();
    }
    
    setDoorwindowQuantity(quantity) {
        this.quantity = quantity;
        this.changed();
    }

    setDoorwindowType(doorwindowType) {
        this.frameType = doorwindowType;

        var newFrameWidth = global.settings.windowFrameWidth;
        if (doorwindowType == 'Ajtó') {
            newFrameWidth = global.settings.doorFrameWidth;
        }

        // resize dividers because door frame size changed
        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.frameWidth) {
                this.dividers[i][0] = newFrameWidth;
            }

            if (this.dividers[i][2] == this.width - this.frameWidth) {
                this.dividers[i][2] = this.width - newFrameWidth;
            }

            if (this.dividers[i][1] == this.frameWidth) {
                this.dividers[i][1] = newFrameWidth;
            }

            if (this.dividers[i][3] == this.height - this.frameWidth) {
                this.dividers[i][3] = this.height - newFrameWidth;
            }
        }

        this.frameWidth = newFrameWidth;
        this.recalculateFrameSpacingAndFrameWidth();
        this.changed();
    }

    setDoorwindowDoorstep(doorstepType) {
        this.doorstepType = doorstepType;
        this.recalculateFrameSpacingAndFrameWidth();
        this.changed();
    }

    setDoorwindowColor(color) {
        this.color = color;
        this.changed();
    }

    setSelectedWingOpeningMode(openingMode) {
        if (this.selectedWingIndex == -1) {
            return;
        }

        var selectedWing = this.wings[this.selectedWingIndex];
        selectedWing.setOpeningMode(openingMode);
        selectedWing.updateHandle();

        this.recalculateFrameSpacingAndFrameWidth();
        this.changed();
        if (this.isInEditor) {
            updateWingInput(selectedWing);
        }
    }

    setSelectedWingOpeningSide(openingSide) {
        if (this.selectedWingIndex == -1) {
            return;
        }

        var selectedWing = this.wings[this.selectedWingIndex];

        selectedWing.openingSide = openingSide;
        selectedWing.updateHandle();
        this.changed();
    }

    setSelectedWingHinge(hinge) {
        if (this.selectedWingIndex == -1) {
            return;
        }

        var selectedWing = this.wings[this.selectedWingIndex];
        selectedWing.hingeType = hinge;
        this.changed();
    }

    setSelectedWingFittings(fittings) {
        if (this.selectedWingIndex == -1) {
            return;
        }

        var selectedWing = this.wings[this.selectedWingIndex];
        selectedWing.fittings = fittings;
        this.changed();
    }

    setSelectedWingKfnyDividerPosition(kfnyDividerPosition) {
        if (this.selectedWingIndex == -1) {
            return;
        }

        var selectedWing = this.wings[this.selectedWingIndex];
        selectedWing.setKfnyDivider(kfnyDividerPosition);
        this.changed();
    }

    setSelectedGlassAttributes(glassType, glassWidth, glassFrame) {
        if (this.selectedWingIndex == -1) {
            return;
        }

        this.wings[this.selectedWingIndex].setSelectedGlassAttributes(glassType, glassWidth, glassFrame);

        this.changed();
    }

    setAllGlassAttributes(glassType, glassWidth, glassFrame) {
        for (var i = 0; i < this.wings.length; i++) {
            this.wings[i].setAllGlassAttributes(glassType, glassWidth, glassFrame);
        }

        this.changed();
    }

    setSelectedWingFrameType(frameType) {
        if (this.selectedWingIndex == -1) {
            return;
        }

        var selectedWing = this.wings[this.selectedWingIndex];
        selectedWing.frameType = frameType;
        this.recalculateFrameSpacingAndFrameWidth();
        this.changed();
    }

    setSelectedWingHandle(handleType) {
        if (this.selectedWingIndex == -1) {
            return;
        }

        var selectedWing = this.wings[this.selectedWingIndex];
        selectedWing.setHandleType(handleType);
        this.changed();
    }    

    setManualPriceCalculation(manualPriceCalculation) {
        this.manualPriceCalculation = manualPriceCalculation;
    }

    setProfit(profit) {
        this.profit = profit;
        this.changed();
    }

    setWage(wage) {
        this.wage = wage;
        this.changed();
    }

    setFittingsPrice(fittingsPrice) {
        this.fittingsPrice = fittingsPrice;
        this.changed();
    }

    setSelectedWingDividerPosition(oldPosition, newPosition) {
        for (var i = 0; i < this.wings.length; i++) {
            if (this.wings[i].selectedDividerIndex !== -1) {
                this.wings[i].setSelectedWingDividerPosition(oldPosition, newPosition);
            }
        }
        
        this.changed();
    }

    // updates the doorwindow size inputs
    // it doesn't let the doorwindow size to be smaller 
    // than it's the last divider
    updateDoorwindowSizeInputValues() {
        var currentWidth = this.width;
        var currentHeight = this.height;

        // find the minimum size that the doorwindow can be resized to
        var minimumWidth = 0;
        var minimumHeight = 0;

        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                if (this.dividers[i][0] > minimumWidth) {
                    minimumWidth = this.dividers[i][0];
                }
            } else {
                // horizontal
                if (this.dividers[i][1] > minimumHeight) {
                    minimumHeight = this.dividers[i][1];
                }
            }
        }

        if (this.isInEditor) {
            updateDoorwindowInputs(currentWidth, currentHeight, minimumWidth, minimumHeight);
        }
    }

    // updates the input field value, minimum and maximum attributes
    // based on the currently selected divider
    updateDividerInputValues() {
        if (!this.isInEditor) {
            return;
        }

        if (this.selectedDividerIndex == -1) {
            return;
        }

        var selectedDivider = this.dividers[this.selectedDividerIndex];
        var currentPosition;
        var minimumPosition = 0;
        var maximumPosition;
        if (selectedDivider[0] == selectedDivider[2]) {
            // vertical
            currentPosition = selectedDivider[0];
            maximumPosition = this.width;
            for (var i = 0; i < this.dividers.length; i++) {
                if (i == this.selectedDividerIndex || this.dividers[i][1] == this.dividers[i][3]) {
                    continue;
                }

                // look for the minimum value the divider can be repositioned 
                if (this.dividers[i][0] < selectedDivider[0] && this.dividers[i][0] > minimumPosition &&
                    ((this.dividers[i][1] >= selectedDivider[1] && this.dividers[i][3] <= selectedDivider[3]) ||
                    (this.dividers[i][1] <= selectedDivider[1] && this.dividers[i][3] >= selectedDivider[3]))) {
                    minimumPosition = this.dividers[i][0];
                }

                // look for the maximum value the divider can be repositioned 
                if (this.dividers[i][0] > selectedDivider[0] && this.dividers[i][0] < maximumPosition &&
                    ((this.dividers[i][1] >= selectedDivider[1] && this.dividers[i][3] <= selectedDivider[3]) ||
                    (this.dividers[i][1] <= selectedDivider[1] && this.dividers[i][3] >= selectedDivider[3]))) {
                    maximumPosition = this.dividers[i][0];
                }
            }
        } else {
            // horizontal
            currentPosition = selectedDivider[1];
            maximumPosition = this.height;
            for (var i = 0; i < this.dividers.length; i++) {
                if (i == this.selectedDividerIndex || this.dividers[i][0] == this.dividers[i][2]) {
                    continue;
                }

                // look for the minimum value the divider can be repositioned 
                if (this.dividers[i][1] < selectedDivider[1] && this.dividers[i][1] > minimumPosition &&
                    ((this.dividers[i][0] >= selectedDivider[0] && this.dividers[i][2] <= selectedDivider[2]) ||
                    (this.dividers[i][0] <= selectedDivider[0] && this.dividers[i][2] >= selectedDivider[2]))) {
                    minimumPosition = this.dividers[i][1];
                }
                
                // look for the maximum value the divider can be repositioned 
                if (this.dividers[i][1] > selectedDivider[1] && this.dividers[i][1] < maximumPosition &&
                    ((this.dividers[i][0] >= selectedDivider[0] && this.dividers[i][2] <= selectedDivider[2]) ||
                    (this.dividers[i][0] <= selectedDivider[0] && this.dividers[i][2] >= selectedDivider[2]))) {
                    maximumPosition = this.dividers[i][1];
                }
            }
        }

        updateDividerInput(currentPosition, minimumPosition + 1000, maximumPosition - 1000);
    }

    repositionSelectedDivider(oldPosition, newPosition) {
        if (oldPosition == newPosition) {
            return;
        }

        var selectedDivider = this.dividers[this.selectedDividerIndex];
        var selectedDividerDirection = 'horizontal';

        if (selectedDivider[0] == selectedDivider[2]) {
            selectedDividerDirection = 'vertical';
        }

        // reposition the selected divider
        if (selectedDividerDirection == 'horizontal') {
            this.dividers[this.selectedDividerIndex][1] = newPosition;
            this.dividers[this.selectedDividerIndex][3] = newPosition;
        } else {
            this.dividers[this.selectedDividerIndex][0] = newPosition;
            this.dividers[this.selectedDividerIndex][2] = newPosition;
        }
        
        // reposition the dividers which are next to the selected divider
        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2] && selectedDividerDirection == 'horizontal'
                && this.dividers[i][0] >= selectedDivider[0] && this.dividers[i][2] <= selectedDivider[2]) {
                // vertical
                if (this.dividers[i][1] == oldPosition + this.dividerWidth / 2) {
                    this.dividers[i][1] = newPosition + this.dividerWidth / 2;
                }

                if (this.dividers[i][3] == oldPosition - this.dividerWidth / 2) {
                    this.dividers[i][3] = newPosition - this.dividerWidth / 2;
                }
            }
            if (this.dividers[i][1] == this.dividers[i][3] && selectedDividerDirection == 'vertical'
                && this.dividers[i][1] >= selectedDivider[1] && this.dividers[i][3] <= selectedDivider[3]) {
                // horizontal
                if (this.dividers[i][0] == oldPosition + this.dividerWidth / 2) {
                    this.dividers[i][0] = newPosition + this.dividerWidth / 2;
                    
                }
                
                if (this.dividers[i][2] == oldPosition - this.dividerWidth / 2) {
                    this.dividers[i][2] = newPosition - this.dividerWidth / 2;
                }
            }
        }

        // match divider's position to frame spacing
        var selectedDividerExtended = extendDividerToMatchWings(selectedDivider, this.dividerWidth, this.frameWidth, this.width, this.height);
        
        // reposition wings which are next to the divider
        for (var i = 0; i < this.wings.length; i++) {
            if (selectedDividerDirection == 'horizontal'
                && this.wings[i].x >= selectedDividerExtended[0]
                && this.wings[i].x <= selectedDividerExtended[2]
                && this.wings[i].x + this.wings[i].width >= selectedDividerExtended[0]
                && this.wings[i].x + this.wings[i].width <= selectedDividerExtended[2]) {
                
                if (this.wings[i].y == oldPosition) {
                    this.wings[i].setSize(this.wings[i].width, this.wings[i].height + oldPosition - newPosition);
                    this.wings[i].setPosition(this.wings[i].x, newPosition);
                }

                if (this.wings[i].y + this.wings[i].height == oldPosition) {
                    this.wings[i].setSize(this.wings[i].width, newPosition - this.wings[i].y);
                }
            }

            if (selectedDividerDirection == 'vertical'
                && this.wings[i].y >= selectedDividerExtended[1]
                && this.wings[i].y <= selectedDividerExtended[3]
                && this.wings[i].y + this.wings[i].height >= selectedDividerExtended[1]
                && this.wings[i].y + this.wings[i].height <= selectedDividerExtended[3]) {

                if (this.wings[i].x == oldPosition) {
                    this.wings[i].setSize(this.wings[i].width + oldPosition - newPosition, this.wings[i].height);
                    this.wings[i].setPosition(newPosition, this.wings[i].y);
                }

                if (this.wings[i].x + this.wings[i].width == oldPosition) {
                    this.wings[i].setSize(newPosition - this.wings[i].x, this.wings[i].height);
                }
            }
        }

        if (this.isInEditor) {
            this.updateDoorwindowSizeInputValues();
        }

        this.changed();
    }

    unselectAllWingsAndDividersAndExtensions() {
        this.selectedDividerIndex = -1;
        this.selectedWingIndex = -1;

        for (var i = 0; i < this.wings.length; i++) {
            this.wings[i].selected = false;
        }

        for (var i = 0; i < this.extensions.top.length; i++) {
            this.extensions.top[i].selected = false;
        }

        for (var i = 0; i < this.extensions.right.length; i++) {
            this.extensions.right[i].selected = false;
        }

        for (var i = 0; i < this.extensions.bottom.length; i++) {
            this.extensions.bottom[i].selected = false;
        }

        for (var i = 0; i < this.extensions.left.length; i++) {
            this.extensions.left[i].selected = false;
        }
    }

    dividerDragOver(mouseX, mouseY, dividerDirection) {
        for (var i = 0; i < this.wings.length; i++) {
            var wingXPositionInPixels = mmToPixel(this.x + this.wings[i].x);
            var wingYPositionInPixels = mmToPixel(this.y + this.wings[i].y);
            var wingWidthInPixels = mmToPixel(this.wings[i].width);
            var wingHeightInPixels = mmToPixel(this.wings[i].height);

            if (mouseX >= wingXPositionInPixels && mouseX <= wingXPositionInPixels + wingWidthInPixels 
                && mouseY >= wingYPositionInPixels && mouseY <= wingYPositionInPixels + wingHeightInPixels) {
                    this.wings[i].dividerDirection = dividerDirection;

                    if (dividerDirection == 'horizontal') {
                        this.wings[i].dividerPosition = pixelToMm(mouseY) - this.y - this.wings[i].y;
                    } else {
                        this.wings[i].dividerPosition = pixelToMm(mouseX) - this.x - this.wings[i].x;
                    }
            } else {
                this.wings[i].dividerDirection = '';
                this.wings[i].dividerPosition = -1;
            }
        }
    }

    extensionDragOver(mouseX, mouseY, extensionDragSize, extensionDragName) {
        var newExtensonDragSide = -1;
        if (mouseX < mmToPixel(this.x) && mouseY > mmToPixel(this.y) && mouseY < mmToPixel(this.y + this.height)) {
            newExtensonDragSide = 3;
        } else if (mouseX > mmToPixel(this.x + this.width) && mouseY > mmToPixel(this.y) &&
            mouseY < mmToPixel(this.y + this.height)) {
            newExtensonDragSide = 1;
        } else if (mouseY < mmToPixel(this.y) && mouseX > mmToPixel(this.x) && mouseX < mmToPixel(this.x + this.width)) {
            newExtensonDragSide = 0;
        } else if (mouseY > mmToPixel(this.y + this.height) && mouseX > mmToPixel(this.x) &&
            mouseX < mmToPixel(this.x + this.width)) {
            newExtensonDragSide = 2;
        } else {
            newExtensonDragSide = -1;
            this.extensionDragSize = -1;
        }

        if (newExtensonDragSide == 3 && this.extensionDragSide !== 3) {
            this.x += extensionDragSize;
        }

        if (newExtensonDragSide == 0 && this.extensionDragSide !== 0) {
            this.y += extensionDragSize;
        }

        if (newExtensonDragSide !== 3 && this.extensionDragSide == 3) {
            this.x -= extensionDragSize;
        }

        if (newExtensonDragSide !== 0 && this.extensionDragSide == 0) {
            this.y -= extensionDragSize;
        }

        this.extensionDragSide = newExtensonDragSide
        this.extensionDragSize = extensionDragSize;
        this.extensionDragName = extensionDragName;
    }

    wingDividerDragOver(mouseX, mouseY, dividerDirection, kfnyMultipleDivision) {
        for (var i = 0; i < this.wings.length; i++) {
            var wingXPositionInPixels = mmToPixel(this.x + this.wings[i].x);
            var wingYPositionInPixels = mmToPixel(this.y + this.wings[i].y);
            var wingWidthInPixels = mmToPixel(this.wings[i].width);
            var wingHeightInPixels = mmToPixel(this.wings[i].height);

            this.wings[i].unsetWingDividerDrag();

            if (mouseX >= wingXPositionInPixels && mouseX <= wingXPositionInPixels + wingWidthInPixels 
                && mouseY >= wingYPositionInPixels && mouseY <= wingYPositionInPixels + wingHeightInPixels) {
                    this.wings[i].wingDividerDragOver(this.x, this.y, mouseX, mouseY, dividerDirection, kfnyMultipleDivision);
            }
        }
    }

    extensionDrop(extensionIsInSize, extensionName) {
        switch (this.extensionDragSide) {
            case 0: 
                this.extensions.top.push({
                    size: this.extensionDragSize,
                    name: extensionName,
                    position: 'felső',
                    selected: false,
                });

                if (extensionIsInSize) {
                    this.setSize(this.width, this.height - this.extensionDragSize);
                }
            break;
            case 1:
                this.extensions.right.push({
                    size: this.extensionDragSize,
                    name: extensionName,
                    position: 'jobb',
                    selected: false,
                });

                if (extensionIsInSize) {
                    this.setSize(this.width - this.extensionDragSize, this.height);
                }
            break;
            case 2:
                this.extensions.bottom.push({
                    size: this.extensionDragSize,
                    name: extensionName,
                    position: 'alsó',
                    selected: false,
                });

                if (extensionIsInSize) {
                    this.setSize(this.width, this.height - this.extensionDragSize);
                }
            break;
            case 3:
                this.extensions.left.push({
                    size: this.extensionDragSize,
                    name: extensionName,
                    position: 'bal',
                    selected: false,
                });

                if (extensionIsInSize) {
                    this.setSize(this.width - this.extensionDragSize, this.height);
                }
            break;
        }

        this.extensionDragSide = -1;
        this.extensionDragSize = -1;

        this.updateDoorwindowSizeInputValues();
        this.changed();
    }

    dividerDrop() {
        for (var i = 0; i < this.wings.length; i++) {
            if (this.wings[i].dividerPosition != -1) {
                var wingXPosition = this.wings[i].x;
                var wingYPosition = this.wings[i].y;
                var wingWidth = this.wings[i].width;
                var wingHeight = this.wings[i].height;
                var wingDividerPosition = parseInt(this.wings[i].dividerPosition / 100) * 100;
                var wingFrameType = this.wings[i].frameType;
                var wingOpeningMode = this.wings[i].openingMode;
                var wingOpeningSide = this.wings[i].openingSide;
                var wingHandle = this.wings[i].handle.type;
                var wingHingeType = this.wings[i].hingeType;
                var wingFittings = this.wings[i].fittings;
                var currentGlassType = this.wings[i].glasses[0].glassType;
                var currentGlassWidth = this.wings[i].glasses[0].glassWidth;
                var currentGlassFrame = this.wings[i].glasses[0].glassFrame;
                

                if (this.wings[i].dividerDirection == 'horizontal') {
                    // divide wing into 2
                    var wing1 = new Wing(wingOpeningMode, wingOpeningSide, wingXPosition, wingYPosition, wingWidth, wingDividerPosition, wingFrameType);
                    wing1.setAllGlassAttributes(currentGlassType, currentGlassWidth, currentGlassFrame);
                    var wing2 = new Wing(wingOpeningMode, wingOpeningSide, wingXPosition, wingYPosition + wingDividerPosition, wingWidth, wingHeight - wingDividerPosition, wingFrameType);
                    wing2.setAllGlassAttributes(currentGlassType, currentGlassWidth, currentGlassFrame);
                    this.wings.splice(i, 1, wing1);
                    this.wings.splice(i, 0, wing2);
                    wing1.hingeType = wingHingeType;
                    wing1.fittings = wingFittings;
                    wing1.setHandleType(wingHandle);
                    wing2.hingeType = wingHingeType;
                    wing2.fittings = wingFittings;
                    wing2.setHandleType(wingHandle);

                    // check if the divider's ends are at the frame of the DoorWindow or at an other divider
                    var leftDividerSpacing = !wingXPosition ? this.frameWidth : this.dividerWidth / 2;
                    var rightDividerSpacing = (wingXPosition + wingWidth == this.width) ? this.frameWidth : this.dividerWidth / 2;

                    // add divider to collection
                    this.dividers.push([wingXPosition + leftDividerSpacing, wingYPosition + wingDividerPosition, wingXPosition + wingWidth - rightDividerSpacing, wingYPosition + wingDividerPosition]);
                } else {
                    // divide wing into 2
                    var wing1 = new Wing(wingOpeningMode, wingOpeningSide, wingXPosition, wingYPosition, wingDividerPosition, wingHeight, wingFrameType);
                    wing1.setAllGlassAttributes(currentGlassType, currentGlassWidth, currentGlassFrame);
                    var wing2 = new Wing(wingOpeningMode, wingOpeningSide, wingXPosition + wingDividerPosition, wingYPosition, wingWidth - wingDividerPosition, wingHeight, wingFrameType);
                    wing2.setAllGlassAttributes(currentGlassType, currentGlassWidth, currentGlassFrame);
                    this.wings.splice(i, 1, wing1);
                    this.wings.splice(i, 0, wing2);
                    wing1.hingeType = wingHingeType;
                    wing1.fittings = wingFittings;
                    wing1.setHandleType(wingHandle);
                    wing2.hingeType = wingHingeType;
                    wing2.fittings = wingFittings;
                    wing2.setHandleType(wingHandle);

                    // check if the divider's ends are at the frame of the DoorWindow or at an other divider
                    var topDividerSpacing = !wingYPosition ? this.frameWidth : this.dividerWidth / 2;
                    var bottomDividerSpacing = (wingYPosition + wingHeight == this.height) ? this.frameWidth : this.dividerWidth / 2;

                    // add divider to collection
                    this.dividers.push([wingXPosition + wingDividerPosition, wingYPosition + topDividerSpacing, wingXPosition + wingDividerPosition, wingYPosition + wingHeight - bottomDividerSpacing]);
                }
                
                this.selectedDividerIndex = -1;
                this.selectedWingIndex = -1;
                break;
            }
        }

        this.recalculateFrameSpacingAndFrameWidth();
        if (this.isInEditor) {
            this.updateDividerInputValues();
            this.updateDoorwindowSizeInputValues();
        }
        this.changed();
    }

    wingDividerDrop() {
        for (var i = 0; i < this.wings.length; i++) {
            this.wings[i].wingDividerDrop();
        }

        this.changed();
    }

    // calculates the space betweend the outside edge of the wing's frame
    // and the divider or DoorWindow's frame
    recalculateFrameSpacingAndFrameWidth() {
        var frameSpacingAtDoorwindowFrame = 3600;
        var frameSpacingAtFixDoorwindowFrame = 4350;

        if (this.frameType == 'Ajtó') {
            frameSpacingAtDoorwindowFrame = 5350;
            frameSpacingAtFixDoorwindowFrame = 6150;
        }

        for (var i = 0; i < this.wings.length; i++) {
            if (this.wings[i].openingMode == 'Fix') {
                var newFrameWidth = 0;
                var newFrameSpacing = [2100, 2100, 2100, 2100];
            } else {
                var newFrameSpacing = [1350, 1350, 1350, 1350];
                var newFrameWidth = global.settings.wingFrameWidthByType[this.wings[i].frameType + ' szárny'];
            }

            // if the side of the wing is at a divider, then it has a different frame spacing
            if (this.wings[i].x == 0) {
                if (this.wings[i].openingMode == 'Fix') {
                    newFrameSpacing[3] = frameSpacingAtFixDoorwindowFrame;
                } else {
                    newFrameSpacing[3] = frameSpacingAtDoorwindowFrame;
                }
            }

            if (this.wings[i].x + this.wings[i].width == this.width) {
                if (this.wings[i].openingMode == 'Fix') {
                    newFrameSpacing[1] = frameSpacingAtFixDoorwindowFrame;
                } else {
                    newFrameSpacing[1] = frameSpacingAtDoorwindowFrame;
                }
            }

            if (this.wings[i].y == 0) {
                if (this.wings[i].openingMode == 'Fix') {
                    newFrameSpacing[0] = frameSpacingAtFixDoorwindowFrame;
                } else {
                    newFrameSpacing[0] = frameSpacingAtDoorwindowFrame;
                }
            }

            if (this.wings[i].y + this.wings[i].height == this.height) {
                if (this.wings[i].openingMode == 'Fix') {
                    newFrameSpacing[2] = frameSpacingAtFixDoorwindowFrame;
                } else {
                    if (this.doorstepType !== 'Tok küszöb') {
                        if (this.wings[0].hingeType == 'Ablak' && this.wings[0].fittings == 'Ablak') {
                            newFrameSpacing[2] = 1200;
                        } else {
                            newFrameSpacing[2] = 1000;
                        }
                    } else {
                        newFrameSpacing[2] = frameSpacingAtDoorwindowFrame;
                    }
                }
            }

            this.wings[i].setFrameSpacing(newFrameSpacing);
            this.wings[i].setFrameWidth(newFrameWidth);
        }
    }

    // returns the a 2 element array that contains the selected glass' size
    // if there is no glass selected, return [-1, -1]
    getSelectedGlassSize() {
        var selectedGlassSize = [-1, -1];
        
        if (this.selectedWingIndex !== -1) {
            var wingSelectedGlassSize = this.wings[this.selectedWingIndex].getSelectedGlassSize();
            if (wingSelectedGlassSize[0] !== -1) {
                selectedGlassSize[0] = wingSelectedGlassSize[0];
                selectedGlassSize[1] = wingSelectedGlassSize[1];
            }
        }

        if (selectedGlassSize[0] !== -1) {
            selectedGlassSize[0] /= 100;
            selectedGlassSize[1] /= 100;
        }

        return selectedGlassSize;    
    }

    // returns a 2 element array that contains the width and height of the doorwindow
    // in pixels and includes the size symbols drawn outside of doorwindow
    getDoorWindowSizeWithSymbolsInPixels(zoom) {
        var oldZoom = global.zoom;
        global.zoom = zoom;

        var widthWithDividerSizeSymbols = mmToPixel(this.width + this.x) + this.dividerSymbolDistance * 2 + 5;
        var heightWithDividerSizeSymbols = mmToPixel(this.height + this.y) + this.dividerSymbolDistance * 2 + 5;

        // collect unique horizontal and vertial divider coordinates
        var uniqueXSymbolPositions = this.getUniqueSymbolPositions()[0];
        var uniqueYSymbolPositions = this.getUniqueSymbolPositions()[1];

        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                if (uniqueXSymbolPositions.indexOf(this.dividers[i][0]) == -1) {
                    uniqueXSymbolPositions.push(this.dividers[i][0])
                }
            } else {
                // horizontal
                if (uniqueYSymbolPositions.indexOf(this.dividers[i][1]) == -1) {
                    uniqueYSymbolPositions.push(this.dividers[i][1])
                }
            }
        }

        for (var i = 0; i < uniqueYSymbolPositions.length; i++) {
            widthWithDividerSizeSymbols = mmToPixel(this.width + this.x) + (i * this.dividerSymbolDistance) + this.dividerSymbolDistance * 2 + 5;
        }

        for (var i = 0; i < uniqueXSymbolPositions.length; i++) {
            heightWithDividerSizeSymbols = mmToPixel(this.height + this.y) + (i * this.dividerSymbolDistance) + this.dividerSymbolDistance * 2 + 5;
        }

        global.zoom = oldZoom;
        return [widthWithDividerSizeSymbols, heightWithDividerSizeSymbols];
    }

    getUniqueGlasses(glassFrameIncluded = true) {
        var uniqueGlasses = [];

        for (var i = 0; i < this.wings.length; i++) {
            // get all glasses from the current doorwindow
            var wingGlasses = this.wings[i].getGlasses(glassFrameIncluded);
            for (var j = 0; j < wingGlasses.length; j++) {
                // check if glass is already exists in the collection
                var wingGlassFound = false;
                for (var k = 0; k < uniqueGlasses.length; k++) {
                    if (uniqueGlasses[k].width == wingGlasses[j].width && 
                        uniqueGlasses[k].height == wingGlasses[j].height && 
                        uniqueGlasses[k].name + uniqueGlasses[k].frame == wingGlasses[j].name + wingGlasses[j].frame) {
                        
                        uniqueGlasses[k].quantity++;
                        wingGlassFound = true;
                    }
                }

                // if glass wasn't found, add it to the collection
                if (!wingGlassFound) {
                    uniqueGlasses.push(wingGlasses[j]);
                }
            }
        }

        return uniqueGlasses;
    }

    getUniqueWingFrames() {
        var uniqueWingFrames = [];

        for (var i = 0; i < this.wings.length; i++) {
            // get all the frames from the current doorwindow
            var wingFrames = this.wings[i].getFrames();
            for (var j = 0; j < wingFrames.length; j++) {
                // check if the frame is already exists in the collection
                var wingFrameFound = false;
                for (var k = 0; k < uniqueWingFrames.length; k++) {
                    if (uniqueWingFrames[k].size == wingFrames[j].size && 
                        uniqueWingFrames[k].name == wingFrames[j].name) {
                        
                        uniqueWingFrames[k].quantity += wingFrames[j].quantity;
                        wingFrameFound = true;
                    }
                }

                // if glass wasn't found, then add it to the collection
                if (!wingFrameFound) {
                    uniqueWingFrames.push(wingFrames[j]);
                }
            }
        }

        return uniqueWingFrames;
    }

    // returns an array of objects that contains unique
    // dividers and the amount that required for the doorwindow
    getUniqueSizedDividers() {
        var uniqueSizedDividers = [];

        // check dividers
        for (var i = 0; i < this.dividers.length; i++) {
            // set the default size for vertical divider
            var size = this.dividers[i][2] - this.dividers[i][0];
            
            // if it's a horizontal divider
            if (size == 0) {
                size = this.dividers[i][3] - this.dividers[i][1];
            }

            // if the divider is already in the collection, increment it's quantity
            var dividerSizeFound = false;
            for (var j = 0; j < uniqueSizedDividers.length && !dividerSizeFound; j++) {
                if (uniqueSizedDividers[j].size == size) {
                    uniqueSizedDividers[j].quantity++;
                    dividerSizeFound = true;
                }
            }

            // add the divider to the collection if it doesn't contain it yet
            if (!dividerSizeFound) {
                uniqueSizedDividers.push({
                    size: size,
                    quantity: 1,
                });
            }
        }

        return uniqueSizedDividers;
    }

    getUniqueSizedWingDividers() {
        var uniqueSizedWingDividers = [];

        // check dividers
        for (var i = 0; i < this.wings.length; i++) {
            var wingDividers = this.wings[i].getUniqueWingDividers();

            for (var j = 0; j < wingDividers.length; j++) {
                var isNewUniqueSize = true;
                
                for (var k = 0; k < uniqueSizedWingDividers.length; k++) {
                    if (uniqueSizedWingDividers[k].size == wingDividers[j].size) {
                        isNewUniqueSize = false;
                        uniqueSizedWingDividers[k].quantity += wingDividers[j].quantity;
                    }
                }

                if (isNewUniqueSize) {
                    uniqueSizedWingDividers.push({size: wingDividers[j].size, quantity: wingDividers[j].quantity});
                }
            }
        }

        return uniqueSizedWingDividers;
    }

    getUniqueSizedStulps() {
        var uniqueSizedStulps = [];

        // check KFNY wings
        for (var i = 0; i < this.wings.length; i++) {
            if (this.wings[i].openingMode !== 'KFNY' && this.wings[i].openingMode !== 'KFNY-BNY') {
                continue;
            }

            // set the default size for vertical divider
            var size = this.wings[i].height - this.wings[i].frameSpacing[0] - this.wings[i].frameSpacing[2] - this.wings[i].frameWidth * 2;
            
            // if the divider is already in the collection, increment it's quantity
            var dividerSizeFound = false;
            for (var j = 0; j < uniqueSizedStulps.length && !dividerSizeFound; j++) {
                if (uniqueSizedStulps[j].size == size) {
                    uniqueSizedStulps[j].quantity++;
                    dividerSizeFound = true;
                }
            }

            // add the divider to the collection if it doesn't contain it yet
            if (!dividerSizeFound) {
                uniqueSizedStulps.push({
                    size: size,
                    quantity: 1,
                });
            }
        }

        return uniqueSizedStulps;
    }

    getWingFramesForCuttingList(frameType, order = '', doorwindowNumber = '', cuttingListType = 'profile') {
        var wingFrames = [];
        for (var k = 0; k < this.quantity; k++) {
            for (var i = 0; i < this.wings.length; i++) {
                var currentWingFrames = this.wings[i].getWingFramesForCuttingList(frameType, order, doorwindowNumber, cuttingListType);
                for (var j = 0; j < currentWingFrames.length; j++) {
                    wingFrames.push(currentWingFrames[j]);
                }
            }
        }

        // calculate handle positions
        var handlePositions = ipcRenderer.sendSync('load-handle-positions');
        for (var i = 0; i < wingFrames.length; i++) {
            if (wingFrames[i].handle !== 'to calculate') {
                continue;
            }

            //ide
            var handleHeight = getHandleHeight(handlePositions, wingFrames[i].size - 600);
            if (handleHeight !== -1) {
                wingFrames[i].handle = handleHeight;
            }
        }

        return wingFrames;
    }

    getDoorwindowFramesForCuttingList(frameType, order = '', doorwindowNumber = '', cuttingListType = 'profile') {
        var doorwindowFrames = [];
        var sizeDifference = 600;
        if (cuttingListType == 'metal-rod') {
            if (this.frameType == 'Ablak') {
                sizeDifference = -9000;
            } else {
                sizeDifference = -13000;
            }
        }

        if (this.frameType != frameType) {
            return doorwindowFrames;
        }

        var openingSide = '';
        if (this.wings.length == 1) {
            openingSide = this.wings[0].openingSide;
            if (this.wings[0].openingMode == 'KFNY') {
                openingSide = 'KFNY';
            }

            if (this.wings[0].openingMode == 'Bukó') {
                openingSide = 'Bukó';
            }
        }

        for (var i = 0; i < this.quantity; i++) {
            doorwindowFrames.push({
                size: Math.round(this.width + sizeDifference) / 100 * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: 'O ' + openingSide,
                handle: -1,
                quantity: (cuttingListType == 'metal-rod' && this.doorstepType == 'Tok küszöb') ? 2 : 1,
            });

            if (this.doorstepType == 'Tok küszöb') {
                doorwindowFrames.push({
                    size: Math.round(this.width + sizeDifference) / 100 * 100,
                    left: '45°\\',
                    right: '45°/',
                    order: order,
                    doorwindowNumber: doorwindowNumber,
                    name: 'U ' + openingSide,
                    handle: -1,
                    quantity: cuttingListType == 'metal-rod' ? 0 : 1,
                });

                doorwindowFrames.push({
                    size: Math.round(this.height + sizeDifference) / 100 * 100,
                    left: '45°\\',
                    right: '45°/',
                    order: order,
                    doorwindowNumber: doorwindowNumber,
                    name: 'L ' + openingSide,
                    handle: -1,
                    quantity: cuttingListType == 'metal-rod' ? 2 : 1,
                });

                doorwindowFrames.push({
                    size: Math.round(this.height + sizeDifference) / 100 * 100,
                    left: '45°\\',
                    right: '45°/',
                    order: order,
                    doorwindowNumber: doorwindowNumber,
                    name: 'R ' + openingSide,
                    handle: -1,
                    quantity: cuttingListType == 'metal-rod' ? 0 : 1,
                });
            } else {
                if (cuttingListType == 'profile') {
                    sizeDifference = 300;
                } else {
                    if (this.frameType == 'Ablak') {
                        sizeDifference = -4500;
                    } else {
                        sizeDifference = -6500;
                    }
                }

                doorwindowFrames.push({
                    size: Math.round((this.height + sizeDifference - this.doorstepWidth) / 100) * 100,
                    left: '90°|',
                    right: '45/',
                    order: order,
                    doorwindowNumber: doorwindowNumber,
                    name: 'L ' + openingSide,
                    handle: -1,
                    quantity: (cuttingListType == 'metal-rod' && this.frameType == 'Ablak') ? 2 : 1,
                });

                doorwindowFrames.push({
                    size: Math.round((this.height + sizeDifference - this.doorstepWidth) / 100) * 100,
                    right: '90°|',
                    left: '45\\',
                    order: order,
                    doorwindowNumber: doorwindowNumber,
                    name: 'R ' + openingSide,
                    handle: -1,
                    quantity: (cuttingListType == 'metal-rod' && this.frameType == 'Ablak') ? 0 : 1,
                });
            }
        }

        // remove frames with 0 quantity
        for (var i = doorwindowFrames.length - 1; i >= 0; i --) {
            if (!doorwindowFrames[i].quantity) {
                doorwindowFrames.splice(i, 1);
            }
        }

        return doorwindowFrames;
    }

    getUniqueExtensions() {
        var uniqueExtensions = [];
        var rightExtensionSumSize = this.getExtensionsSumSize('right');
        var leftExtensionSumSize = this.getExtensionsSumSize('left');

        var horizontalExtensions = this.extensions.top.concat(this.extensions.bottom);
        var verticalExtensions = this.extensions.left.concat(this.extensions.right);

        // horizontal extensions
        for (var i = 0; i < horizontalExtensions.length; i++) {
            uniqueExtensions.push({
                name: horizontalExtensions[i].name,
                size: this.width + leftExtensionSumSize + rightExtensionSumSize,
                position: horizontalExtensions[i].position,
            });
        }

        // vertical extensions
        for (var i = 0; i < verticalExtensions.length; i++) {
            uniqueExtensions.push({
                name: verticalExtensions[i].name,
                size: this.height,
                position: verticalExtensions[i].position,
            });
        }
        
        return uniqueExtensions;
    }
    
    // a list of wings, but KFNY and KFNY-BNY are separated into 2 wings
    getWingsForFittingsList() {
        var wings = [];

        for (var i = 0; i < this.wings.length; i ++) {
            if (this.wings[i].openingMode == 'KFNY' || this.wings[i].openingMode == 'KFNY-BNY') {
                var wing = {};
                wing.height = Math.round((this.wings[i].height - this.wings[i].frameSpacing[2] - this.wings[i].frameSpacing[0]) / 100) - 40;
                if (this.wings[i].openingSide == 'Jobb') {
                    wing.width = Math.round((this.wings[i].width - (this.wings[i].width - this.wings[i].kfnyDivider) - this.wings[i].frameSpacing[3] - 400) / 100) - 40;
                } else {
                    wing.width = Math.round((this.wings[i].width - this.wings[i].kfnyDivider - this.wings[i].frameSpacing[1] - 400) / 100) - 40;
                }

                wing.openingMode = this.wings[i].openingMode + ' Nyíló oldal';
                if (this.wings[i].openingMode == 'KFNY') {
                    wing.openingMode = this.wings[i].openingMode + ' bal';
                }

                wing.openingSide = this.wings[i].openingSide;
                wing.fittingType = this.wings[i].fittings;
                wing.handleType = this.wings[i].handle.type;
                wing.wingFrame = this.wings[i].frameType + ' szárny';
                wing.hingeType = this.wings[i].hingeType;
                wings.push(wing);

                wing = {};
                wing.height = Math.round((this.wings[i].height - this.wings[i].frameSpacing[2] - this.wings[i].frameSpacing[0]) / 100) - 40;
                if (this.wings[i].openingSide == 'Bal') {
                    wing.width = Math.round((this.wings[i].width - (this.wings[i].width - this.wings[i].kfnyDivider) - this.wings[i].frameSpacing[3] - 400) / 100) - 40;
                } else {
                    wing.width = Math.round((this.wings[i].width - this.wings[i].kfnyDivider - this.wings[i].frameSpacing[1] - 400) / 100) - 40;
                }

                wing.openingMode = this.wings[i].openingMode + ' Bukó oldal';
                if (this.wings[i].openingMode == 'KFNY') {
                    wing.openingMode = this.wings[i].openingMode + ' jobb';
                }

                wing.openingSide = this.wings[i].openingSide;
                wing.fittingType = this.wings[i].fittings;
                wing.handleType = this.wings[i].handle.type;
                wing.wingFrame = this.wings[i].frameType + ' szárny';
                wing.hingeType = this.wings[i].hingeType;
                wings.push(wing);
            } else {
                var wing = {};
                wing.height = Math.round((this.wings[i].height - this.wings[i].frameSpacing[2] - this.wings[i].frameSpacing[0]) / 100) - 40;
                wing.width = Math.round((this.wings[i].width - this.wings[i].frameSpacing[3] - this.wings[i].frameSpacing[1]) / 100) - 40;
                wing.openingMode = this.wings[i].openingMode;
                wing.openingSide = this.wings[i].openingSide;
                wing.fittingType = this.wings[i].fittings;
                wing.handleType = this.wings[i].handle.type;
                wing.wingFrame = this.wings[i].frameType + ' szárny';
                wing.hingeType = this.wings[i].hingeType;
                wings.push(wing);
            }
        }

        return wings;
    }

    getFittingsList() {
        var wingsForFittingsList = this.getWingsForFittingsList();
        var wings = [];
        var fittings = ipcRenderer.sendSync('load-fittings');
        for (var j = 0; j < wingsForFittingsList.length; j++) {
            var wing = {};
            wing.fittings = [];

            for (var i = 0; i < fittings.length; i++) {
                wing.name = wingsForFittingsList[j].width + 'x' + wingsForFittingsList[j].height + ' mm ' + wingsForFittingsList[j].openingSide + ' ' + wingsForFittingsList[j].openingMode;
                if (fittings[i].minWidth != -1 && wingsForFittingsList[j].width < fittings[i].minWidth) {
                    continue;
                }

                if (fittings[i].maxWidth != -1 && wingsForFittingsList[j].width > fittings[i].maxWidth) {
                    continue;
                }

                if (fittings[i].minHeight != -1 && wingsForFittingsList[j].height < fittings[i].minHeight) {
                    continue;
                }

                if (fittings[i].maxHeight != -1 && wingsForFittingsList[j].height > fittings[i].maxHeight) {
                    continue;
                }

                if (fittings[i].openingSide !== '' && fittings[i].openingSide !== wingsForFittingsList[j].openingSide) {
                    continue;
                }
                
                if (fittings[i].openingMode !== '' && fittings[i].openingMode !== wingsForFittingsList[j].openingMode) {
                    continue;
                }

                if (fittings[i].frame !== '' && fittings[i].frame !== this.frameType) {
                    continue;
                }

                if (fittings[i].fittingType !== '' && fittings[i].fittingType !== wingsForFittingsList[j].fittingType) {
                    continue;
                }

                if (fittings[i].handleType !== '' && fittings[i].handleType !== wingsForFittingsList[j].handleType) {
                    continue;
                }

                if (fittings[i].wingFrame !== '' && fittings[i].wingFrame !== wingsForFittingsList[j].wingFrame) {
                    continue;
                }
                
                if (fittings[i].hingeType !== '' && fittings[i].hingeType !== wingsForFittingsList[j].hingeType) {
                    continue;
                }

                var fitting = {};
                fitting.code = fittings[i].code;
                fitting.minWidth = fittings[i].minWidth == -1 ? '' : fittings[i].minWidth;
                fitting.maxWidth = fittings[i].maxWidth == -1 ? '' : fittings[i].maxWidth;
                fitting.minHeight = fittings[i].minHeight == -1 ? '' : fittings[i].minHeight;
                fitting.maxHeight = fittings[i].maxHeight == -1 ? '' : fittings[i].maxHeight;
                fitting.shortName = fittings[i].shortName;
                fitting.longName = fittings[i].longName;
                fitting.price = fittings[i].price;
                fitting.quantity = fittings[i].quantity;
                fitting.display = fittings[i].display;

                wing.fittings.push(fitting);
            }

            wings.push(wing);
        }

        return wings;
    }

    getFittingsPrice() {
        var fittingsPrice = 0;

        var fittingsByWings = this.getFittingsList();
        for (var i = 0; i < fittingsByWings.length; i++) {
            for (var j = 0; j < fittingsByWings[i].fittings.length; j++) {
                var currentFitting = fittingsByWings[i].fittings[j];
                fittingsPrice += currentFitting.quantity * currentFitting.price;
            }
        }

        return fittingsPrice;
    }
    
    getWorkFees() {
        var workFee = 0;
        var workFees = ipcRenderer.sendSync('load-work-fees');
        for (var j = 0; j < this.wings.length; j++) {
            for (var i = 0; i < workFees.length; i ++) {
                if (workFees[i].fittings !== '' && workFees[i].fittings !== this.wings[j].fittings) {
                    continue;
                }

                if (workFees[i].wingFrame !== '' && workFees[i].wingFrame !== this.wings[j].frameType) {
                    continue;
                }

                if (workFees[i].openingMode !== '' && workFees[i].openingMode !== this.wings[j].openingMode) {
                    continue;
                }

                if (workFees[i].price > workFee) {
                    workFee = workFees[i].price;
                }
            }
        }

        return workFee;
    }

    getProfit() {
        var profit = 0;
        var profits = ipcRenderer.sendSync('load-profits');
         
        for (var j = 0; j < this.wings.length; j++) {
            for (var i = 0; i < profits.length; i ++) {
                if (profits[i].fittings !== '' && profits[i].fittings !== this.wings[j].fittings) {
                    continue;
                }

                if (profits[i].wingFrame !== '' && profits[i].wingFrame !== this.wings[j].frameType) {
                    
                    continue;
                }

                if (profits[i].openingMode !== '' && profits[i].openingMode !== this.wings[j].openingMode) {
                    continue;
                }

                if (profits[i].price > profit) {
                    profit = profits[i].price;
                }
            }
        }

        return profit;
    }

    getOpeningDirectionText() {
        var openingDirectionText = 'Belülről nézve, befelé nyílik';
        if (this.wings[0].frameType.indexOf('Kifelé') == 0) {
            openingDirectionText = 'Kívűlről nézve, kifelé nyílik';
        }

        if (this.wings[0].openingMode == 'Fix') {
            openingDirectionText = 'Belülről nézve';
        }

        return openingDirectionText;
    }

    getExtensionsSumSize(side) {
        var sumSize = 0;
        
        for (var i = 0; i < this.extensions[side].length; i++) {
            sumSize += this.extensions[side][i].size;
        }

        return sumSize;
    }

    // returns a 2 element array containing 2 arrays wih unique
    // symbol positions. the first array is containing x positions,
    // the second one is y positions
    getUniqueSymbolPositions() {
        var uniqueYPositions = [];
        var uniqueXPositions = [];

        // get unique coordinates from dividers
        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                if (uniqueXPositions.indexOf(this.dividers[i][0]) == -1) {
                    uniqueXPositions.push(this.dividers[i][0])
                }
            } else {
                // horizontal
                if (uniqueYPositions.indexOf(this.dividers[i][1]) == -1) {
                    uniqueYPositions.push(this.dividers[i][1])
                }
            }
        }

        // get unique coordinates from wings
        for (var i = 0; i < this.wings.length; i++) {
            var uniqueWingXPositions = this.wings[i].getUniqueSymbolPositions()[0];
            var uniqueWingYPositions = this.wings[i].getUniqueSymbolPositions()[1];

            for (var j = 0; j < uniqueWingXPositions.length; j++) {
                if (uniqueXPositions.indexOf(uniqueWingXPositions[j]) == -1) {
                    uniqueXPositions.push(uniqueWingXPositions[j])
                }
            }

            for (var j = 0; j < uniqueWingYPositions.length; j++) {
                if (uniqueYPositions.indexOf(uniqueWingYPositions[j]) == -1) {
                    uniqueYPositions.push(uniqueWingYPositions[j])
                }
            }
        }

        return [uniqueXPositions, uniqueYPositions];
    }
    
    setSumPrice(withoutUniqueAdditionalParts = false) {
        this.sumPrice = 0;
        var priceSettings = ipcRenderer.sendSync('load-price-settings');

        var uniqueExtensions = this.getUniqueExtensions();
        var dividers = this.getUniqueSizedDividers();
        var stulps = this.getUniqueSizedStulps();
        var wingDividers = this.getUniqueSizedWingDividers();
        var glasses = this.getUniqueGlasses(false);
        var glassFrames = this.getUniqueGlasses();
        var frames = this.getUniqueWingFrames();

        // calculate doorwindow price
        // doorwindow frame price by width
        var horizontalFrameCount = (this.doorstepType == 'Tok küszöb') ? 2 : 1;
        var partPrice = Math.round(getPriceByPartName(priceSettings, this.frameType + ' tok') * this.width / 100000 * horizontalFrameCount);
        this.sumPrice += partPrice;
        
        // additional parts
        var additionalPartsPrice = 0;
        for (var i = 0; i < this.additionalParts.length; i++) {
            if (this.additionalParts[i].type == 'kiegészítő') {
                additionalPartsPrice += this.additionalParts[i].price;
            }

            if (this.additionalParts[i].type == 'szúnyogháló' && !withoutUniqueAdditionalParts) {
                additionalPartsPrice += this.additionalParts[i].price;
            }

            if (this.additionalParts[i].type == 'redőny' && !withoutUniqueAdditionalParts) {
                additionalPartsPrice += this.additionalParts[i].price;
            }

            if (this.additionalParts[i].type == 'párkány' && !withoutUniqueAdditionalParts) {
                additionalPartsPrice += this.additionalParts[i].price;
            }
        }

        // extensions
        for (var i = 0; i < uniqueExtensions.length; i++) {
            partPrice = Math.round(getPriceByPartName(priceSettings, uniqueExtensions[i].name) * uniqueExtensions[i].size / 100000);
            this.sumPrice += partPrice;
        }

        // doorwindow frame price by height
        var verticalFrameHeight = this.height;
        if (this.doorstepType == 'Alu küszöb bekötővel') {
            verticalFrameHeight -= this.doorstepWidth;
        }

        partPrice = Math.round(getPriceByPartName(priceSettings, this.frameType + ' tok') * verticalFrameHeight / 100000 * 2);
        this.sumPrice += partPrice;

        // dividers price
        var dividerAndStulpCount = 0;
        for (var i = 0; i < dividers.length; i++) {
            partPrice = Math.round(getPriceByPartName(priceSettings, 'Tokosztó') * dividers[i].size / 100000 * dividers[i].quantity);
            dividerAndStulpCount += dividers[i].quantity;
            this.sumPrice += partPrice;
        }

        // wing dividers price
        for (var i = 0; i < wingDividers.length; i++) {
            partPrice = Math.round(getPriceByPartName(priceSettings, 'Stulp') * wingDividers[i].size / 100000 * wingDividers[i].quantity);
            dividerAndStulpCount += wingDividers[i].quantity;
            this.sumPrice += partPrice;
        }

        // stulps price
        for (var i = 0; i < stulps.length; i++) {
            partPrice = Math.round(getPriceByPartName(priceSettings, 'Stulp') * stulps[i].size / 100000 * stulps[i].quantity);
            dividerAndStulpCount += stulps[i].quantity;
            this.sumPrice += partPrice;
        }

        // divider and stulp wage
        partPrice = Math.round(getPriceByPartName(priceSettings, 'Tokosztó és stulp munkabér') * dividerAndStulpCount);
        this.sumPrice += partPrice;

        // glasses price
        for (var i = 0; i < glasses.length; i++) {
            if (glasses[i].name.indexOf('Üveg nélkül') !== -1) {
                continue;
            }
            
            if (glasses[i].name.indexOf('Panel') !== -1) {
                partPrice = Math.round(getPriceByPartName(priceSettings, glasses[i].name));
            } else {
                if (glasses[i].name.indexOf('Stadur') !== -1) {
                    partPrice = 0;
                } else {
                    partPrice = Math.round(getPriceByPartName(priceSettings, glasses[i].framePriceName) * (glasses[i].width / 100000 * 2 + glasses[i].height / 100000 * 2) * glasses[i].quantity);
                }

                partPrice += Math.round(getPriceByPartName(priceSettings, glasses[i].name) * glasses[i].width / 100000 * glasses[i].height / 100000 * glasses[i].quantity);
            }

            this.sumPrice += partPrice;
        }

        // glass frame price
        for (var i = 0; i < glassFrames.length; i++) {
            var glassWidth = glassFrames[i].name.split(' ');
            glassWidth = glassWidth[glassWidth.length - 1];

            partPrice = Math.round(getPriceByPartName(priceSettings, 'Üvegléc ' + glassWidth) * (glassFrames[i].width * 2 + glassFrames[i].height * 2) / 100000 * glassFrames[i].quantity);
            this.sumPrice += partPrice;
        }

        // wings frame price
        for (var i = 0; i < frames.length; i++) {
            partPrice = Math.round(getPriceByPartName(priceSettings, frames[i].name + '') * frames[i].size / 100000 * frames[i].quantity);
            this.sumPrice += partPrice;
        }

        // doorstep price
        if (this.doorstepType == 'Alu küszöb bekötővel') {
            partPrice = getPriceByPartName(priceSettings, 'Küszöb') * this.width / 100000;
            this.sumPrice += partPrice;
        }

        // doorstep connector
        if (this.doorstepType == 'Alu küszöb bekötővel') {
            partPrice = getPriceByPartName(priceSettings, 'Küszöb bekötő');
            this.sumPrice += partPrice;
        }

        // add profit, wage and fittings to price
        this.sumPrice += this.profit;
        this.sumPrice += this.wage;
        this.sumPrice += this.fittingsPrice;

        this.sumPrice *= this.quantity;

        // additional parts are not
        this.sumPrice += additionalPartsPrice;
    }
}