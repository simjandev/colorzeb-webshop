class Canvas{

    constructor(isInEditor = false){
        this.changeHistory = [];
        this.changeHistoryIndex = -1;
        // required because loading a doorwindow from history
        // triggers change event in history
        this.historyLocked = false;

        // blank space inside canvas in pixels
        this.offsetX = 10;
        this.offsetY = 10;
        this.doorWindow = new DoorWindow(90000, 150000, isInEditor);

        // this prevents dragging text and other elements
        // from being detected as divider drag
        this.drag = false;
        this.dragType = '';

        this.addToChangeHistory();
        updateHistoryButtons(this.changeHistory.length, this.changeHistoryIndex);
        this.width = 0;
        this.height = 0;
    }

    loadDoorwindow(doorwindowString) {
        this.doorWindow.load(doorwindowString);
        this.changeHistory = [];
        this.changeHistoryIndex = -1;

        var isThereChangeHistory = false;
        var changeHistoryLoadList = doorwindowString.split('|CHANGE-HISTORY|');
        if (changeHistoryLoadList.length > 1) {
            // in older save files |CHANGE-HISTORY|...|END-OF-CHANGE-HISTORY|
            // does not exists, so it has to be checked
            //this.changeHistoryIndex = parseInt(doorwindowString.split('|CHANGE-HISTORY-INDEX|')[1].split('|END-OF-CHANGE-HISTORY-INDEX|')[0]);
            changeHistoryLoadList = changeHistoryLoadList[1].split('|END-OF-CHANGE-HISTORY|')[0].split('|CHANGE-HISTORY-DIVIDER|');
            if (changeHistoryLoadList[0] !== '') {
                isThereChangeHistory = true;
                for (var i = 0; i < changeHistoryLoadList.length; i++) {
                    this.changeHistory.push(changeHistoryLoadList[i]);
                }
            }
        }

        if (!isThereChangeHistory) {
            this.addToChangeHistory();    
        }
        
        updateHistoryButtons(this.changeHistory.length, this.changeHistoryIndex);
    }

    getSaveString() {
        var saveString = this.doorWindow.getSaveString();
        saveString += '|CHANGE-HISTORY|';
        
        /*for (var i = 0; i < this.changeHistory.length; i++) {
            saveString += this.changeHistory[i];
            if (i < this.changeHistory.length - 1) {
                saveString += '|CHANGE-HISTORY-DIVIDER|';
            }
        }*/
        
        saveString += '|END-OF-CHANGE-HISTORY|';
        saveString += '|CHANGE-HISTORY-INDEX|' + this.changeHistoryIndex + '|END-OF-CHANGE-HISTORY-INDEX|';
        return saveString;
    }

    addToChangeHistory() {
        if (this.historyLocked) {
            return;
        }

        var changeHistorySize = global.settings.doorwindowChangeHistorySize;
        
        if (this.changeHistoryIndex == this.changeHistory.length - 1) {
            if (this.changeHistory.length < changeHistorySize) {
                this.changeHistory.push(this.doorWindow.getSaveString());
                this.changeHistoryIndex ++;
            } else {
                this.changeHistory.shift();
                this.changeHistory.push(this.doorWindow.getSaveString());
            }
        } else {
            while (this.changeHistory.length > this.changeHistoryIndex + 1) {
                this.changeHistory.pop();
            }

            this.changeHistory.push(this.doorWindow.getSaveString());
            this.changeHistoryIndex ++;
        }

        updateHistoryButtons(this.changeHistory.length, this.changeHistoryIndex);
    }

    stepBackInChangeHistory() {
        if (this.changeHistoryIndex == 0) {
            return;
        }

        this.changeHistoryIndex --;
        this.historyLocked = true;
        this.doorWindow.load(this.changeHistory[this.changeHistoryIndex]);
        this.historyLocked = false;

        updateHistoryButtons(this.changeHistory.length, this.changeHistoryIndex);
        updateDoorwindowAdditionalParts();
    }

    stepForwardInChangeHistory() {
        if (this.changeHistoryIndex > this.changeHistory.length - 1) {
            return;
        }

        this.changeHistoryIndex ++;
        this.historyLocked = true;
        this.doorWindow.load(this.changeHistory[this.changeHistoryIndex]);
        this.historyLocked = false;

        updateHistoryButtons(this.changeHistory.length, this.changeHistoryIndex);
        updateDoorwindowAdditionalParts();
    }

    setCanvasDom(canvasDom) {
        this.canvasDom = canvasDom;
        this.graphics = canvasDom.getContext('2d');
    }

    drawout(printing = false) {
        if (!this.doorWindow || !this.graphics) {
            return;
        }

        /*
        if (!printing) {
            this.doorWindow.x = pixelToMm(this.width / 2) - this.doorWindow.width / 2;
            this.doorWindow.y = pixelToMm(this.height / 2) - this.doorWindow.height / 2;
        }
        */

        var graphics = this.graphics;
        if (printing) {
            this.doorWindow.unselectAllWingsAndDividersAndExtensions();
            
            var oldZoom = global.zoom;
            global.zoom = 1;
        
            // print canvas size in pixel
            var printCanvasWidth = 264;
            var printCanvasHeight = 430;
            
            var sizeWithDividerSizeSymbols = this.doorWindow.getDoorWindowSizeWithSymbolsInPixels(global.zoom);

            while (sizeWithDividerSizeSymbols[0] > printCanvasWidth - this.doorWindow.dividerSymbolDistance * 2.5 ||
                sizeWithDividerSizeSymbols[1] > printCanvasHeight - this.doorWindow.dividerSymbolDistance * 2.5) {
                    
                global.zoom += 0.5;
                sizeWithDividerSizeSymbols = this.doorWindow.getDoorWindowSizeWithSymbolsInPixels(global.zoom);
            }
        }

        graphics.lineCap = 'round';
        graphics.lineJoin = 'round';
        graphics.fillStyle = 'rgba(255, 255, 255, 255)';
        graphics.strokeStyle = 'rgba(0, 0, 0, 255)';
        graphics.lineWidth = 2;

    
        if (printing) {
            graphics.save();
            graphics.translate(printCanvasWidth / 2 - sizeWithDividerSizeSymbols[0] / 2, 0);
        } else {
            graphics.fillRect(0, 0, this.canvasDom.width, this.canvasDom.height);
        }
        
        this.doorWindow.drawout(graphics);
        
        // draw out selected glass sizeout
        var selectedGlassSize = this.doorWindow.getSelectedGlassSize();
        if (selectedGlassSize[0] !== -1) {
            graphics.font = '16px Arial';
            graphics.fillRect(0, this.canvasDom.height - 20, this.canvasDom.width, 20);
            graphics.fillStyle = 'rgb(0, 0, 0)';
            graphics.textAlign = 'left';
            graphics.fillText("Kiválasztott üveg: " + Math.round(selectedGlassSize[0]) + 'x' + Math.round(selectedGlassSize[1]) + "mm", 10, this.canvasDom.height - 10);
        }
        

        if (printing) {
            global.zoom = oldZoom;
            graphics.restore();
        }
    }

    dividerDragStart(event) {
        if (event.target.getAttribute('data-direction') == null) {
            return;
        }

        event.dataTransfer.setData("kfny-multiple-division", document.getElementById('divider-kfny-multiple-division').checked);
        event.dataTransfer.setData("direction", event.target.getAttribute('data-direction'));
        this.dragType = event.target.getAttribute('data-type');
        this.drag = true;
    }

    extensionDragStart(event) {
        var extensionDragSize = parseInt($('#doorwindow-extension').val());
        var extensionDragIsInSize = $('#doorwindow-extension-in-size').prop('checked');
        var extensionDragName = $('#doorwindow-extension').find('option:selected').text();

        this.dragType = 'extension';
        this.extensionDragSize = extensionDragSize;
        this.extensionDragIsInSize = extensionDragIsInSize;
        this.extensionDragName = extensionDragName;
        this.drag = true;
    }

    // when mouse enters with a new wing
    dividerDragOver(event){
        if (!this.drag) {
            return;
        }

        var mouseX = event.clientX - document.getElementById('canvas').offsetLeft;
        var mouseY = event.clientY - document.getElementById('canvas').offsetTop;
        
        if (this.dragType == 'frame') {
            var direction = $('#new-divider-direction').attr('data-direction');
            this.doorWindow.dividerDragOver(mouseX, mouseY, direction);
        }

        if (this.dragType == 'wing') {
            var direction = $('#new-wing-divider-direction').attr('data-direction');
            var kfnyMultipleDivision = document.getElementById('divider-kfny-multiple-division').checked;
            this.doorWindow.wingDividerDragOver(mouseX, mouseY, direction, kfnyMultipleDivision);
        }

        if (this.dragType == 'extension') {
            this.doorWindow.extensionDragOver(mouseX, mouseY, this.extensionDragSize);
        }

        event.preventDefault();
    }

    drop() {
        if (this.dragType == 'frame') {
            this.doorWindow.dividerDrop();
        }
        
        if (this.dragType == 'wing') {
            this.doorWindow.wingDividerDrop();
        }

        if (this.dragType == 'extension') {
            console.log(this.extensionDragIsInSize);
            this.doorWindow.extensionDrop(this.extensionDragIsInSize, this.extensionDragName);
        }

        if (this.doorWindow.selectedDividerIndex == -1 && this.doorWindow.selectedWingIndex == -1) {
            resetFormInputs();
        }

        this.drag = false;
    }

    click(event) {
        var mouseX = event.clientX - document.getElementById('canvas').offsetLeft;
        var mouseY = event.clientY - document.getElementById('canvas').offsetTop;
        
        this.doorWindow.unselectAllWingsAndDividersAndExtensions();
        this.doorWindow.selectExtensionUnderMouse(mouseX, mouseY);
        this.doorWindow.selectWingUnderMouse(mouseX, mouseY);
        this.doorWindow.selectDividerUnderMouse(mouseX, mouseY);
        this.doorWindow.checkDeletableSelectedObjects();
        if (this.doorWindow.selectedDividerIndex == -1 && this.doorWindow.selectedWingIndex == -1) {
            resetFormInputs();
        }
    }
}

