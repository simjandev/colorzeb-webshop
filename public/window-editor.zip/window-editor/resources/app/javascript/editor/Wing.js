class Wing {
    constructor(openingMode, openingSide, x, y, width, height, frameType = 'Ablak') {
        // is the wing selected        
        this.selected = false;

        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.openingSide = openingSide;
        this.frameType = frameType;
        this.frameWidth = 0;
        this.hingeType = 'Ablak';
        this.fittings = 'Ablak';
        this.handle = new Handle('H', 'R', 'Ablak');

        this.dividerWidth = global.settings.wingDividerWidth;
        this.dividerPosition = -1;
        this.dividerDirection = '';

        // space between the wing frame and the doorwindow frame or divider
        this.frameSpacing = [1500, 1500, 1500, 1500];
        
        // divider position for KFNY and KFNY-BNY windows
        this.kfnyDivider = parseInt(this.width / 2);

        this.glasses = [];
        this.selectedGlassIndex = -1;

        this.setOpeningMode(openingMode);
        
        this.dividers = [];
        this.selectedDividerIndex = -1;
        
        this.updateHandle();
    }

    load(wingString) {
        var wingData = wingString.split('|GLASSLIST|')[0].split('|');
        this.x = parseInt(wingData[0]);
        this.y = parseInt(wingData[1]);
        this.width = parseInt(wingData[2]);
        this.height = parseInt(wingData[3]);
        this.kfnyDivider = parseInt(wingData[4]);
        this.openingSide = wingData[5];
        this.openingMode = wingData[6];
        this.frameType = wingData[7];
        this.fittings = wingData[8];
        this.hingeType = wingData[9];
        this.setHandleType(wingData[10]);
        this.frameWidth = parseInt(wingData[11]);
        this.frameSpacing[0] = parseInt(wingData[12]);
        this.frameSpacing[1] = parseInt(wingData[13]);
        this.frameSpacing[2] = parseInt(wingData[14]);
        this.frameSpacing[3] = parseInt(wingData[15]);
        this.dividerWidth = parseInt(wingData[16]);
        this.glasses = [];
        this.dividers = [];

        if (this.hingeType == 'Ajtó') {
            this.hingeType = 'Ajtó-iq';
        }

        if (this.fittings == 'Ajtó') {
            this.fittings = 'Ajtó - 5pont';
        }

        var glassData = wingString.split('|GLASSLIST|')[1].split('|END-OF-GLASSLIST|')[0].split('|END-OF-GLASS|');

        for (var i = 0; i < glassData.length; i++) {
            var glass = new Glass(0, 0, 0, 0);
            glass.load(glassData[i]);
            this.glasses.push(glass);
        }

        var dividersData = wingString.split('|WING-DIVIDERLIST|')[1].split('|END-OF-WING-DIVIDERLIST|')[0].split('|END-OF-WING-DIVIDER|');

        if (dividersData[0] !== '') {
            for (var i = 0; i < dividersData.length; i++) {
                var dividerData = dividersData[i].split('|');
                var divider = [
                    parseInt(dividerData[0]),
                    parseInt(dividerData[1]),
                    parseInt(dividerData[2]),
                    parseInt(dividerData[3]),
                ];

                this.dividers.push(divider);
            }
        }

        this.updateHandle();
        this.setDividerSize(global.settings.wingDividerWidth);
    }

    getSaveString() {
        var saveString = '';
         
        saveString += this.x + '|';
        saveString += this.y + '|';
        saveString += this.width + '|';
        saveString += this.height + '|';
        saveString += this.kfnyDivider + '|';
        saveString += this.openingSide + '|';
        saveString += this.openingMode + '|';
        saveString += this.frameType + '|';
        saveString += this.fittings + '|';
        saveString += this.hingeType + '|';
        saveString += this.handle.type + '|';
        saveString += this.frameWidth + '|';
        saveString += this.frameSpacing[0] + '|';
        saveString += this.frameSpacing[1] + '|';
        saveString += this.frameSpacing[2] + '|';
        saveString += this.frameSpacing[3] + '|';
        saveString += this.dividerWidth;

        // glasses
        saveString += '|GLASSLIST|';

        for (var i = 0; i < this.glasses.length; i ++) {
            saveString += this.glasses[i].getSaveString();

            if (i !== this.glasses.length - 1) {
                saveString += '|END-OF-GLASS|';
            }
        }

        saveString += '|END-OF-GLASSLIST|';

        // dividers
        saveString += '|WING-DIVIDERLIST|';

        for (var i = 0; i < this.dividers.length; i ++) {
            saveString += this.dividers[i][0] + '|';
            saveString += this.dividers[i][1] + '|';
            saveString += this.dividers[i][2] + '|';
            saveString += this.dividers[i][3];

            if (i !== this.dividers.length - 1) {
                saveString += '|END-OF-WING-DIVIDER|';
            }
        }

        saveString += '|END-OF-WING-DIVIDERLIST|';
        
        return saveString;
    }

    drawout(g, offsetX, offsetY, dividerWidth, color) {
        g.lineCap = 'round';
        g.lineJoin = 'round';
        g.fillStyle = color;
        g.strokeStyle = 'rgba(0, 0, 0, 255)';

        g.beginPath();

        var calculatedXPosition = offsetX + mmToPixel(this.x);
        var calculatedYPosition = offsetY + mmToPixel(this.y);
        
        // outer frame line
        if (this.openingMode == 'Nyíló' ||this.openingMode == 'Bukó' || this.openingMode == 'Bukó-nyíló' || this.openingMode == 'Fix' ||
            this.openingMode == 'Bukó-toló' || this.openingMode == 'Bukó-toló k') {
            g.fillRect(calculatedXPosition + mmToPixel(this.frameSpacing[3]), calculatedYPosition + mmToPixel(this.frameSpacing[0]), mmToPixel(this.width - this.frameSpacing[1] - this.frameSpacing[3]), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2]));
            g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3]), calculatedYPosition + mmToPixel(this.frameSpacing[0]), mmToPixel(this.width - this.frameSpacing[1] - this.frameSpacing[3]), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2]));

            for (var i = 0; i < this.glasses.length; i++) {
                this.glasses[i].drawout(g, offsetX, offsetY);
            }

            // inner frame line
            g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth), mmToPixel(this.width - this.frameSpacing[1] - this.frameSpacing[3] - this.frameWidth * 2), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2] - this.frameWidth * 2));
            
        } else if (this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
            // wing's left part
            g.fillRect(calculatedXPosition + mmToPixel(this.frameSpacing[3]), calculatedYPosition + mmToPixel(this.frameSpacing[0]), mmToPixel(this.kfnyDivider - this.frameSpacing[3] - 400), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2]));
            g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3]), calculatedYPosition + mmToPixel(this.frameSpacing[0]), mmToPixel(this.kfnyDivider - this.frameSpacing[3] - 400), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2]));

            for (var i = 0; i < this.glasses.length; i++) {
                this.glasses[i].drawout(g, offsetX, offsetY);
            }

            // inner frame line
            g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth), mmToPixel(this.kfnyDivider - this.frameSpacing[3] - this.frameWidth * 2 - 400), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2] - this.frameWidth * 2));

            // wing's right part
            g.fillStyle = color;
            g.fillRect(calculatedXPosition + mmToPixel(this.kfnyDivider + 400), calculatedYPosition + mmToPixel(this.frameSpacing[0]), mmToPixel(this.width - this.kfnyDivider - this.frameSpacing[1] - 400), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2]));
            g.strokeRect(calculatedXPosition + mmToPixel(this.kfnyDivider + 400), calculatedYPosition + mmToPixel(this.frameSpacing[0]), mmToPixel(this.width - this.kfnyDivider - this.frameSpacing[1] - 400), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2]));
            
            for (var i = 0; i < this.glasses.length; i++) {
                this.glasses[i].drawout(g, offsetX, offsetY);
            }
            
            // inner frame line
            g.strokeRect(calculatedXPosition + mmToPixel(this.kfnyDivider + this.frameWidth + 400), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth), mmToPixel(this.width - this.kfnyDivider - this.frameSpacing[1] - this.frameWidth * 2 - 400), mmToPixel(this.height - this.frameSpacing[0] - this.frameSpacing[2] - this.frameWidth * 2));
        }

        // corner symbols
        if (this.openingMode == 'Nyíló' || this.openingMode == 'Bukó' || this.openingMode == 'Bukó-nyíló' || this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
            // top left
            g.beginPath();
            g.moveTo(calculatedXPosition + mmToPixel(this.frameSpacing[3]), calculatedYPosition + mmToPixel(this.frameSpacing[0]));
            g.lineTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
            g.stroke();

            // top right
            g.beginPath();
            g.moveTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1]), calculatedYPosition + mmToPixel(this.frameSpacing[0]));
            g.lineTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
            g.stroke();

            // bottom left
            g.beginPath();
            g.moveTo(calculatedXPosition + mmToPixel(this.frameSpacing[3]), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2]));
            g.lineTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
            g.stroke();

            // top right
            g.beginPath();
            g.moveTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1]), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2]));
            g.lineTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
            g.stroke();

        }

        // symbols
        if (this.openingMode == 'Fix') {
            g.moveTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
            g.lineTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
            g.stroke();
        }

        if (this.openingMode == 'Bukó-toló' || this.openingMode == 'Bukó-toló k') {
            g.moveTo(calculatedXPosition + mmToPixel(this.width / 2 - 6000), calculatedYPosition + mmToPixel(this.height / 2));
            g.lineTo(calculatedXPosition + mmToPixel(this.width / 2 + 6000), calculatedYPosition + mmToPixel(this.height / 2));
            g.stroke();

            if (this.openingSide == 'Jobb') {
                g.moveTo(calculatedXPosition + mmToPixel(this.width / 2 + 6000), calculatedYPosition + mmToPixel(this.height / 2));
                g.lineTo(calculatedXPosition + mmToPixel(this.width / 2 + 4000), calculatedYPosition + mmToPixel(this.height / 2 - 1500));
                g.stroke();

                g.moveTo(calculatedXPosition + mmToPixel(this.width / 2 + 6000), calculatedYPosition + mmToPixel(this.height / 2));
                g.lineTo(calculatedXPosition + mmToPixel(this.width / 2 + 4000), calculatedYPosition + mmToPixel(this.height / 2 + 1500));
                g.stroke();
            } else {
                g.moveTo(calculatedXPosition + mmToPixel(this.width / 2 - 6000), calculatedYPosition + mmToPixel(this.height / 2));
                g.lineTo(calculatedXPosition + mmToPixel(this.width / 2 - 4000), calculatedYPosition + mmToPixel(this.height / 2 - 1500));
                g.stroke();

                g.moveTo(calculatedXPosition + mmToPixel(this.width / 2 - 6000), calculatedYPosition + mmToPixel(this.height / 2));
                g.lineTo(calculatedXPosition + mmToPixel(this.width / 2 - 4000), calculatedYPosition + mmToPixel(this.height / 2 + 1500));
                g.stroke();
            }
        }

        if (this.openingMode == 'Nyíló' || this.openingMode == 'Bukó-nyíló') {
            if (this.openingSide == 'Bal') {
                g.moveTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
                g.lineTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.height / 2));
                g.lineTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
                g.stroke();
            } else {
                g.moveTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
                g.lineTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.height / 2));
                g.lineTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
                g.stroke();
            }
        }

        if (this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
            // left wing
            g.moveTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
            g.lineTo(calculatedXPosition + mmToPixel(this.kfnyDivider - this.frameWidth - 400), calculatedYPosition + mmToPixel(this.height / 2));
            g.lineTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
            g.stroke();

            // right wing
            g.moveTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
            g.lineTo(calculatedXPosition + mmToPixel(this.kfnyDivider + this.frameWidth + 400), calculatedYPosition + mmToPixel(this.height / 2));
            g.lineTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
            g.stroke();
        }

        if (this.openingMode == 'KFNY-BNY') {
            if (this.openingSide == 'Jobb') {
                g.moveTo(calculatedXPosition + mmToPixel(this.kfnyDivider + this.frameWidth + 400), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
                g.lineTo(calculatedXPosition + mmToPixel(this.kfnyDivider + this.frameWidth + (this.width - this.kfnyDivider - this.frameWidth * 2 - this.frameSpacing[1]) / 2 + 400), calculatedYPosition + mmToPixel(this.frameWidth + this.frameSpacing[0]));
                g.lineTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
                g.stroke();
            } else {
                g.moveTo(calculatedXPosition + mmToPixel(this.frameWidth + this.frameSpacing[3]), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
                g.lineTo(calculatedXPosition + mmToPixel(this.frameWidth + this.frameSpacing[3]) + mmToPixel(this.kfnyDivider - this.frameWidth * 2 - this.frameSpacing[3] + 400) / 2, calculatedYPosition + mmToPixel(this.frameWidth + this.frameSpacing[0]));
                g.lineTo(calculatedXPosition + mmToPixel(this.kfnyDivider - this.frameWidth - 400), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
                g.stroke();
            }
        }

        if (this.openingMode == 'Bukó-nyíló' || this.openingMode == 'Bukó') {
            g.moveTo(calculatedXPosition + mmToPixel(this.width / 2), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
            g.lineTo(calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
            g.lineTo(calculatedXPosition + mmToPixel(this.width / 2), calculatedYPosition + mmToPixel(this.frameSpacing[0] + this.frameWidth));
            g.lineTo(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - this.frameWidth));
            g.stroke();
        }
        
        // hinges
        g.fillStyle = color;
        if (this.hingeType == 'Ajtó-iq') {
            if ((this.openingSide == 'Jobb' && (this.openingMode == 'Nyíló' || this.openingMode == 'Bukó-nyíló')) || this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
                g.fillRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 10 - 5000), mmToPixel(3000), mmToPixel(10000));
                g.strokeRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 10 - 5000), mmToPixel(3000), mmToPixel(10000));

                g.fillRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 10 * 5 - 5000), mmToPixel(3000), mmToPixel(10000));
                g.strokeRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 10 * 5 - 5000), mmToPixel(3000), mmToPixel(10000));

                g.fillRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 10 * 9 - 5000), mmToPixel(3000), mmToPixel(10000));
                g.strokeRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 10 * 9 - 5000), mmToPixel(3000), mmToPixel(10000));
            }

            if ((this.openingSide == 'Bal' && (this.openingMode == 'Nyíló' || this.openingMode == 'Bukó-nyíló')) || this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
                g.fillRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 10 - 5000), mmToPixel(3000), mmToPixel(10000));
                g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 10 - 5000), mmToPixel(3000), mmToPixel(10000));

                g.fillRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 10 * 5 - 5000), mmToPixel(3000), mmToPixel(10000));
                g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 10 * 5 - 5000), mmToPixel(3000), mmToPixel(10000));

                g.fillRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 10 * 9 - 5000), mmToPixel(3000), mmToPixel(10000));
                g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 10 * 9 - 5000), mmToPixel(3000), mmToPixel(10000));
            }
        } else if(this.hingeType == 'Ablak' || this.hingeType == 'Ajtó-ablak') {
            if (this.openingMode == 'Nyíló' || this.openingMode == 'Bukó-nyíló' || this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
                if (this.openingSide == 'Jobb' || this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
                    g.fillRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 4 - 5000), mmToPixel(3000), mmToPixel(10000));
                    g.strokeRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 4 - 5000), mmToPixel(3000), mmToPixel(10000));

                    g.fillRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 4 * 3 - 5000), mmToPixel(3000), mmToPixel(10000));
                    g.strokeRect(calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - 1600), calculatedYPosition + mmToPixel(this.height / 4 * 3 - 5000), mmToPixel(3000), mmToPixel(10000));
                }

                if (this.openingSide == 'Bal' || this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
                    g.fillRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 4 - 5000), mmToPixel(3000), mmToPixel(10000));
                    g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 4 - 5000), mmToPixel(3000), mmToPixel(10000));

                    g.fillRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 4 * 3 - 5000), mmToPixel(3000), mmToPixel(10000));
                    g.strokeRect(calculatedXPosition + mmToPixel(this.frameSpacing[3] - 1600), calculatedYPosition + mmToPixel(this.height / 4 * 3 - 5000), mmToPixel(3000), mmToPixel(10000));
                }
            }
            
            if (this.openingMode == 'Bukó') {
                g.fillRect(calculatedXPosition + mmToPixel(this.width / 4 - 5000), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - 1600), mmToPixel(10000), mmToPixel(3000));
                g.strokeRect(calculatedXPosition + mmToPixel(this.width / 4 - 5000), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - 1600), mmToPixel(10000), mmToPixel(3000));

                g.fillRect(calculatedXPosition + mmToPixel(this.width / 4 * 3 - 5000), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - 1600), mmToPixel(10000), mmToPixel(3000));
                g.strokeRect(calculatedXPosition + mmToPixel(this.width / 4 * 3 - 5000), calculatedYPosition + mmToPixel(this.height - this.frameSpacing[2] - 1600), mmToPixel(10000), mmToPixel(3000));
            }
        }

        // draw out drag over new divider
        if (this.dividerPosition !== -1) {
            g.strokeStyle = "rgb(0, 100, 255)";
            g.lineCap = 'square';
            g.beginPath();

            if (this.dividerDirection == 'horizontal')
            {
                g.moveTo(calculatedXPosition, calculatedYPosition + mmToPixel(this.dividerPosition));
                g.lineTo(calculatedXPosition + mmToPixel(this.width), calculatedYPosition + mmToPixel(this.dividerPosition));
                g.stroke();
            } else {
                g.moveTo(calculatedXPosition + mmToPixel(this.dividerPosition), calculatedYPosition);
                g.lineTo(calculatedXPosition + mmToPixel(this.dividerPosition), calculatedYPosition + mmToPixel(this.height));
                g.stroke();
            }

            g.strokeStyle = 'rgb(0, 0, 0)';
        }

        // draw out wing dividers
        for (var i = 0; i < this.dividers.length; i++) {
            g.fillStyle = "#ffffff";

            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                g.fillRect(offsetX + mmToPixel(this.dividers[i][0] - this.dividerWidth / 2), offsetY + mmToPixel(this.dividers[i][1]), mmToPixel(this.dividerWidth), mmToPixel(this.dividers[i][3] - this.dividers[i][1]));
                g.strokeRect(offsetX + mmToPixel(this.dividers[i][0] - this.dividerWidth / 2), offsetY + mmToPixel(this.dividers[i][1]), mmToPixel(this.dividerWidth), mmToPixel(this.dividers[i][3] - this.dividers[i][1]));
            } else {
                // horizontal
                g.fillRect(offsetX + mmToPixel(this.dividers[i][0]), offsetY + mmToPixel(this.dividers[i][1] - this.dividerWidth / 2), mmToPixel(this.dividers[i][2] - this.dividers[i][0]), mmToPixel(this.dividerWidth));
                g.strokeRect(offsetX + mmToPixel(this.dividers[i][0]), offsetY + mmToPixel(this.dividers[i][1] - this.dividerWidth / 2), mmToPixel(this.dividers[i][2] - this.dividers[i][0]), mmToPixel(this.dividerWidth));
            }

            if (i == this.selectedDividerIndex) {
                var blinking = (new Date().getTime() / 1.1) % 2000 / 1000.0;
                if (blinking > 1) {
                    blinking = 2 - blinking;
                }

                blinking = blinking / 2.0 + 0.5;
                g.fillStyle = "rgba(0, 100, 255, " + blinking + ")";

            } else {
                g.fillStyle = color;
            }

            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                g.fillRect(offsetX + mmToPixel(this.dividers[i][0] - this.dividerWidth / 2), offsetY + mmToPixel(this.dividers[i][1]), mmToPixel(this.dividerWidth), mmToPixel(this.dividers[i][3] - this.dividers[i][1]));
                g.strokeRect(offsetX + mmToPixel(this.dividers[i][0] - this.dividerWidth / 2), offsetY + mmToPixel(this.dividers[i][1]), mmToPixel(this.dividerWidth), mmToPixel(this.dividers[i][3] - this.dividers[i][1]));
            } else {
                // horizontal
                g.fillRect(offsetX + mmToPixel(this.dividers[i][0]), offsetY + mmToPixel(this.dividers[i][1] - this.dividerWidth / 2), mmToPixel(this.dividers[i][2] - this.dividers[i][0]), mmToPixel(this.dividerWidth));
                g.strokeRect(offsetX + mmToPixel(this.dividers[i][0]), offsetY + mmToPixel(this.dividers[i][1] - this.dividerWidth / 2), mmToPixel(this.dividers[i][2] - this.dividers[i][0]), mmToPixel(this.dividerWidth));
            }
        }

        

        // handle
        g.fillStyle = color;

        // set the handle height 170cm for doors and adjust 
        // if the door height is lower than 170cm
        var handleHeight = calculatedYPosition + mmToPixel(this.height - 107000);
        if (this.height < 107000) {
            handleHeight += mmToPixel(107000 - this.height + 15000);
        }

        if (this.handle.type !== 'Ajtó') {
            handleHeight = calculatedYPosition + mmToPixel(this.height / 2);
        }

        if (this.openingMode == 'Nyíló' || this.openingMode == 'Bukó-nyíló') {
            if (this.openingSide == 'Jobb') {
                this.handle.drawout(g, calculatedXPosition + mmToPixel(this.frameSpacing[3] + 1500), handleHeight);
            } else {
                this.handle.drawout(g, calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth + 1500), handleHeight);
            }
        } else if (this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
            if (this.openingSide == 'Jobb') {
                this.handle.drawout(g, calculatedXPosition + mmToPixel(this.kfnyDivider + 2300), handleHeight);
            } else {
                this.handle.drawout(g, calculatedXPosition + mmToPixel(this.kfnyDivider - this.frameWidth + 500), handleHeight);
            }
        }

        if (this.openingMode == 'Bukó-toló' || this.openingMode == 'Bukó-toló k') {
            if (this.openingSide == 'Jobb') {
                this.handle.drawout(g, calculatedXPosition + mmToPixel(this.frameSpacing[3] + this.frameWidth / 2 - 1500), handleHeight);
            } else {
                this.handle.drawout(g, calculatedXPosition + mmToPixel(this.width - this.frameSpacing[1] - this.frameWidth / 2 - 1500), handleHeight);
            }
        }

        if (this.openingMode == 'Bukó') {
            this.handle.drawout(g, calculatedXPosition + mmToPixel(this.width / 2), calculatedYPosition + mmToPixel(this.frameSpacing[0] + 1500));
        }
    }

    selectGlassUnderMouse(mouseX, mouseY) {
        this.selectedGlassIndex = -1;
        for (var i = 0; i < this.glasses.length; i++) {
            if (mouseX > this.glasses[i].x && mouseX < this.glasses[i].x + this.glasses[i].width &&
                mouseY > this.glasses[i].y && mouseY < this.glasses[i].y + this.glasses[i].height) {
                this.glasses[i].selected = true;
                this.selectedGlassIndex = i;
                updateGlassInput(this.glasses[i]);
            } else {
                this.glasses[i].selected = false;
            }
        }
    }

    // returns true if the selected divided is deletable,
    // and false if it's not or there is no selected divider
    selectWingDividerUnderMouse(mouseX, mouseY) {
        this.selectedDividerIndex = -1;
        
        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2] && 
                mouseX > this.dividers[i][0] - this.dividerWidth / 2 && mouseX < this.dividers[i][0] + this.dividerWidth / 2 &&
                mouseY > this.dividers[i][1] && mouseY < this.dividers[i][3]) {
                this.selectedDividerIndex = i;
                updateWingDividerInput(this.dividers[i][0], 0, 20000);
            }

            if (this.dividers[i][1] == this.dividers[i][3] && 
                mouseX > this.dividers[i][0] && mouseX < this.dividers[i][2] && 
                mouseY > this.dividers[i][1] - this.dividerWidth / 2 && mouseY < this.dividers[i][1] + this.dividerWidth / 2) {
                this.selectedDividerIndex = i;
                updateWingDividerInput(this.dividers[i][1], 0, 20000);
            }
        }
        
        this.updateWingDividerInputValues();
    }

    isSelectedDividerDeletable() {
        if(this.selectedDividerIndex == -1) {
            return false;
        }
        
        var isDeletable = true;
        // check if divider is deletable
        if (this.dividers[this.selectedDividerIndex][0] == this.dividers[this.selectedDividerIndex][2]) {
            // vertical
            for (var i = 0; i < this.dividers.length; i ++) {
                if (this.dividers[i][1] == this.dividers[i][3] &&
                    this.dividers[i][1] >= this.dividers[this.selectedDividerIndex][1] &&
                    this.dividers[i][1] <= this.dividers[this.selectedDividerIndex][3] && (
                    this.dividers[i][0] == this.dividers[this.selectedDividerIndex][0] + this.dividerWidth / 2 ||
                    this.dividers[i][2] == this.dividers[this.selectedDividerIndex][0] - this.dividerWidth / 2)) {
                        isDeletable = false;
                }
            }
        } else {
            // horizontal
            for (var i = 0; i < this.dividers.length; i ++) {
                if (this.dividers[i][0] == this.dividers[i][2] &&
                    this.dividers[i][0] >= this.dividers[this.selectedDividerIndex][0] &&
                    this.dividers[i][0] <= this.dividers[this.selectedDividerIndex][2] && (
                    this.dividers[i][1] == this.dividers[this.selectedDividerIndex][1] + this.dividerWidth / 2 ||
                    this.dividers[i][3] == this.dividers[this.selectedDividerIndex][1] - this.dividerWidth / 2)) {
                        isDeletable = false;
                }
            }
        }

        return isDeletable;
    }

    deleteSelectedObject() {
        if (this.selectedDividerIndex == -1) {
            return;
        }

        if (this.dividers[this.selectedDividerIndex][0] == this.dividers[this.selectedDividerIndex][2]) {
            // vertical
            var deletedGlassWidth = 0;
            // delete second glass
            for (var i = 0; i < this.glasses.length; i++) {
                if (this.glasses[i].x == this.dividers[this.selectedDividerIndex][0] + this.dividerWidth / 2 &&
                    this.glasses[i].y == this.dividers[this.selectedDividerIndex][1] &&
                    this.glasses[i].y + this.glasses[i].height == this.dividers[this.selectedDividerIndex][3]) {
                        deletedGlassWidth = this.glasses[i].width;
                        this.glasses.splice(i, 1);
                    }
            }

            // extend first glass
            for (var i = 0; i < this.glasses.length; i++) {
                if (this.glasses[i].x + this.glasses[i].width == this.dividers[this.selectedDividerIndex][0] - this.dividerWidth / 2 &&
                    this.glasses[i].y == this.dividers[this.selectedDividerIndex][1] &&
                    this.glasses[i].y + this.glasses[i].height == this.dividers[this.selectedDividerIndex][3]) {
                        this.glasses[i].width += deletedGlassWidth + this.dividerWidth;
                    }
            }

            this.dividers.splice(this.selectedDividerIndex, 1);
            this.selectedDividerIndex = -1;
        } else {
            // horizontal
            var deletedGlassHeight = 0;
            // delete second glass
            for (var i = 0; i < this.glasses.length; i++) {
                if (this.glasses[i].y == this.dividers[this.selectedDividerIndex][1] + this.dividerWidth / 2 &&
                    this.glasses[i].x == this.dividers[this.selectedDividerIndex][0] &&
                    this.glasses[i].x + this.glasses[i].width == this.dividers[this.selectedDividerIndex][2]) {
                        deletedGlassHeight = this.glasses[i].height;
                        this.glasses.splice(i, 1);
                    }
            }

            // extend first glass
            for (var i = 0; i < this.glasses.length; i++) {
                if (this.glasses[i].y + this.glasses[i].height == this.dividers[this.selectedDividerIndex][1] - this.dividerWidth / 2 &&
                    this.glasses[i].x == this.dividers[this.selectedDividerIndex][0] &&
                    this.glasses[i].x + this.glasses[i].width == this.dividers[this.selectedDividerIndex][2]) {
                        this.glasses[i].height += deletedGlassHeight + this.dividerWidth;
                    }
            }

            this.dividers.splice(this.selectedDividerIndex, 1);
            this.selectedDividerIndex = -1;
        }
    }

    setSelectedGlassAttributes(glassType, glassWidth, glassFrame) {
        if (this.selectedGlassIndex == -1) {
            return;
        }

        this.glasses[this.selectedGlassIndex].glassType = glassType;
        this.glasses[this.selectedGlassIndex].glassWidth = glassWidth;
        this.glasses[this.selectedGlassIndex].glassFrame = glassFrame;
    }

    setAllGlassAttributes(glassType, glassWidth, glassFrame) {
        for (var i = 0; i < this.glasses.length; i++) {
            this.glasses[i].glassType = glassType;
            this.glasses[i].glassWidth = glassWidth;
            this.glasses[i].glassFrame = glassFrame;
        }
    }

    setPosition(newX, newY) {
        var horizontalDifference = newX - this.x;
        var verticalDifference = newY - this.y;

        for (var i = 0; i < this.glasses.length; i++) {
            this.glasses[i].x += horizontalDifference;
            this.glasses[i].y += verticalDifference;
        }
        
        for (var i = 0; i < this.dividers.length; i++) {
            this.dividers[i][0] += horizontalDifference;
            this.dividers[i][2] += horizontalDifference;
            this.dividers[i][1] += verticalDifference;
            this.dividers[i][3] += verticalDifference;
        }

        this.x = newX;
        this.y = newY;
    }

    setSize(newWidth, newHeight) {
        var widthDifference = newWidth / this.width;
        var heightDifference = newHeight / this.height;
        var newKfnyDivider = parseInt((this.kfnyDivider * widthDifference) / 100) * 100;

        for (var i = 0; i < this.dividers.length; i ++) {
            if (heightDifference !== 1 && this.dividers[i][1] == this.dividers[i][3]) {
                // horizontal
                var dividerYPosition = this.dividers[i][1];

                // search for connected glasses
                for (var j = 0; j < this.glasses.length; j ++) {
                    if (this.glasses[j].x + this.glasses[j].width < this.dividers[i][0] || 
                        this.glasses[j].x > this.dividers[i][2]) {
                        continue;
                    }

                    if (this.glasses[j].y + this.glasses[j].height == dividerYPosition - this.dividerWidth / 2) {
                        this.glasses[j].height = parseInt((dividerYPosition - this.y) * heightDifference) + this.y - this.glasses[j].y - this.dividerWidth / 2;
                    }

                    if (this.glasses[j].y == dividerYPosition + this.dividerWidth / 2) {
                        this.glasses[j].height -= parseInt((dividerYPosition - this.y) * heightDifference) + this.y - this.glasses[j].y + this.dividerWidth / 2;
                        this.glasses[j].y = parseInt((dividerYPosition - this.y) * heightDifference) + this.y + this.dividerWidth / 2;
                    }
                }

                // search for connected vertical dividers
                for (var j = 0; j < this.dividers.length; j ++) {
                    if (this.dividers[j][0] !== this.dividers[j][2] ||
                        this.dividers[j][0] < this.dividers[i][0] ||
                        this.dividers[j][0] > this.dividers[i][2]) {
                        continue;
                    }

                    if (this.dividers[j][1] == dividerYPosition + this.dividerWidth / 2) {
                        this.dividers[j][1] = parseInt((dividerYPosition - this.y) * heightDifference) + this.y + this.dividerWidth / 2;
                    }

                    if (this.dividers[j][3] == dividerYPosition - this.dividerWidth / 2) {
                        this.dividers[j][3] = parseInt((dividerYPosition - this.y) * heightDifference) + this.y - this.dividerWidth / 2;
                    }
                }

                this.dividers[i][1] = parseInt((dividerYPosition - this.y) * heightDifference) + this.y;
                this.dividers[i][3] = parseInt((dividerYPosition - this.y) * heightDifference) + this.y;
            }

            if (widthDifference !== 1 && this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                var dividerXPosition = this.dividers[i][0];

                // search for connected glasses
                for (var j = 0; j < this.glasses.length; j ++) {
                    if (this.glasses[j].y + this.glasses[j].height < this.dividers[i][1] || 
                        this.glasses[j].y > this.dividers[i][3]) {
                        continue;
                    }

                    if (this.glasses[j].x + this.glasses[j].width == dividerXPosition - this.dividerWidth / 2) {
                        this.glasses[j].width = parseInt((dividerXPosition - this.x) * widthDifference) + this.x - this.glasses[j].x - this.dividerWidth / 2;
                    }

                    if (this.glasses[j].x == dividerXPosition + this.dividerWidth / 2) {
                        this.glasses[j].width -= parseInt((dividerXPosition - this.x) * widthDifference) + this.x - this.glasses[j].x + this.dividerWidth / 2;
                        this.glasses[j].x = parseInt((dividerXPosition - this.x) * widthDifference) + this.x + this.dividerWidth / 2;
                    }
                }

                // search for connected horizontal dividers
                for (var j = 0; j < this.dividers.length; j ++) {
                    if (this.dividers[j][0] == this.dividers[j][2] ||
                        this.dividers[j][1] < this.dividers[i][1] ||
                        this.dividers[j][1] > this.dividers[i][3]) {
                        continue;
                    }

                    if (this.dividers[j][0] == dividerXPosition + this.dividerWidth / 2) {
                        this.dividers[j][0] = parseInt((dividerXPosition - this.x) * widthDifference) + this.x + this.dividerWidth / 2;
                    }

                    if (this.dividers[j][2] == dividerXPosition - this.dividerWidth / 2) {
                        this.dividers[j][2] = parseInt((dividerXPosition - this.x) * widthDifference) + this.x - this.dividerWidth / 2;
                    }
                }

                this.dividers[i][0] = parseInt((dividerXPosition - this.x) * widthDifference) + this.x;
                this.dividers[i][2] = parseInt((dividerXPosition - this.x) * widthDifference) + this.x;
            }

            if (heightDifference !== 1 && this.dividers[i][0] == this.dividers[i][2] &&
                this.dividers[i][3] == this.y + this.height - this.frameWidth - this.frameSpacing[2]) {
                    this.dividers[i][3] = this.y + newHeight - this.frameWidth - this.frameSpacing[2]
            }

            if (widthDifference !== 1 && this.dividers[i][1] == this.dividers[i][3] &&
                this.dividers[i][2] == this.x + this.width - this.frameWidth - this.frameSpacing[1]) {
                    this.dividers[i][2] = this.x + newWidth - this.frameWidth - this.frameSpacing[1]
            }

            if ((this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') &&
                widthDifference !== 1 && this.dividers[i][1] == this.dividers[i][3] &&
                this.dividers[i][2] == this.x + this.kfnyDivider - this.frameWidth - 400) {
                this.dividers[i][2] = this.x + newKfnyDivider - this.frameWidth - 400;
            }

            if ((this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') &&
                widthDifference !== 1 && this.dividers[i][1] == this.dividers[i][3] &&
                this.dividers[i][0] == this.x + this.kfnyDivider + this.frameWidth + 400) {
                this.dividers[i][0] = this.x + newKfnyDivider + this.frameWidth + 400;
            }
            
        }

        for (var i = 0; i < this.glasses.length; i++) {
            var newGlassXPosition = this.glasses[i].x;
            var newGlassYPosition = this.glasses[i].y;
            var newGlassWidth = this.glasses[i].width;
            var newGlassHeight = this.glasses[i].height;

            if (this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
                if (this.glasses[i].x + this.glasses[i].width == this.x + this.kfnyDivider - this.frameWidth - 400) {
                    newGlassWidth = this.x + newKfnyDivider - this.frameWidth - 400 - this.glasses[i].x;
                }

                if (this.glasses[i].x == this.x + this.kfnyDivider + this.frameWidth + 400) {
                    newGlassXPosition = this.x + newKfnyDivider + this.frameWidth + 400;
                    newGlassWidth -= newGlassXPosition - this.glasses[i].x;
                }

            }

            if (this.glasses[i].x + this.glasses[i].width == this.x + this.width - this.frameSpacing[1] - this.frameWidth) {
                newGlassWidth = this.x + newWidth - this.frameSpacing[1] - this.frameWidth - newGlassXPosition;
            }

            if (this.glasses[i].y + this.glasses[i].height == this.y + this.height - this.frameSpacing[2] - this.frameWidth) {
                newGlassHeight = this.y + newHeight - this.frameSpacing[2] - this.frameWidth - newGlassYPosition;
            }

            this.glasses[i].x = newGlassXPosition;
            this.glasses[i].y = newGlassYPosition;
            this.glasses[i].width = newGlassWidth;
            this.glasses[i].height = newGlassHeight;
        }

        this.width = newWidth;
        this.height = newHeight;
        this.kfnyDivider = newKfnyDivider;
    }

    alignDividersToMm() {
        for (var i = 0; i < this.dividers.length; i++) {
            this.selectedDividerIndex = i;
            if (this.dividers[i][0] == this.dividers[i][2]) {
                var difference = this.dividers[i][0] % 100;
                if (difference < 50) {
                    this.setSelectedWingDividerPosition(this.dividers[i][0], this.dividers[i][0] - difference);
                } else {
                    difference = 100 - difference;
                    this.setSelectedWingDividerPosition(this.dividers[i][0], this.dividers[i][0] + difference);
                }
            } else {
                var difference = this.dividers[i][1] % 100;
                if (difference < 50) {
                    this.setSelectedWingDividerPosition(this.dividers[i][1], this.dividers[i][1] - difference);
                } else {
                    difference = 100 - difference;
                    this.setSelectedWingDividerPosition(this.dividers[i][1], this.dividers[i][1] + difference);
                }
            }
        }
    }
    
    setFrameWidth(newFrameWidth) {
        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                if (this.dividers[i][1] == this.y + this.frameSpacing[0] + this.frameWidth) {
                    this.dividers[i][1] = this.y + this.frameSpacing[0] + newFrameWidth;
                }

                if (this.dividers[i][3] == this.y + this.height - this.frameSpacing[2] - this.frameWidth) {
                    this.dividers[i][3] = this.y + this.height - this.frameSpacing[2] - newFrameWidth;
                }
            } else {
                // horizontal
                if (this.dividers[i][0] == this.x + this.frameSpacing[3] + this.frameWidth) {
                    this.dividers[i][0] = this.x + this.frameSpacing[3] + newFrameWidth;
                }

                if ((this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY')
                    && this.dividers[i][0] == this.x + this.kfnyDivider + 400 + this.frameWidth) {
                    this.dividers[i][0] = this.x + this.kfnyDivider + 400 + newFrameWidth;
                }

                if (this.dividers[i][2] == this.x + this.width - this.frameSpacing[1] - this.frameWidth) {
                    this.dividers[i][2] = this.x + this.width - this.frameSpacing[1] - newFrameWidth;
                }

                if ((this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY')
                    && this.dividers[i][2] == this.x + this.kfnyDivider - 400 - this.frameWidth) {
                    this.dividers[i][2] = this.x + this.kfnyDivider - 400 - newFrameWidth;
                }
            }
        }
        
        for (var i = 0; i < this.glasses.length; i++) {
            var newXPosition = this.glasses[i].x;
            var newYPosition = this.glasses[i].y;
            var newWidth = this.glasses[i].width;
            var newHeight = this.glasses[i].height;

            if (this.glasses[i].x == this.x + this.frameSpacing[3] + this.frameWidth) {
                newXPosition += newFrameWidth - this.frameWidth;
                newWidth -= newFrameWidth - this.frameWidth;
            }

            if ((this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') &&
                this.glasses[i].x == this.x + this.kfnyDivider + this.frameWidth + 400) {
                newXPosition += newFrameWidth - this.frameWidth;
                newWidth -= newFrameWidth - this.frameWidth;
            }

            if (this.glasses[i].y == this.y + this.frameSpacing[0] + this.frameWidth) {
                newYPosition += newFrameWidth - this.frameWidth;
                newHeight -= newFrameWidth - this.frameWidth;
            }

            if (this.glasses[i].x + this.glasses[i].width == this.x + this.width - this.frameSpacing[1] - this.frameWidth) {
                newWidth -= newFrameWidth - this.frameWidth;
            }

            if ((this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') &&
                this.glasses[i].x + this.glasses[i].width == this.x + this.kfnyDivider - this.frameWidth - 400) {
                newWidth -= newFrameWidth - this.frameWidth;
            }

            if (this.glasses[i].y + this.glasses[i].height == this.y + this.height - this.frameSpacing[2] - this.frameWidth) {
                newHeight -= newFrameWidth - this.frameWidth;
            }

            this.glasses[i].x = newXPosition;
            this.glasses[i].y = newYPosition;
            this.glasses[i].width = newWidth;
            this.glasses[i].height = newHeight;
        }
        
        this.frameWidth = newFrameWidth;
    }

    setDividerSize(newSize) {
        var oldSpace = this.dividerWidth / 2;
        var newSpace = newSize / 2;

        for (var i = 0; i < this.dividers.length; i ++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical

                // check for connected glasses
                for (var j = 0; j < this.glasses.length; j ++) {
                    if ((this.glasses[j].y + this.glasses[j].height >= this.dividers[i][1] &&
                        this.glasses[j].y + this.glasses[j].height <= this.dividers[i][3]) || (
                        this.glasses[j].y >= this.dividers[i][1] &&
                        this.glasses[j].y <= this.dividers[i][3])) {
                        if (this.glasses[j].x == this.dividers[i][0] + oldSpace) {
                            this.glasses[j].x = this.dividers[i][0] + newSpace;
                            this.glasses[j].width -= newSpace - oldSpace;
                        }

                        if (this.glasses[j].x + this.glasses[j].width == this.dividers[i][0] - oldSpace) {
                            this.glasses[j].width -= newSpace - oldSpace;
                        }
                    }
                }

                // check for connected horizontal dividers
                for (var j = 0; j < this.dividers.length; j ++) {
                    if (this.dividers[j][1] == this.dividers[j][3] &&
                        this.dividers[j][1] > this.dividers[i][1] &&
                        this.dividers[j][3] < this.dividers[i][3]) {
                        if (this.dividers[j][0] == this.dividers[i][0] + oldSpace) {
                            this.dividers[j][0] = this.dividers[i][0] + newSpace;
                        }

                        if (this.dividers[j][2] == this.dividers[i][0] - oldSpace) {
                            this.dividers[j][2] = this.dividers[i][0] - newSpace;
                        }
                    }
                }
            } else {
                // horizontal

                // check for connected glasses
                for (var j = 0; j < this.glasses.length; j ++) {
                    if ((this.glasses[j].x + this.glasses[j].width >= this.dividers[i][0] &&
                        this.glasses[j].x + this.glasses[j].width <= this.dividers[i][2]) || (
                        this.glasses[j].x >= this.dividers[i][0] &&
                        this.glasses[j].x <= this.dividers[i][2])) {
                        if (this.glasses[j].y == this.dividers[i][1] + oldSpace) {
                            this.glasses[j].y = this.dividers[i][1] + newSpace;
                            this.glasses[j].height -= newSpace - oldSpace;
                        }

                        if (this.glasses[j].y + this.glasses[j].height == this.dividers[i][1] - oldSpace) {
                            this.glasses[j].height -= newSpace - oldSpace;
                        }
                    }
                }

                // check for connected vertical dividers
                for (var j = 0; j < this.dividers.length; j ++) {
                    if (this.dividers[j][0] == this.dividers[j][2] &&
                        this.dividers[j][0] > this.dividers[i][0] &&
                        this.dividers[j][2] < this.dividers[i][2]) {
                        if (this.dividers[j][1] == this.dividers[i][1] + oldSpace) {
                            this.dividers[j][1] = this.dividers[i][1] + newSpace;
                        }

                        if (this.dividers[j][3] == this.dividers[i][1] - oldSpace) {
                            this.dividers[j][3] = this.dividers[i][1] - newSpace;
                        }
                    }
                }
            }
        }

        this.dividerWidth = newSize;
    }

    setOpeningMode(newOpeningMode) {
        var currentGlassType = 'Üveg';
        var currentGlassWidth = '24mm';
        var currentGlassFrame = 'alukeret';
        
        if (this.glasses.length > 0) {
            currentGlassType = this.glasses[0].glassType;
            currentGlassWidth = this.glasses[0].glassWidth;
            currentGlassFrame = this.glasses[0].glassFrame;
        }

        this.glasses = [];
        this.dividers = [];
        if (newOpeningMode == 'KFNY' || newOpeningMode == 'KFNY-BNY') {
            this.glasses.push(new Glass(this.x + this.frameSpacing[3] + this.frameWidth, this.y + this.frameSpacing[0] + this.frameWidth,
                this.kfnyDivider - this.frameWidth * 2 - this.frameSpacing[3] - 400,
                this.height - this.frameWidth * 2 - this.frameSpacing[0] - this.frameSpacing[2]));

            this.glasses.push(new Glass(this.x + this.kfnyDivider + this.frameWidth + 400, this.y + this.frameSpacing[0] + this.frameWidth,
                this.width - this.kfnyDivider - this.frameWidth * 2 - this.frameSpacing[1] - 400,
                this.height - this.frameWidth * 2 - this.frameSpacing[0] - this.frameSpacing[2]));
            
        } else {
            this.glasses.push(new Glass(this.x + this.frameSpacing[3] + this.frameWidth, this.y + this.frameSpacing[0] + this.frameWidth,
                this.width - this.frameWidth * 2 - this.frameSpacing[1] - this.frameSpacing[3],
                this.height - this.frameWidth * 2 - this.frameSpacing[0] - this.frameSpacing[2]));
        }

        this.setAllGlassAttributes(currentGlassType, currentGlassWidth, currentGlassFrame);
        this.openingMode = newOpeningMode;
        this.selectedGlassIndex = -1;
        hideGlassInput();
    }

    setFrameSpacing(newFrameSpacing) {
        for (var i = 0; i < this.glasses.length; i++) {
            
            var newGlassXPosition = this.glasses[i].x;
            var newGlassYPosition = this.glasses[i].y;
            var newGlassWidth = this.glasses[i].width;
            var newGlassHeight = this.glasses[i].height;

            if (this.glasses[i].x == this.x + this.frameSpacing[3] + this.frameWidth && this.frameSpacing[3] !== newFrameSpacing[3]) {
                newGlassXPosition += newFrameSpacing[3] - this.frameSpacing[3];
                newGlassWidth -= newFrameSpacing[3] - this.frameSpacing[3];
            }

            if (this.glasses[i].y == this.y + this.frameSpacing[0] + this.frameWidth && this.frameSpacing[0] !== newFrameSpacing[0]) {
                newGlassYPosition += newFrameSpacing[0] - this.frameSpacing[0];
                newGlassHeight -= newFrameSpacing[0] - this.frameSpacing[0];
            }

            if (this.glasses[i].x + this.glasses[i].width == this.x + this.width - this.frameSpacing[1] - this.frameWidth && this.frameSpacing[1] !== newFrameSpacing[1]) {
                newGlassWidth -= newFrameSpacing[1] - this.frameSpacing[1];
            }

            if (this.glasses[i].y + this.glasses[i].height == this.y + this.height - this.frameSpacing[2] - this.frameWidth && this.frameSpacing[2] !== newFrameSpacing[2]) {
                newGlassHeight -= newFrameSpacing[2] - this.frameSpacing[2];
            }
            
            this.glasses[i].x = newGlassXPosition;
            this.glasses[i].y = newGlassYPosition;
            this.glasses[i].width = newGlassWidth;
            this.glasses[i].height = newGlassHeight;
        }

        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                if (this.frameSpacing[0] != newFrameSpacing[0] && this.dividers[i][1] == this.y + this.frameSpacing[0] + this.frameWidth) {
                    this.dividers[i][1] = this.y + newFrameSpacing[0] + this.frameWidth;
                }

                if (this.frameSpacing[2] != newFrameSpacing[2] && this.dividers[i][3] == this.y + this.height - this.frameSpacing[2] - this.frameWidth) {
                    this.dividers[i][3] = this.y + this.height - newFrameSpacing[2] - this.frameWidth;
                }
            } else {
                // horizontal
                if (this.frameSpacing[3] != newFrameSpacing[3] && this.dividers[i][0] == this.x + this.frameSpacing[3] + this.frameWidth) {
                    this.dividers[i][0] = this.x + newFrameSpacing[3] + this.frameWidth;
                }

                if (this.frameSpacing[1] != newFrameSpacing[1] && this.dividers[i][2] == this.x + this.width - this.frameSpacing[1] - this.frameWidth) {
                    this.dividers[i][2] = this.x + this.width - newFrameSpacing[1] - this.frameWidth;
                }
            }
        }

        this.frameSpacing = newFrameSpacing;
    }

    setKfnyDivider(newKfnyDivider) {
        for (var i = 0; i < this.glasses.length; i++) {
            if (this.glasses[i].x + this.glasses[i].width == this.x + this.kfnyDivider - this.frameWidth - 400) {
                this.glasses[i].width = this.x + newKfnyDivider - this.frameWidth - 400 - this.glasses[i].x;
            }

            if (this.glasses[i].x == this.x + this.kfnyDivider + this.frameWidth + 400) {
                this.glasses[i].x = this.x + newKfnyDivider + this.frameWidth + 400;
                this.glasses[i].width -= newKfnyDivider - this.kfnyDivider;
            }
        }

        for (var i = 0; i < this.dividers.length; i ++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                continue;
            }

            if (this.dividers[i][2] == this.kfnyDivider - this.frameWidth - 400) {
                this.dividers[i][2] = newKfnyDivider - this.frameWidth - 400;
            }

            if (this.dividers[i][0] == this.kfnyDivider + this.frameWidth + 400) {
                this.dividers[i][0] = newKfnyDivider + this.frameWidth + 400;
            }
        }

        this.kfnyDivider = newKfnyDivider;
    }

    setSelectedWingDividerPosition(oldPosition, newPosition) {
        var selectedWingDivider = this.dividers[this.selectedDividerIndex];

        // reposition connected dividers
        for (var i = 0; i < this.dividers.length; i++) {
            if (selectedWingDivider[0] == selectedWingDivider[2]) {
                // vertical
                if (this.dividers[i][1] == this.dividers[i][3] && 
                    this.dividers[i][1] >= selectedWingDivider[1] && this.dividers[i][1] <= selectedWingDivider[3] &&
                    this.dividers[i][2] == oldPosition - this.dividerWidth / 2) {

                    this.dividers[i][2] = newPosition - this.dividerWidth / 2;
                }

                if (this.dividers[i][1] == this.dividers[i][3] && 
                    this.dividers[i][1] >= selectedWingDivider[1] && this.dividers[i][1] <= selectedWingDivider[3] &&
                    this.dividers[i][0] == oldPosition + this.dividerWidth / 2) {

                    this.dividers[i][0] = newPosition + this.dividerWidth / 2;
                }
            } else {
                // horizontal
                if (this.dividers[i][0] == this.dividers[i][2] && 
                    this.dividers[i][0] >= selectedWingDivider[0] && this.dividers[i][0] <= selectedWingDivider[2] &&
                    this.dividers[i][3] == oldPosition - this.dividerWidth / 2) {

                    this.dividers[i][3] = newPosition - this.dividerWidth / 2;
                }

                if (this.dividers[i][0] == this.dividers[i][2] && 
                    this.dividers[i][0] >= selectedWingDivider[0] && this.dividers[i][0] <= selectedWingDivider[2] &&
                    this.dividers[i][1] == oldPosition + this.dividerWidth / 2) {

                    this.dividers[i][1] = newPosition + this.dividerWidth / 2;
                }
            }
        }
    
        // reposition connected glasses
        for (var i = 0; i < this.glasses.length; i++) {
            if (selectedWingDivider[0] == selectedWingDivider[2]) {
                // vertical

                if (this.glasses[i].y + this.glasses[i].height < selectedWingDivider[1] ||
                    this.glasses[i].y > selectedWingDivider[3]) {
                        continue;
                }

                if (this.glasses[i].x == oldPosition + this.dividerWidth / 2) {
                    this.glasses[i].x = newPosition + this.dividerWidth / 2;
                    this.glasses[i].width -= newPosition - oldPosition;
                }

                if (this.glasses[i].x + this.glasses[i].width == oldPosition - this.dividerWidth / 2) {
                    this.glasses[i].width += newPosition - oldPosition;
                }
            } else {
                // horizontal

                if (this.glasses[i].x + this.glasses[i].width < selectedWingDivider[0] ||
                    this.glasses[i].x > selectedWingDivider[2]) {
                        continue;
                }

                if (this.glasses[i].y == oldPosition + this.dividerWidth / 2) {
                    this.glasses[i].y = newPosition + this.dividerWidth / 2;
                    this.glasses[i].height -= newPosition - oldPosition;
                }

                if (this.glasses[i].y + this.glasses[i].height == oldPosition - this.dividerWidth / 2) {
                    this.glasses[i].height += newPosition - oldPosition;
                }
            }
        }

        // reposition wing divider
        if (selectedWingDivider[0] == selectedWingDivider[2]) {
            // vertical
            selectedWingDivider[0] = newPosition;
            selectedWingDivider[2] = newPosition;
        } else {
            // horizontal
            selectedWingDivider[1] = newPosition;
            selectedWingDivider[3] = newPosition;
        }
    }

    setHandleType(handleType) {
        this.handle.type = handleType;
    }

    updateHandle() {
        var handleType = this.handle.type;

        if (this.openingMode == 'Nyíló' || this.openingMode == 'KFNY') {
            if (this.openingSide == 'Jobb') {
                this.handle = new Handle('V', 'R', handleType);
            } else {
                this.handle = new Handle('V', 'L', handleType);
            }
        }

        if (this.openingMode == 'Bukó-toló' || this.openingMode == 'Bukó-toló k') {
            if (this.openingSide == 'Jobb') {
                this.handle = new Handle('V', 'D', handleType);
            } else {
                this.handle = new Handle('V', 'D', handleType);
            }
        }

        if (this.openingMode == 'Bukó') {
            this.handle = new Handle('H', 'R', handleType);
        }

        if (this.openingMode == 'Bukó-nyíló' || this.openingMode == 'KFNY-BNY' ) {
            this.handle = new Handle('V', 'D', handleType);
        }
    }

    // returns true if something is changed in the wing
    // and false if didn't
    autoPositionWingDividers() {
        var glassesSumWidth = this.getGlassesSumSize()[0];
        var glassesSumHeight = this.getGlassesSumSize()[1];
        var dividerCount = this.dividers.length;

        var isAllVertical = true;
        var isAllHorizontal = true;

        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] !== this.dividers[i][2]) {
                isAllVertical = false;
            } else {
                isAllHorizontal = false;
            }
        }

        if (!isAllHorizontal && !isAllVertical) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Ez a funkció csak azokra szárnyakra alkalmazható, amelyekben kizárólag vízszintes vagy függőleges szárnyosztók vannak.'});
            return false;
        }

        if ((this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') && !isAllHorizontal) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'KFNY és KFNY-BNY szárnyakon ez a funkció csak horizontális szárnyosztókkal működik.'});
            return false;
        }

        var singleGlassSize = parseInt(glassesSumWidth / (dividerCount + 1));
        if (!isAllVertical) {
            singleGlassSize = parseInt(glassesSumHeight / (dividerCount + 1));

            if (glassesSumHeight / (dividerCount + 1) !== singleGlassSize) {
                dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Az üvegek nem oszthatóak el úgy, hogy egyenlő magasságúak legyenek.'});
            }
        } else if (glassesSumWidth / (dividerCount + 1) !== singleGlassSize) {
            dialog.showMessageBox(null, {buttons: ['Bezárás'], message: 'Az üvegek nem oszthatóak el úgy, hogy egyenlő szélességűek legyenek.'});
        }

        var glassesSizeBeforeLastOne = 0;
        for (var i = 0; i < this.glasses.length; i++) {
            if (isAllVertical) {
                if (i == this.glasses.length - 1) {
                    singleGlassSize = glassesSumWidth - glassesSizeBeforeLastOne;
                }

                while (this.glasses[i].width !== singleGlassSize) {
                    var difference = -1;
                    if (this.glasses[i].width < singleGlassSize) {
                        difference = 1;
                    }
                    
                    // reposition connected divider after glass
                    for (var j = 0; j < this.dividers.length; j++) {
                        if (this.dividers[j][0] < this.glasses[i].x + this.glasses[i].width + this.dividerWidth / 2) {
                            continue;
                        }

                        this.dividers[j][0] += difference;
                        this.dividers[j][2] += difference;
                    }

                    // reposition connected glass after current glass
                    for (var j = 0; j < this.glasses.length; j++) {
                        if (this.glasses[j].x < this.glasses[i].x + this.glasses[i].width + this.dividerWidth) {
                            continue;
                        }

                        this.glasses[j].x += difference;
                    }

                    this.glasses[i].width += difference;
                }

                glassesSizeBeforeLastOne += this.glasses[i].width;
            } else {
                if (i == this.glasses.length - 1) {
                    singleGlassSize = glassesSumHeight - glassesSizeBeforeLastOne;
                }

                while (this.glasses[i].height !== singleGlassSize) {
                    var difference = -1;
                    if (this.glasses[i].height < singleGlassSize) {
                        difference = 1;
                    }
                    
                    // reposition connected divider after glass
                    for (var j = 0; j < this.dividers.length; j++) {
                        if (this.dividers[j][1] < this.glasses[i].y + this.glasses[i].height + this.dividerWidth / 2) {
                            continue;
                        }

                        this.dividers[j][1] += difference;
                        this.dividers[j][3] += difference;
                    }

                    // reposition connected glass after current glass
                    for (var j = 0; j < this.glasses.length; j++) {
                        if (this.glasses[j].y < this.glasses[i].y + this.glasses[i].height + this.dividerWidth) {
                            continue;
                        }

                        this.glasses[j].y += difference;
                    }

                    this.glasses[i].height += difference;
                }

                glassesSizeBeforeLastOne += this.glasses[i].height;
            }
        }

        // round divider positions
        for (var i = 0; i < this.dividers.length; i++) {
            this.selectedDividerIndex = i;
            if (isAllVertical && this.dividers[i][0] == this.dividers[i][2]) {
                var difference = this.dividers[i][0] % 100;
                if (difference < 50) {
                    this.setSelectedWingDividerPosition(this.dividers[i][0], this.dividers[i][0] - difference);
                } else {
                    difference = 100 - difference;
                    this.setSelectedWingDividerPosition(this.dividers[i][0], this.dividers[i][0] + difference);
                }
            }

            if (isAllHorizontal && this.dividers[i][1] == this.dividers[i][3]) {
                var difference = this.dividers[i][1] % 100;
                if (difference < 50) {
                    this.setSelectedWingDividerPosition(this.dividers[i][1], this.dividers[i][1] - difference);
                } else {
                    difference = 100 - difference;
                    this.setSelectedWingDividerPosition(this.dividers[i][1], this.dividers[i][1] + difference);
                }
            }
        }
        
        this.selectedDividerIndex = -1;
        this.alignDividersToMm();
        return true;
    }

    // updates the input field value, minimum and maximum attributes
    // based on the currently selected divider
    updateWingDividerInputValues() {
        if (this.selectedDividerIndex == -1) {
            return;
        }

        var selectedDivider = this.dividers[this.selectedDividerIndex];
        var currentPosition;
        var minimumPosition;
        var maximumPosition;
        if (selectedDivider[0] == selectedDivider[2]) {
            // vertical
            currentPosition = selectedDivider[0];
            minimumPosition = this.x + this.frameSpacing[3] + this.frameWidth;
            maximumPosition = this.x + this.width - this.frameSpacing[1] - this.frameWidth;

            if (this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
                if (selectedDivider[0] < this.x + this.kfnyDivider) {
                    maximumPosition = this.x + this.kfnyDivider - 400 - this.frameWidth - this.frameWidth / 2;
                } else {
                    minimumPosition = this.x + this.kfnyDivider + 400 + this.frameWidth + this.frameWidth / 2;
                }
            }

            for (var i = 0; i < this.dividers.length; i ++) {
                if (i == this.selectedDividerIndex || this.dividers[i][1] == this.dividers[i][3]) {
                    continue;
                }

                // look for the minimum value the divider can be repositioned 
                if (this.dividers[i][0] < selectedDivider[0] && this.dividers[i][0] > minimumPosition &&
                    ((this.dividers[i][1] >= selectedDivider[1] && this.dividers[i][3] <= selectedDivider[3]) ||
                    (this.dividers[i][1] <= selectedDivider[1] && this.dividers[i][3] >= selectedDivider[3]))) {
                    minimumPosition = this.dividers[i][0];
                }

                // look for the maximum value the divider can be repositioned 
                if (this.dividers[i][0] > selectedDivider[0] && this.dividers[i][0] < maximumPosition &&
                    ((this.dividers[i][1] >= selectedDivider[1] && this.dividers[i][3] <= selectedDivider[3]) ||
                    (this.dividers[i][1] <= selectedDivider[1] && this.dividers[i][3] >= selectedDivider[3]))) {
                    maximumPosition = this.dividers[i][0];
                }
            }

        } else {
            // horizontal
            currentPosition = selectedDivider[1];
            minimumPosition = this.y + this.frameSpacing[0] + this.frameWidth;
            maximumPosition = this.y + this.height - this.frameSpacing[2] - this.frameWidth;
            for (var i = 0; i < this.dividers.length; i ++) {
                if (i == this.selectedDividerIndex || this.dividers[i][0] == this.dividers[i][2]) {
                    continue;
                }

                // look for the minimum value the divider can be repositioned 
                if (this.dividers[i][1] < selectedDivider[1] && this.dividers[i][1] > minimumPosition &&
                    ((this.dividers[i][0] >= selectedDivider[0] && this.dividers[i][2] <= selectedDivider[2]) ||
                    (this.dividers[i][0] <= selectedDivider[0] && this.dividers[i][2] >= selectedDivider[2]))) {
                    minimumPosition = this.dividers[i][1];
                }
                
                // look for the maximum value the divider can be repositioned 
                if (this.dividers[i][1] > selectedDivider[1] && this.dividers[i][1] < maximumPosition &&
                    ((this.dividers[i][0] >= selectedDivider[0] && this.dividers[i][2] <= selectedDivider[2]) ||
                    (this.dividers[i][0] <= selectedDivider[0] && this.dividers[i][2] >= selectedDivider[2]))) {
                    maximumPosition = this.dividers[i][1];
                }
            }

        }

        updateWingDividerInput(currentPosition, minimumPosition, maximumPosition);
    }

    wingDividerDragOver(doorwindowX, doorwindowY, mouseX, mouseY, dividerDirection, kfnyMultipleDivision) {
        if (this.openingMode == 'Fix') {
            return;
        }
        
        for (var i = 0; i < this.glasses.length; i++) {
            var glassXPositionInPixels = mmToPixel(doorwindowX + this.glasses[i].x);
            var glassYPositionInPixels = mmToPixel(doorwindowY + this.glasses[i].y);
            var glassWidthInPixels = mmToPixel(this.glasses[i].width);
            var glassHeightInPixels = mmToPixel(this.glasses[i].height);

            if ((this.openingMode !== 'KFNY' && this.openingMode !== 'KFNY-BNY' || dividerDirection == 'vertical') &&
                mouseX >= glassXPositionInPixels && mouseX <= glassXPositionInPixels + glassWidthInPixels &&
                mouseY >= glassYPositionInPixels && mouseY <= glassYPositionInPixels + glassHeightInPixels) {
                this.glasses[i].wingDividerDragOver(pixelToMm(mouseX) - doorwindowX - this.glasses[i].x, pixelToMm(mouseY) - doorwindowY - this.glasses[i].y, dividerDirection);
            }

            if ((this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') && dividerDirection == 'horizontal' &&
                (mouseX >= glassXPositionInPixels && mouseX <= glassXPositionInPixels + glassWidthInPixels || kfnyMultipleDivision) &&
                mouseY >= glassYPositionInPixels && mouseY <= glassYPositionInPixels + glassHeightInPixels) {
                this.glasses[i].wingDividerDragOver(pixelToMm(mouseX) - doorwindowX - this.glasses[i].x, pixelToMm(mouseY) - doorwindowY - this.glasses[i].y, dividerDirection);
            }
        }
    }

    unsetWingDividerDrag() {
        for (var i = 0; i < this.glasses.length; i++) {
            this.glasses[i].dividerPosition = -1;
            this.glasses[i].dividerDirection = '';
        }
    }

    wingDividerDrop() {
        for (var i = 0; i < this.glasses.length; i++) {
            if (this.glasses[i].dividerPosition !== -1) {
                var currentGlassType = this.glasses[i].glassType;
                var currentGlassWidth = this.glasses[i].glassWidth;
                var currentGlassFrame = this.glasses[i].glassFrame;

                var dividerPosition = parseInt(this.glasses[i].dividerPosition / 100) * 100;
                var glassXPosition = this.glasses[i].x;
                var glassYPosition = this.glasses[i].y;
                var glassWidth = this.glasses[i].width;
                var glassHeight = this.glasses[i].height;

                if (this.glasses[i].dividerDirection == 'horizontal') {
                    // horizontal

                    // split glass into 2
                    this.glasses.splice(i, 1, new Glass(glassXPosition, glassYPosition, glassWidth, dividerPosition - this.dividerWidth / 2, currentGlassType, currentGlassWidth, currentGlassFrame));
                    this.glasses.splice(i, 0, new Glass(glassXPosition, glassYPosition + dividerPosition + this.dividerWidth / 2, glassWidth, glassHeight - dividerPosition - this.dividerWidth / 2, currentGlassType, currentGlassWidth, currentGlassFrame));
                    
                    // create new divider
                    var newDivider = [
                        glassXPosition,
                        glassYPosition + dividerPosition,
                        glassXPosition + glassWidth,
                        glassYPosition + dividerPosition
                    ];
                } else {
                    // vertical

                    // split glass into 2
                    this.glasses.splice(i, 1, new Glass(glassXPosition, glassYPosition, dividerPosition - this.dividerWidth / 2, glassHeight, currentGlassType, currentGlassWidth, currentGlassFrame));
                    this.glasses.splice(i, 0, new Glass(glassXPosition + dividerPosition + this.dividerWidth / 2, glassYPosition, glassWidth - dividerPosition - this.dividerWidth / 2, glassHeight, currentGlassType, currentGlassWidth, currentGlassFrame));

                    // create new divider
                    var newDivider = [
                        glassXPosition + dividerPosition,
                        glassYPosition,
                        glassXPosition + dividerPosition,
                        glassYPosition + glassHeight
                    ];
                }

                // add wing divider to the wing
                this.dividers.push(newDivider);
            }
        }

        
        hideGlassInput();
        this.updateWingDividerInputValues();
    }

    getSelectedGlassSize() {
        var selectedGlassSize = [-1, -1];
        
        if (this.selectedGlassIndex !== -1) {
            var selectedGlass = this.glasses[this.selectedGlassIndex];
selectedGlassSize[0] = selectedGlass.width - 800;
selectedGlassSize[1] = selectedGlass.height - 800;
// javitani
        }

        return selectedGlassSize;
    }

    // returns a 2 element array containing the minimum and maximum values 
    // that can be set for the kfny divider
    getKfnyPositionLimits() {
        var kfnyPositionLimits = [0, this.width];

        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical

                if (this.dividers[i][0] - this.x < this.kfnyDivider &&
                    this.dividers[i][0] - this.x > kfnyPositionLimits[0]) {
                    kfnyPositionLimits[0] = this.dividers[i][0] - this.x;
                }

                if (this.dividers[i][0] - this.x > this.kfnyDivider &&
                    this.dividers[i][0] - this.x < kfnyPositionLimits[1]) {
                    kfnyPositionLimits[1] = this.dividers[i][0] - this.x;
                }
            }
        }

        return kfnyPositionLimits;
    }

    getUniqueWingDividers() {
        var uniqueWingDividers = [];

        for (var i = 0; i < this.dividers.length; i++) {
            var dividerSize = this.dividers[i][2] - this.dividers[i][0];

            if (this.dividers[i][0] == this.dividers[i][2]) {
                dividerSize = this.dividers[i][3] - this.dividers[i][1];
            }

            var isNewUniqueSize = true;
            for (var j = 0; j < uniqueWingDividers.length; j++) {
                if (uniqueWingDividers[j].size == dividerSize) {
                    uniqueWingDividers[j].quantity ++;
                    isNewUniqueSize = false;
                }
            }

            if (isNewUniqueSize) {
                uniqueWingDividers.push({size: dividerSize, quantity: 1});
            }
        }

        return uniqueWingDividers;
    }

    getGlasses(glassFrameIncluded = true) {
        var glasses = [];

        var glassFrameSize = 800;
        
        for (var i = 0; i < this.glasses.length; i++) {
            var glass = {
                name: this.glasses[i].glassType + ' ' + this.glasses[i].glassWidth,
                frame: this.glasses[i].glassFrame,
                framePriceName: this.glasses[i].glassFrame + ' ' + this.glasses[i].glassWidth,
                quantity: 1,
                width: Math.round(this.glasses[i].width / 100) * 100,
                height: Math.round(this.glasses[i].height / 100) * 100,
            };

            if (!glassFrameIncluded) {
                glass.width -= glassFrameSize;
                glass.height -= glassFrameSize;
            }

            glasses.push(glass);
        }

        return glasses;
    }

    getFrames() {
        var frames = [];

        if (this.openingMode == 'Fix') {
            return frames;
        }

        var frameHeight = this.height - this.frameSpacing[0] - this.frameSpacing[2];
        if (this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
            // KFNY left horizontal frames
            var frameWidth = this.width - (this.width - this.kfnyDivider) - 400 - this.frameSpacing[3];
            var frame = {
                name: this.frameType + " szárny",
                quantity: 2,
                size: frameWidth,
            };
            frames.push(frame);

            // KFNY right horizontal frames
            frameWidth = this.width - this.kfnyDivider - 400 - this.frameSpacing[1];
            frame = {
                name: this.frameType + " szárny",
                quantity: 2,
                size: frameWidth,
            };
            frames.push(frame);

            // KFNY vertical frames
            frame = {
                name: this.frameType + " szárny",
                quantity: 4,
                size: frameHeight,
            };
            frames.push(frame);

        } else {
            var frameWidth = this.width - this.frameSpacing[1] - this.frameSpacing[3];
            var frame = {
                name: this.frameType + " szárny",
                quantity: 2,
                size: frameWidth,
            };

            frames.push(frame);
            
            frame = {
                name: this.frameType + " szárny",
                quantity: 2,
                size: frameHeight,
            };

            frames.push(frame);
        }

        return frames;
    }

    //returns a sum of the wing's glasses width and height
    getGlassesSumSize() {
        var sumGlasssize = [0, 0];

        for (var i = 0; i < this.glasses.length; i++) {
            sumGlasssize[0] += this.glasses[i].width;
            sumGlasssize[1] += this.glasses[i].height;
        }

        return sumGlasssize;
    }

    getWingFramesForCuttingList(frameType, order = '', doorwindowNumber = '', cuttingListType = 'profile') {
        var wingFrames = [];
        var sizeDifference = 600;
        if (cuttingListType == 'metal-rod') {
            sizeDifference = -10000;
            if (this.frameType == 'Ablak') {
                sizeDifference = -11800;
            }

            if (this.frameType == 'Balkon') {
                sizeDifference = -15500;
            }

            if (this.frameType == 'Bejárati ajtó') {
                sizeDifference = -21300;
            }

            if (this.frameType == 'Kifelé nyíló balkon') {
                sizeDifference = -21200;
            }

            if (this.frameType == 'Kifelé nyíló bejárati ajtó') {
                sizeDifference = -21200;
            }
        }

        var calculatedFrameType = this.frameType;
        if (cuttingListType == 'metal-rod' && calculatedFrameType == 'Kifelé nyíló balkon') {
            calculatedFrameType = 'Balkon';
        }

        if (cuttingListType == 'metal-rod' && calculatedFrameType == 'Kifelé nyíló bejárati ajtó') {
            calculatedFrameType = 'Bejárati ajtó';
        }

        if (this.openingMode == 'Fix' || calculatedFrameType !== frameType) {
            return wingFrames;
        }

        if (this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
            var leftHandle = 'stulp';
            var rightHandle = 'to calculate';

            if (this.openingSide == 'Jobb') {
                leftHandle = 'to calculate';
                rightHandle = 'stulp';
            }

            wingFrames.push({
                size: Math.round((this.height - this.frameSpacing[0] - this.frameSpacing[2] + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: '1. L ' + this.openingSide,
                handle: -1,
                quantity: cuttingListType == 'metal-rod' ? 2 : 1,
            });

            wingFrames.push({
                size: Math.round((this.height - this.frameSpacing[0] - this.frameSpacing[2] + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: '1. R ' + this.openingSide,
                handle: rightHandle,
                quantity: cuttingListType == 'metal-rod' ? 2 : 1,
            });

            wingFrames.push({
                size: Math.round((this.height - this.frameSpacing[0] - this.frameSpacing[2] + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: '2. L ' + this.openingSide,
                handle: leftHandle,
                quantity: cuttingListType == 'metal-rod' ? 0 : 1,
            });

            wingFrames.push({
                size: Math.round((this.height - this.frameSpacing[0] - this.frameSpacing[2] + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: '2. R ' + this.openingSide,
                handle: -1,
                quantity: cuttingListType == 'metal-rod' ? 0 : 1,
            });
            
            wingFrames.push({
                size: Math.round((this.kfnyDivider - this.frameSpacing[3] - 400 + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: '1. O ' + this.openingSide,
                handle: -1,
                quantity: cuttingListType == 'metal-rod' ? 2 : 1,
            });

            wingFrames.push({
                size: Math.round((this.kfnyDivider - this.frameSpacing[3] - 400 + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: '1. U ' + this.openingSide,
                handle: -1,
                quantity: cuttingListType == 'metal-rod' ? 0 : 1,
            });

            wingFrames.push({
                size: Math.round(((this.width - this.kfnyDivider) - this.frameSpacing[1] - 400 + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: '2. O ' + this.openingSide,
                handle: -1,
                quantity: cuttingListType == 'metal-rod' ? 2 : 1,
            });

            wingFrames.push({
                size: Math.round(((this.width - this.kfnyDivider) - this.frameSpacing[1] - 400 + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: '2. U ' + this.openingSide,
                handle: -1,
                quantity: cuttingListType == 'metal-rod' ? 0 : 1,
            });

        } else {
            var leftHandle = 'to calculate';
            var rightHandle = -1;
            var topHandle = -1;
            var openingSide = this.openingSide;

            if (this.openingSide == 'Bal') {
                leftHandle = -1;
                rightHandle = 'to calculate';
            }

            if (this.openingMode == 'Bukó') {
                leftHandle = -1;
                rightHandle = -1;
                topHandle = Math.round((this.width - this.frameSpacing[1] - this.frameSpacing[3] + sizeDifference) / 2 / 100)
                openingSide = 'Bukó';
            }

            wingFrames.push({
                size: Math.round((this.width - this.frameSpacing[1] - this.frameSpacing[3] + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: 'O ' + openingSide,
                handle: topHandle,
                quantity: cuttingListType == 'metal-rod' ? 2 : 1,
            });

            wingFrames.push({
                size: Math.round((this.width - this.frameSpacing[1] - this.frameSpacing[3] + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: 'U ' + openingSide,
                handle: -1,
                quantity: cuttingListType == 'metal-rod' ? 0 : 1,
            });

            wingFrames.push({
                size: Math.round((this.height - this.frameSpacing[0] - this.frameSpacing[2] + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: 'L ' + openingSide,
                handle: leftHandle,
                quantity: cuttingListType == 'metal-rod' ? 2 : 1,
            });

            wingFrames.push({
                size: Math.round((this.height - this.frameSpacing[0] - this.frameSpacing[2] + sizeDifference) / 100) * 100,
                left: '45°\\',
                right: '45°/',
                order: order,
                doorwindowNumber: doorwindowNumber,
                name: 'R ' + openingSide,
                handle: rightHandle,
                quantity: cuttingListType == 'metal-rod' ? 0 : 1,
            });
        }

        // remove frames with 0 quantity
        for (var i = wingFrames.length - 1; i >= 0; i --) {
            if (!wingFrames[i].quantity) {
                wingFrames.splice(i, 1);
            }
        }

        return wingFrames;
    }

    getUniqueSymbolPositions() {
        var uniqueXPositions = [];
        var uniqueYPositions = [];

        // get unique coordinates from wing dividers
        for (var i = 0; i < this.dividers.length; i++) {
            if (this.dividers[i][0] == this.dividers[i][2]) {
                // vertical
                if (uniqueXPositions.indexOf(this.dividers[i][0]) == -1) {
                    uniqueXPositions.push(this.dividers[i][0])
                }
            } else {
                // horizontal
                if (uniqueYPositions.indexOf(this.dividers[i][1]) == -1) {
                    uniqueYPositions.push(this.dividers[i][1])
                }
            }
        }

        if (this.openingMode == 'KFNY' || this.openingMode == 'KFNY-BNY') {
            uniqueXPositions.push(this.x + this.kfnyDivider);
        }

        return [uniqueXPositions, uniqueYPositions];
    }
}