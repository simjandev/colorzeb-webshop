var global = {};
global.settings = {};

global.zoom = 3.5;

// doorwindow frames
global.settings.doorFrameWidth = 6150;
global.settings.windowFrameWidth = 4350;

// wings frame width
global.settings.wingFrameWidthByType = [];
global.settings.wingFrameWidthByType['Ablak szárny'] = 5750;
global.settings.wingFrameWidthByType['Balkon szárny'] = 7450;
global.settings.wingFrameWidthByType['Kifelé nyíló balkon szárny'] = 9500;
global.settings.wingFrameWidthByType['Bejárati ajtó szárny'] = 10450;
global.settings.wingFrameWidthByType['Kifelé nyíló bejárati ajtó szárny'] = 10500;

// glassframe widths
global.settings.glassFrameWidth = [];
global.settings.glassFrameWidth['Ablak szárny'] = 1000;
global.settings.glassFrameWidth['Balkon szárny'] = 1000;
global.settings.glassFrameWidth['Kifelé nyíló balkon szárny'] = 1000;
global.settings.glassFrameWidth['Bejárati ajtó szárny'] = 1000;
global.settings.glassFrameWidth['Kifelé nyíló bejárati ajtó szárny'] = 1000;

// divider widths
global.settings.dividerWidth = 4200;
global.settings.wingDividerWidth = 4200;

// doorwindow change history size
global.settings.doorwindowChangeHistorySize = 500;

// parts display name
global.settings.partDisplayNames = [];
global.settings.partDisplayNames['Ablak tok'] = 'Ablak tok Decco 82-es rendszerből (81mm, 6 légkamra)';
global.settings.partDisplayNames['Ajtó tok'] = 'Ajtó tok Decco 82-es rendszerből (81mm, 6 légkamra)';
global.settings.partDisplayNames['Ablak szárny'] = 'Ablak szárny Decco 82-es rendszerből (81mm, 6 légkamra)';
global.settings.partDisplayNames['Balkon szárny'] = 'Balkon szárny Decco 82-es rendszerből (81mm, 6 légkamra)';
global.settings.partDisplayNames['Bejárati ajtó szárny'] = 'Bejárati ajtó szárny Decco 82-es rendszerből (81mm, 5 légkamra)';
global.settings.partDisplayNames['Kifelé nyíló balkon szárny'] = 'Kifelé nyíló balkon szárny Decco 82-es rendszerből (81mm, 6 légkamra)';
global.settings.partDisplayNames['Kifelé nyíló bejárati ajtó szárny'] = 'Kifelé nyíló bejárati ajtó szárny Decco 82-es rendszerből (81mm, 5 légkamra)';

global.settings.partDisplayNames['Üveg 24mm alukeret'] = '4Float-16ALUarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg 44mm alukeret'] = '4LowE-16ALUarg-4Float-16ALUarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (csincsilla) 24mm alukeret'] = '4KatCsincsFeh-16ALUarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (csincsilla) 44mm alukeret'] = '4LowE-16ALUarg-4KatCsincsFeh-16ALUarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (savmart) 24mm alukeret'] = '4SavmSzatFeh-16ALUarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (savmart) 44mm alukeret'] = '4LowE-16ALUarg-4SavmSzatFeh-16ALUarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (screen) 24mm alukeret'] = '4KatScreenFeh-16ALUarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (screen) 44mm alukeret'] = '4LowE-16ALUarg-4KatScreenFeh-16ALUarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (fatörzs) 24mm alukeret'] = '4Fatorzs-16ALUarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (fatörzs) 44mm alukeret'] = '4LowE-16ALUarg-4Fatorzs-16ALUarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (bambusz) 24mm alukeret'] = '4Bambusz-16ALUarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (bambusz) 44mm alukeret'] = '4LowE-16ALUarg-4Bambusz-16ALUarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (tükrös) 24mm alukeret'] = '4Bronztükrös-16ALUarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (tükrös) 44mm alukeret'] = '4LowE-16ALUarg-4Bronztükrös-16ALUarg-4LowE(Ug: 0.6 W/m²)';

global.settings.partDisplayNames['Üveg 24mm melegperem'] = '4Float-16PVCarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg 44mm melegperem'] = '4LowE-16PVCarg-4Float-16PVCarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (csincsilla) 24mm melegperem'] = '4KatCsincsFeh-16PVCarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (csincsilla) 44mm melegperem'] = '4LowE-16PVCarg-4KatCsincsFeh-16PVCarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (savmart) 24mm melegperem'] = '4SavmSzatFeh-16PVCarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (savmart) 44mm melegperem'] = '4LowE-16PVCarg-4SavmSzatFeh-16PVCarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (screen) 24mm melegperem'] = '4KatScreenFeh-16PVCarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (screen) 44mm melegperem'] = '4LowE-16PVCarg-4KatScreenFeh-16PVCarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (fatörzs) 24mm melegperem'] = '4Fatorzs-16PVCarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (fatörzs) 44mm melegperem'] = '4LowE-16PVCarg-4Fatorzs-16PVCarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (bambusz) 24mm melegperem'] = '4Bambusz-16PVCarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (bambusz) 44mm melegperem'] = '4LowE-16PVCarg-4Bambusz-16PVCarg-4LowE(Ug: 0.6 W/m²)';
global.settings.partDisplayNames['Üveg (tükrös) 24mm melegperem'] = '4Bronztükrös-16PVCarg-4LowE(Ug: 1.0 W/m²)';
global.settings.partDisplayNames['Üveg (tükrös) 44mm melegperem'] = '4LowE-16PVCarg-4Bronztükrös-16PVCarg-4LowE(Ug: 0.6 W/m²)';

global.settings.partDisplayNames['Fehér műanyag léces'] = 'Fehér műanyag léces redőny';
global.settings.partDisplayNames['Fehér műanyag léces kombi'] = 'Fehér műanyag léces szúnyoghálós redőny';
global.settings.partDisplayNames['Fehér alu léces'] = 'Fehér alu léces redőny';
global.settings.partDisplayNames['Fehér alu léces kombi'] = 'Fehér alu léces szúnyoghálós redőny';
global.settings.partDisplayNames['Fehér műanyag léces vakolható'] = 'Fehér műanyag léces vakolható redőny';
global.settings.partDisplayNames['Fehér műanyag léces kombi vakolható'] = 'Fehér műanyag léces szúnyoghálós vakolható redőny';
global.settings.partDisplayNames['Fehér alu léces vakolható'] = 'Fehér alu léces vakolható redőny';
global.settings.partDisplayNames['Fehér alu léces kombi vakolható'] = 'Fehér alu léces szúnyoghálós vakolható redőny';
global.settings.partDisplayNames['Színes alu léces'] = 'Színes alu léces redőny';
global.settings.partDisplayNames['Színes alu léces kombi'] = 'Színes alu léces szúnyoghálós redőny';
global.settings.partDisplayNames['Színes alu léces vakolható'] = 'Színes alu léces vakolható redőny';
global.settings.partDisplayNames['Színes alu léces kombi vakolható'] = 'Színes alu léces szúnyoghálós vakolható redőny';
global.settings.partDisplayNames['Motor vezérlés'] = 'Motor vezérlés redőny';

global.settings.partDisplayNames['Falcos alu keretes fehér'] = 'Falcos alu keretes fehér szúnyogháló';
global.settings.partDisplayNames['Falcos alu keretes barna'] = 'Falcos alu keretes barna szúnyogháló';
global.settings.partDisplayNames['Falcos alu keretes foliás'] = 'Falcos alu keretes foliás szúnyogháló';
global.settings.partDisplayNames['Alu szúnyogháló ajtó fehér'] = 'Alu szúnyogháló ajtó fehér';
global.settings.partDisplayNames['Alu szúnyogháló ajtó kiemelő k. fehér'] = 'Alu szúnyogháló ajtó kiemelő k. fehér';
global.settings.partDisplayNames['26x11mm alu keretes fehér'] = '26x11mm alu keretes fehér szúnyogháló';
global.settings.partDisplayNames['26x11mm alu keretes barna'] = '26x11mm alu keretes barna szúnyogháló';
global.settings.partDisplayNames['26x11mm alu keretes foliás'] = '26x11mm alu keretes foliás szúnyogháló';
global.settings.partDisplayNames['Alu tokos lefelé húzható fehér'] = 'Alu tokos lefelé húzható fehér szúnyogháló';
global.settings.partDisplayNames['Alu tokos lefelé húzható barna'] = 'Alu tokos lefelé húzható barna szúnyogháló';
global.settings.partDisplayNames['Alu tokos lefelé húzható foliás'] = 'Alu tokos lefelé húzható foliás szúnyogháló';
global.settings.partDisplayNames['Alu tokos oldalra húzható fehér'] = 'Alu tokos oldalra húzható fehér szúnyogháló';
global.settings.partDisplayNames['Alu tokos oldalra húzható barna'] = 'Alu tokos oldalra húzható barna szúnyogháló';
global.settings.partDisplayNames['Alu tokos oldalra húzható foliás'] = 'Alu tokos oldalra húzható foliás szúnyogháló';
global.settings.partDisplayNames['Alu szúnyogháló ajtó barna'] = 'Alu szúnyogháló ajtó barna';
global.settings.partDisplayNames['Alu szúnyogháló ajtó foliás'] = 'Alu szúnyogháló ajtó foliás';
global.settings.partDisplayNames['Alu szúnyogháló ajtó kiemelő k. barna'] = 'Alu szúnyogháló ajtó kiemelő k. barna';
global.settings.partDisplayNames['Alu szúnyogháló ajtó kiemelő k. foliás'] = 'Alu szúnyogháló ajtó kiemelő k. foliás';
global.settings.partDisplayNames['2sz. alu szúnyogháló ajtó fehér'] = '2sz. alu szúnyogháló ajtó fehér';
global.settings.partDisplayNames['2sz. alu szúnyogháló ajtó barna'] = '2sz. alu szúnyogháló ajtó barna';
global.settings.partDisplayNames['2sz. alu szúnyogháló ajtó foliás'] = '2sz. alu szúnyogháló ajtó foliás';
global.settings.partDisplayNames['2sz. alu szúnyogháló ajtó kiemelő k. fehér'] = '2sz. alu szúnyogháló ajtó kiemelő k. fehér';
global.settings.partDisplayNames['2sz. alu szúnyogháló ajtó kiemelő k. barna'] = '2sz. alu szúnyogháló ajtó kiemelő k. barna';
global.settings.partDisplayNames['2sz. alu szúnyogháló ajtó kiemelő k. foliás'] = '2sz. alu szúnyogháló ajtó kiemelő k. foliás';
function mmToPixel(mm) {
    return mm / global.zoom / 100;
}

function pixelToMm(pixel) {
    return parseInt(pixel * global.zoom * 100);
}