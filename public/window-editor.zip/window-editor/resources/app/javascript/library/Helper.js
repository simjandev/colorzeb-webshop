function getPriceByPartName(priceSettings, partName) {
    for (var i = 0; i < priceSettings.length; i ++) {
        if (priceSettings[i].name == partName) {
            return priceSettings[i].price;
        }   
    }

    return -1;
}

function getDisplayName(displayNameList, name) {
    if (name in displayNameList) {
        return displayNameList[name];
    }

    return name;
}

function formatCurrency(amount) {
    const formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'HUF',
        minimumFractionDigits: 0,
    });
      
    return formatter.format(amount).replace('HUF', '');
}

function extendDividerToMatchWings(divider, dividerWidth, frameWidth, doorwindowWidth, doorwindowHeight) {
    var extendedDivider = divider.slice();
    console.log(extendedDivider);
    console.log(doorwindowWidth);
    if (divider[0] == frameWidth) {
        extendedDivider[0] = 0;
    } else {
        extendedDivider[0] -= dividerWidth / 2;
    }

    if (divider[1] == frameWidth) {
        extendedDivider[1] = 0;
    } else {
        extendedDivider[1] -= dividerWidth / 2;
    }

    if (divider[2] == doorwindowWidth - frameWidth) {
        extendedDivider[2] = doorwindowWidth;
    } else {
        extendedDivider[2] += dividerWidth / 2;
    }

    if (divider[3] == doorwindowHeight - frameWidth) {
        extendedDivider[3] = doorwindowHeight;
    } else {
        extendedDivider[3] += dividerWidth / 2;
    }

    console.log(extendedDivider);
    return extendedDivider;
}

function getCommissionFee(commissionFees, commissionFeeName) {
    var commissionFee = 0;

    for (var i = 0; i < commissionFees.length; i++) {
        if (commissionFees[i].name == commissionFeeName) {
            commissionFee = commissionFees[i].percentage;
            break;
        }
    }

    return commissionFee;
}

function getHandleHeight(handleList, frameHeight, isFittingSize = false) {
    var handlePosition = -1;

    var fittingSize = 40;
    if (isFittingSize) {
        fittingSize = 0;
    }

    for (var j = 0; j < handleList.length; j++) {
        if (frameHeight / 100 - fittingSize >= handleList[j].minHeight && frameHeight / 100 - fittingSize <= handleList[j].maxHeight) {
            handlePosition = handleList[j].position;
        }
    }

    return handlePosition;
}

function updateInstallationFee(orderNumber) {
    var priceSettings = ipcRenderer.sendSync('load-price-settings');
    var orderList = ipcRenderer.sendSync('load-orders').orders;
    var doorwindowList = ipcRenderer.sendSync('load-orders').doorwindows;
    
    for (var i = 0; i < orderList.length; i++) {
        if (orderList[i].number !== orderNumber) {
            continue;
        }

        var doorwindowCount = 0;
        for (var j = 0; j < doorwindowList.length; j ++) {
            
            if (doorwindowList[j].order != orderList[i].number) {
                continue;
            }

            var doorwindowFileName = orderList[i].number + "_" + doorwindowList[j].name;
            var fileContents = ipcRenderer.sendSync('load-doorwindow-file', doorwindowFileName);
            var quantity = parseInt(fileContents.split('|')[9]);
            doorwindowCount += quantity;
        }
        
        if (orderList[i].installationFeeType == 'beepites') {
            orderList[i].installationFee = getPriceByPartName(priceSettings, 'Beépítés') * doorwindowCount;
        }

        if (orderList[i].installationFeeType == 'beepites+bontas') {
            orderList[i].installationFee = getPriceByPartName(priceSettings, 'Beépítés és bontás');
            if (doorwindowCount <= 3) {
                orderList[i].installationFee += getPriceByPartName(priceSettings, 'Beépítés és bontás kevés nyz.') * 2;
            }

            if (doorwindowCount > 3 && doorwindowCount <= 6) {
                orderList[i].installationFee += getPriceByPartName(priceSettings, 'Beépítés és bontás kevés nyz.');
            }

            orderList[i].installationFee *= doorwindowCount;
            console.log(doorwindowCount);
            console.log(getPriceByPartName(priceSettings, 'Beépítés és bontás'));
            console.log(getPriceByPartName(priceSettings, 'Beépítés és bontás kevés nyz.'));
            console.log(getPriceByPartName(priceSettings, 'Beépítés és bontás kevés nyz.') * 2);
        }

        ipcRenderer.sendSync('update-order', orderList[i]);
    }
}