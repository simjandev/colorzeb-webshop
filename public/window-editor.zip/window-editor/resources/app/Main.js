const {nativeImage, app, BrowserWindow, ipcMain, Menu, dialog, shell, ipcRenderer} = require('electron');
const fs = require('fs');
const path = require('path');
const excel = require('xlsx');
var startTime = new Date();

app.disableHardwareAcceleration();

app.on('ready', function() {
    var basePath = app.getPath('documents') + '/window-editor';
    var appPath = path.join('file:///', __dirname);

    fs.writeFileSync(basePath + '/log.txt', '');
    logText('Ready');

    var icon = nativeImage.createFromPath(__dirname + '/assets/window.png'); 
    icon.setTemplateImage(true);

    var defaultPrices = fs.readFileSync(path.join(__dirname, '/data/default-prices.txt'), 'utf-8');
    var defaultHandlePositions = fs.readFileSync(path.join(__dirname, '/data/default-handle-positions.txt'), 'utf-8');
    var defaultOrdersPageStates = fs.readFileSync(path.join(__dirname, '/data/default-orders-page-states.txt'), 'utf-8');
    var additionalParts = fs.readFileSync(path.join(__dirname, '/data/additional-parts.txt'), 'utf-8');
    var defaultToolPagesStates = fs.readFileSync(path.join(__dirname, '/data/default-tool-pages-states.txt'), 'utf-8');

    if (!fs.existsSync(basePath)) {
        fs.mkdirSync(basePath);
    }

    if (!fs.existsSync(basePath + '/data')) {
        fs.mkdirSync(basePath + '/data');
    }

    if (!fs.existsSync(basePath + '/data/save')) {
        fs.mkdirSync(basePath + '/data/save');
    }

    if (!fs.existsSync(basePath + '/data/orders.txt')) {
        fs.writeFileSync(basePath + '/data/orders.txt', '');
    }
    
    if (!fs.existsSync(basePath + '/data/offer-text.txt')) {
        fs.writeFileSync(basePath + '/data/offer-text.txt', "Teszt árajánlat szöveg\r\n<b>Vastag szöveg</b>\r\n<i>Dölt szöveg</i>");
    }

    fs.writeFileSync(basePath + '/data/handle-positions.txt', defaultHandlePositions);

    if (!fs.existsSync(basePath + '/data/fittings.txt')) {
        fs.writeFileSync(basePath + '/data/fittings.txt', '');
    }

    if (!fs.existsSync(basePath + '/data/work-fees.txt')) {
        fs.writeFileSync(basePath + '/data/work-fees.txt', '');
    }

    if (!fs.existsSync(basePath + '/data/profits.txt')) {
        fs.writeFileSync(basePath + '/data/profits.txt', '');
    }

    if (!fs.existsSync(basePath + '/data/prices.txt')) {
        fs.writeFileSync(basePath + '/data/prices.txt', defaultPrices);
    } else {
        // add prices that are not in the user's list and remove the unused ones
        var currentPricesData = fs.readFileSync(basePath + '/data/prices.txt', 'utf-8').split("\r\n");
        var defaultPricesData = defaultPrices.split("\r\n");

        // write missing prices to save file
        for (var i = 0; i < defaultPricesData.length; i ++) {
            var found = false;
            for (var j = 0; j < currentPricesData.length && !found; j++) {
                if (currentPricesData[j].split('|')[0] == defaultPricesData[i].split('|')[0]) {
                    found = true;
                }
            }

            if (!found) {
                currentPricesData.push(defaultPricesData[i]);
            }
        }

        // remove unused prices from the save file
        var newCurrentPricesData = [];
        for (var i = 0; i < currentPricesData.length; i ++) {
            var found = false;
            for (var j = 0; j < defaultPricesData.length && !found; j++) {
                if (defaultPricesData[j].split('|')[0] == currentPricesData[i].split('|')[0]) {
                    found = true;
                }
            }

            if (found) {
                newCurrentPricesData.push(currentPricesData[i]);
            }
        }

        fs.writeFileSync(basePath + '/data/prices.txt', newCurrentPricesData.join("\r\n"));
    }

    if (!fs.existsSync(basePath + '/data/prepayment-index.txt')) {
        fs.writeFileSync(basePath + '/data/prepayment-index.txt', '1');
    }

    if (!fs.existsSync(basePath + '/data/payment-index.txt')) {
        fs.writeFileSync(basePath + '/data/payment-index.txt', '1');
    }

    if (!fs.existsSync(basePath + '/data/orders-page-states.txt')) {
        fs.writeFileSync(basePath + '/data/orders-page-states.txt', defaultOrdersPageStates);
    }

    fs.writeFileSync(basePath + '/data/additional-parts.txt', additionalParts);

    if (!fs.existsSync(basePath + '/data/commission-fees.txt')) {
        fs.writeFileSync(basePath + '/data/commission-fees.txt', '');
    }
    
    if (!fs.existsSync(basePath + '/data/tool-pages-states.txt')) {
        fs.writeFileSync(basePath + '/data/tool-pages-states.txt', defaultToolPagesStates);
    }

    var defaultWindowMenuTemplate = [
        {
            label: 'Fájl',
            submenu: [
                {
                    label: 'Kilépés',
                    role: 'close',
                },
            ],
        },
    ];
    var defaultWindowMenuBar = Menu.buildFromTemplate(defaultWindowMenuTemplate);

    var ordersWindowMenuTemplate = [
        {
            label: 'Fájl',
            submenu: [
                {
                    label: 'Kilépés',
                    role: 'close',
                },
            ],
        },
        {
            label: 'Megrendelés',
            submenu: [
                {
                    label: 'Alkatrészek nyomtatása',
                    click: printOrderDoorwindowParts,
                },
                {
                    label: 'Árajánlat nyomtatása',
                    click: printOffer,
                },
                {
                    label: 'Megrendelés visszaigazolás nyomtatása',
                    click: printOrderConfirmation,
                },
                {
                    label: 'Gyártási lap nyomtatása',
                    click: printProductionPage,
                },
                {
                    label: 'Előlegbekérő nyomtatása',
                    click: printPrepaymentRequest,
                },
                {
                    label: 'Díjbekérő nyomtatása',
                    click: printPaymentRequest,
                },
                {
                    label: 'Egységes üveg beállítás',
                    click: showOrderGlassSettingsWindow,
                },
            ],
        },
        {
            label: 'Eszközök',
            submenu: [
                {
                    label: 'Naptár',
                    click: showCalendarWindow,
                },
                {
                    label: 'Alapanyag lista',
                    click: showPartListWindow,
                },
                {
                    label: 'Üveg lista',
                    click: showGlassListWindow,
                },
                {
                    label: 'Profil szabászati lista',
                    click: showProfileCuttingListWindow,
                },
                {
                    label: 'Vas szabászati lista',
                    click: showMetalRodCuttingListWindow,
                },
                {
                    label: 'Vasalat lista',
                    click: showFittingListWindow,
                },
                {
                    label: 'Manuális vasalatlista',
                    click: showFittingListTestWindow,
                },
            ],
        },
        {
            label: 'Beállítások',
            submenu: [
                {
                    'label': 'Árak',
                    click: showPriceSettingsWindow,
                },
                {
                    'label': 'Jutalékok',
                    click: showCommissionFeeSettingsWindow,
                },
                {
                    'label': 'Vasalatok',
                    click: showFittingSettingsWindow,
                },
                {
                    'label': 'Munkadíj',
                    click: showWorkFeeSettingsWindow,
                },
                {
                    'label': 'Profit',
                    click: showProfitSettingsWindow,
                },
                {
                    'label': 'Árajánlat szöveg',
                    click: showOfferTextSettingsWindow,
                }
            ],
        },
        /*{
            label: 'Dev',
            submenu: [
                {
                    'label': 'Mentések frissítése',
                    click: updateSaveFiles,
                },
            ],
        },*/
    ];

    var mainWindowMenuTemplate = [
        {
            label: 'Fájl',
            submenu: [
                {
                    label: 'Kilépés',
                    role: 'close',
                },
            ],
        },
        {
            label: 'Nyílászáró',
            submenu: [
                {
                    label: 'Tokosztó elrendezés üvegméret szerint',
                    click: autoPositionDividers,
                },
                {
                    label: 'Tokosztó elrendezés tokosztó távolság szerint',
                    click: autoPositionDividersByDividerDistance,
                },
                {
                    label: 'Szárnyosztó elrendezés üvegméret szerint',
                    click: autoPositionWingDividers,
                },
            ],
        }
    ];

    var mainWindowMenuBar = Menu.buildFromTemplate(mainWindowMenuTemplate);
    var ordersWindowMenuBar = Menu.buildFromTemplate(ordersWindowMenuTemplate);

    var win = new BrowserWindow({
        width: 1024,
        height: 768,
        minWidth: 1024,
        minHeight: 768,
        show: true,
        icon: icon,
        webPreferences: {
            nodeIntegration: true
        },
    });
    
    win.loadURL(path.join(appPath, '/pages/Orders.html'));
    win.setMenu(ordersWindowMenuBar);
    win.maximize();
    //win.openDevTools();

    var PrintDoorwindowWindow = new BrowserWindow({
        show: false,
        parent: win,
        skipTaskbar: true,
        icon: icon,
        webPreferences: {
            nodeIntegration: true
        },
    });

    PrintDoorwindowWindow.setMenuBarVisibility(false);
    PrintDoorwindowWindow.loadURL(path.join(appPath, '/pages/PrintDoorwindow.html'));
    PrintDoorwindowWindow.on('close', function(event) {
        PrintDoorwindowWindow.hide();
        event.preventDefault();
    });

    var QuestionBoxWindow = new BrowserWindow({
        show: false,
        parent: win,
        modal: true,
        skipTaskbar: true,
        width: 400,
        height: 200,
        closable: false,
        resizable: false,
        icon: icon,
        webPreferences: {
            nodeIntegration: true
        },
    });

    QuestionBoxWindow.setMenuBarVisibility(false);
    QuestionBoxWindow.on('close', function(event) {
        QuestionBoxWindow.hide();
        event.preventDefault();
    });

    var OrderGlassSettingsWindow = new BrowserWindow({
        show: false,
        parent: win,
        modal: true,
        skipTaskbar: true,
        width: 400,
        height: 200,
        closable: false,
        resizable: false,
        icon: icon,
        webPreferences: {
            nodeIntegration: true
        },
    });

    OrderGlassSettingsWindow.setMenuBarVisibility(false);
    OrderGlassSettingsWindow.loadURL(path.join(appPath, '/pages/OrderGlassSettings.html'));
    OrderGlassSettingsWindow.on('close', function(event) {
        OrderGlassSettingsWindow.hide();
        event.preventDefault();
    });

    win.on('closed', function() {
        app.quit();
    });

    // START OF IPC EVENTS
    ipcMain.on('open-questionbox', function(event, data) {
        QuestionBoxWindow.loadURL(path.join(appPath, '/pages/QuestionBox.html?questionText=' + encodeURI(data.questionText) +
            '&acceptText=' + encodeURI(data.acceptText) + '&cancelText=' + encodeURI(data.cancelText) + '&ipcEvent=' + encodeURI(data.ipcEvent) +
            '&windowId=' + encodeURI(data.windowId)));

        setTimeout(function() {
            QuestionBoxWindow.show();
        }.bind(this), 100);

        event.returnValue = '';
    });

    ipcMain.on('open-orders-page', function(event, data) {
        win.setMenu(defaultWindowMenuBar);
        win.loadURL(path.join(appPath, '/pages/Orders.html'));
        win.setMenu(ordersWindowMenuBar);
    });

    ipcMain.on('open-editor', function(event, doorwindowFileName) {
        win.setMenu(mainWindowMenuBar);
        win.loadURL(path.join(appPath, '/pages/Editor.html?doorwindowFileName=' +
            encodeURI(doorwindowFileName) + '&isSaved=1'));
        
        event.returnValue = '';
    });

    ipcMain.on('save-additional-parts', function(event, data) {
        win.send('save-additional-parts', data);

        event.returnValue = '';
    });
    
    ipcMain.on('open-order-glass-settings-window', function(event, data) {
        OrderGlassSettingsWindow.loadURL(path.join(appPath, '/pages/OrderGlassSettings.html?selectedOrder=' + data.selectedOrder));

        setTimeout(function() {
            OrderGlassSettingsWindow.show();
        }.bind(this), 100);
        event.returnValue = '';
    });

    ipcMain.on('set-order-glass', function(event, data) {
        win.send('set-selected-order-glass', data);
        OrderGlassSettingsWindow.hide();
        event.returnValue = '';
    });
    
    ipcMain.on('get-price-settings', function(event, data) {
        event.returnValue = fs.readFileSync(basePath + '/data/prices.txt', 'utf-8');;
    });

    ipcMain.on('close-offer-text-settings', function(event, data) {
        win.loadURL(path.join(appPath, '/pages/Orders.html'));
        win.setMenu(ordersWindowMenuBar);
        event.returnValue = '';
    });

    ipcMain.on('close-order-glass-settings', function(event, data) {
        OrderGlassSettingsWindow.hide();
        event.returnValue = '';
    });

    ipcMain.on('save-price-settings', function(event, data) {
        fs.writeFileSync(basePath + '/data/prices.txt', data);
        win.loadURL(path.join(appPath, '/pages/Orders.html'));
        win.setMenu(ordersWindowMenuBar);
        event.returnValue = '';
    });

    ipcMain.on('save-offer-text', function(event, data) {
        fs.writeFileSync(basePath + '/data/offer-text.txt', data);
        event.returnValue = '';
    });

    ipcMain.on('update-order',  function(event, data) {
        updateOrder(data);
        event.returnValue = '';
    });
    
    ipcMain.on('load-fittings-from-excel', function(event, data) {
        var fittings = loadFittingsListFromExcel(data.filePath);
        event.returnValue = fittings;
    });

    ipcMain.on('load-fittings', function(event, data) {
        var fittings = loadFittings();
        event.returnValue = fittings;
    });

    ipcMain.on('save-fittings', function(event, data) {
        saveFittings(data.fittings);
        event.returnValue = '';
    });

    ipcMain.on('load-work-fees', function(event, data) {
        var workFees = loadWorkFees();
        event.returnValue = workFees;
    });

    ipcMain.on('load-profits', function(event, data) {
        var profits = loadProfits();
        event.returnValue = profits;
    });

    ipcMain.on('load-additional-parts', function(event, data) {
        var additionalParts = loadAdditionalParts();
        event.returnValue = additionalParts;
    });

    ipcMain.on('save-work-fees', function(event, data) {
        saveWorkFees(data.workFees);
        event.returnValue = '';
    });

    ipcMain.on('save-profits', function(event, data) {
        saveProfits(data.profits);
        event.returnValue = '';
    });

    ipcMain.on('load-work-fees-from-excel', function(event, data) {
        var workFees = loadWorkFeesFromExcel(data.filePath);
        event.returnValue = workFees;
    });

    ipcMain.on('load-profits-from-excel', function(event, data) {
        var profits = loadProfitsFromExcel(data.filePath);
        event.returnValue = profits;
    });

    ipcMain.on('load-prepayment-index', function(event, data) {
        var prepaymentIndex = fs.readFileSync(basePath + '/data/prepayment-index.txt', 'utf-8');
        event.returnValue = prepaymentIndex;
    });

    ipcMain.on('load-payment-index', function(event, data) {
        var paymentIndex = fs.readFileSync(basePath + '/data/payment-index.txt', 'utf-8');
        event.returnValue = paymentIndex;
    });

    ipcMain.on('load-orders-page-states', function(event, data) {
        var ordersPageStates = loadOrdersPageStates();
        event.returnValue = ordersPageStates;
    });

    ipcMain.on('save-orders-page-states', function(event, data) {
        saveOrdersPageStates(data);
        event.returnValue = '';
    });

    ipcMain.on('load-commission-fees', function(event, data) {
        var commissionFees = loadCommissionFees();
        event.returnValue = commissionFees;
    });

    ipcMain.on('save-commission-fees', function(event, data) {
        saveCommissionFees(data);
        event.returnValue = '';
    });

    ipcMain.on('load-tool-pages-states', function(event, data) {
        var toolPagesStates = loadToolPagesStates();
        event.returnValue = toolPagesStates;
    });

    ipcMain.on('save-tool-pages-states', function(event, data) {
        saveToolPagesStates(data);
        event.returnValue = '';
    });

    ipcMain.on('load-orders', function(event, data) {
        // read order list from file
        var orders = loadOrders();

        // update the orders' status to finished
        for (var i = 0; i < orders.length; i ++) {
            var today = new Date();
            var orderFinishDate = new Date(orders[i].finishDate + 'T00:00:00Z');

            if (today > orderFinishDate) {
                orders[i].status = 'teljesített';
            }
        }

        saveOrders(orders);

        // read doorwindows list from file
        var files = fs.readdirSync(basePath + '/data/save/');
        
        var doorwindows = [];
        for (var i=0; i < files.length; i++) {
            var fileName = files[i].substring(0, files[i].length - 3);
            var orderName = fileName.split("_")[0];
            var doorwindowName = fileName.split("_")[1];
            
            // get doorwindow display name
            var doorwindowDisplayName = doorwindowName;
            var doorwindowFileLines = fs.readFileSync(basePath + '/data/save/' + fileName + '.we', 'utf-8').split('|');
            doorwindowDisplayName = doorwindowFileLines[0];

            doorwindows.push({
                order: orderName,
                name: doorwindowName,
                displayName: doorwindowDisplayName,
            });
        }

        doorwindows.sort(function(a, b){
            if(parseInt(a.name) < parseInt(b.name)) { return -1; }
            if(parseInt(a.name) > parseInt(b.name)) { return 1; }
            return 0;
        });

        event.returnValue = {doorwindows: doorwindows, orders: orders};
    });

    ipcMain.on('create-order', function(event, data) {
        var orderNumber = data.orderNumber;
        var orderCustomer = data.orderCustomer;
        var orderAddress = data.orderAddress;
        var orderStatus = data.orderStatus;
        var orderDate = data.orderDate;
        var orderFinishDate = data.orderFinishDate;
        var orderEmail = data.orderEmail;
        var orderPhone = data.orderPhone;
        var orderComment = data.orderComment;
        var orderTaxNumber = data.orderTaxNumber;
        var orderCommissionFee = data.orderCommissionFee;
        var orderInstallationFeeType = data.orderInstallationFeeType;
        var orderInstallationFee = data.orderInstallationFee;

        var orderString = orderNumber + '|' + orderCustomer + '|' + orderStatus + '|' + orderDate + '|' +
            orderFinishDate + '|' + orderEmail + '|' + orderPhone + '|' + orderAddress + '|' + orderComment + '|' + orderTaxNumber + '|'
            + orderCommissionFee + '|' + orderInstallationFee + '|' + orderInstallationFeeType;

        if (fs.readFileSync(basePath + '/data/orders.txt', 'utf-8').length > 0) {
            orderString = "\r\n" + orderString;
        }

        fs.appendFileSync(basePath + '/data/orders.txt', orderString);
        event.returnValue = '';
    });

    ipcMain.on('log', function(event, data) {
        logText(data);
        event.returnValue = '';
    });

    ipcMain.on('create-doorwindow', function(event, doorwindowFileName) {
        win.setMenu(mainWindowMenuBar);
        win.loadURL(path.join(appPath, '/pages/Editor.html?doorwindowFileName=' +
            encodeURI(doorwindowFileName) + '&isSaved=0'));

        event.returnValue = '';
    });

    ipcMain.on('load-offer-text', function(event, data) {
        var fileContents = fs.readFileSync(basePath + '/data/offer-text.txt', 'utf-8');
        fileContents = fileContents.split("\r\n").join("<br>").split("\n").join("<br>");

        event.returnValue = fileContents;
    });

    ipcMain.on('load-doorwindow-file', function(event, doorwindowName) {
        var fileContents = fs.readFileSync(basePath + '/data/save/' + doorwindowName + '.we', 'utf-8');

        event.returnValue = fileContents;
    });

    ipcMain.on('save-doorwindow', function(event, data) {
        fs.writeFileSync(basePath + '/data/save/' + data.doorwindowName + '.we', data.doorwindowSaveString);
        event.returnValue = '';
    });

    ipcMain.on('questionbox-accept-callback', function(event, data) {
        BrowserWindow.fromId(parseInt(data.callbackWindowId)).webContents.send(data.callbackIpcEvent);

        QuestionBoxWindow.hide();

        event.returnValue = '';
    });

    ipcMain.on('questionbox-cancel-callback', function(event, data) {
        QuestionBoxWindow.hide();

        event.returnValue = '';
    });

    ipcMain.on('delete-order', function(event, data) {
        var deletedOrderNumber = data.order;

        // load orders without the deleted order
        var ordersString = '';
        var lines = fs.readFileSync(basePath + '/data/orders.txt', 'utf-8').split("\r\n");
        for (var i = 0; i < lines.length; i++) {
            var data = lines[i].split('|');
            
            if (data[0] == deletedOrderNumber) {
                continue;
            }
            
            if (ordersString !== '') {
                ordersString += "\r\n";
            }

            ordersString += lines[i];
        }

        // save orders without the deleted order
        fs.writeFileSync(basePath + '/data/orders.txt', ordersString);

        // delete saved doorwindows from the deleted order
        var files = fs.readdirSync(basePath + '/data/save/');
        for (var i=0; i < files.length; i++) {
            var orderName = files[i].split("_")[0];
            if (orderName == deletedOrderNumber) {
                fs.unlinkSync(basePath + '/data/save/' + files[i]);
            }
        }

        event.returnValue = '';
    });

    ipcMain.on('delete-doorwindow', function(event, data) {
        var deletedDoorwindowName = data.doorwindow;
        var deletedOrderNumber = data.order;

        // delete saved doorwindows from the deleted order
        var files = fs.readdirSync(basePath + '/data/save/');
        for (var i=0; i < files.length; i++) {
            var orderNumber = files[i].split("_")[0];
            var doorwindowName = files[i].split("_")[1];
            doorwindowName = doorwindowName.substring(0, doorwindowName.length - 3);
            
            if (doorwindowName == deletedDoorwindowName && orderNumber == deletedOrderNumber) {
                fs.unlinkSync(basePath + '/data/save/' + files[i]);
            }
        }

        event.returnValue = '';
    });

    
    ipcMain.on('open-prepayment-request-data-page', function(event, data) {
        win.setMenu(defaultWindowMenuBar);
        win.loadURL(path.join(appPath, '/pages/PrepaymentRequest.html?orderNumber=' + data.order));
    });

    ipcMain.on('print-prepayment-request', function(event, data) {
        dialog.showSaveDialog(win, {defaultPath: data.orderNumber + '-elolegbekero.pdf', title: 'PDF helye', filters: [{name: 'PDF document', extensions: ['pdf']}]}).then(function(result) {
            if (result.canceled) {
                return;
            }
           
            updatePrepaymentRequestIndex(data.prepaymentIndex);
            
            win.webContents.printToPDF({printBackground: true, landscape: false}).then(function(data) {
                fs.writeFile(result.filePath, data, function (error) {
                    shell.openExternal(result.filePath);
                });
            });    
        });
    });

    ipcMain.on('open-payment-request-data-page', function(event, data) {
        win.setMenu(defaultWindowMenuBar);
        win.loadURL(path.join(appPath, '/pages/PaymentRequest.html?orderNumber=' + data.order));
    });

    ipcMain.on('print-payment-request', function(event, data) {
        dialog.showSaveDialog(win, {defaultPath: data.orderNumber + '-dijbekero.pdf', title: 'PDF helye', filters: [{name: 'PDF document', extensions: ['pdf']}]}).then(function(result) {
            if (result.canceled) {
                return;
            }
           
            updatePaymentRequestIndex(data.paymentIndex);
            
            win.webContents.printToPDF({printBackground: true, landscape: false}).then(function(data) {
                fs.writeFile(result.filePath, data, function (error) {
                    shell.openExternal(result.filePath);
                });
            });    
        });
    });

    ipcMain.on('print-part-list', function(event, data) {
        dialog.showSaveDialog(win, {defaultPath: data, title: 'PDF helye', filters: [{name: 'PDF document', extensions: ['pdf']}]}).then(function(result) {
            if (result.canceled) {
                return;
            }
           
            win.webContents.printToPDF({printBackground: true, landscape: false}).then(function(data) {
                fs.writeFile(result.filePath, data, function (error) {
                    shell.openExternal(result.filePath);
                });
            });
        });
    });

    ipcMain.on('print-glass-list', function(event, data) {
        dialog.showSaveDialog(win, {defaultPath: data, title: 'PDF helye', filters: [{name: 'PDF document', extensions: ['pdf']}]}).then(function(result) {
            if (result.canceled) {
                return;
            }
           
            win.webContents.printToPDF({printBackground: true, landscape: false}).then(function(data) {
                fs.writeFile(result.filePath, data, function (error) {
                    shell.openExternal(result.filePath);
                });
            });
        });
    });

    ipcMain.on('export-glass-list', function(event, data) {
        exportGlassList(data);
    });

    ipcMain.on('print-fitting-list', function(event, data) {
        dialog.showSaveDialog(win, {defaultPath: data, title: 'PDF helye', filters: [{name: 'PDF document', extensions: ['pdf']}]}).then(function(result) {
            if (result.canceled) {
                return;
            }
           
            win.webContents.printToPDF({printBackground: true, landscape: false}).then(function(data) {
                fs.writeFile(result.filePath, data, function (error) {
                    shell.openExternal(result.filePath);
                });
            });
        });
    });

    ipcMain.on('print-cutting-list', function(event, data) {
        
        dialog.showSaveDialog(win, {defaultPath: data, title: 'PDF helye', filters: [{name: 'PDF document', extensions: ['pdf']}]}).then(function(result) {
            if (result.canceled) {
                return;
            }
           
            win.webContents.printToPDF({printBackground: true, landscape: false}).then(function(data) {
                fs.writeFile(result.filePath, data, function (error) {
                    shell.openExternal(result.filePath);
                });
            });
        });
    });

    ipcMain.on('print-order', function(event, data) {
        var printData = {};
        printData.doorwindows = [];
        printData.priceSettings = loadPriceSettings();
        
        // load doorwindows
        var files = fs.readdirSync(path.join(basePath, '/data/save/'));
        for (var i=0; i < files.length; i++) {
            var doorwindow = {};
            doorwindow.orderNumber = files[i].split("_")[0];
            doorwindow.doorWindowName = files[i].split("_")[1].split('.we')[0];
            
            if (doorwindow.orderNumber == data.orderNumber) {
                doorwindow.string = fs.readFileSync(path.join(basePath, '/data/save', files[i]), 'utf-8');
                printData.doorwindows.push(doorwindow);
            }
        }

        printData.doorwindows.sort(function(a, b) {
            if(parseInt(a.orderNumber) < parseInt(b.orderNumber)) { return -1; }
            if(parseInt(a.orderNumber) > parseInt(b.orderNumber)) { return 1; }
            if(parseInt(a.doorWindowName) < parseInt(b.doorWindowName)) { return -1; }
            if(parseInt(a.doorWindowName) > parseInt(b.doorWindowName)) { return 1; }
            return 0;
        });

        // load customer
        printData.customer = data.customer;
        printData.orderNumber = data.orderNumber;
        printData.orderAddress = data.orderAddress;
        printData.orderEmail = data.orderEmail;
        printData.orderPhone = data.orderPhone;
        printData.orderDate = data.orderDate;
        printData.orderFinishDate = data.orderFinishDate;
        printData.orderComment = data.orderComment;
        printData.orderTaxNumber = data.orderTaxNumber;
        printData.orderCommissionFee = data.orderCommissionFee;
        printData.orderInstallationFee = data.orderInstallationFee;
        
        PrintDoorwindowWindow.send(data.printType, printData);
//PrintDoorwindowWindow.show();
//PrintDoorwindowWindow.openDevTools();
//return;

        var fileName = printData.orderNumber + '-arajanlat.pdf';
        if (data.printType == 'print-doorwindow-parts') {
            fileName = printData.orderNumber + '-alkatreszlista.pdf';
        }

        if (data.printType == 'print-production-page') {
            fileName = printData.orderNumber + '-gyartasi-lap.pdf';
        }

        if (data.printType == 'print-order-confirmation') {
            fileName = printData.orderNumber + '-visszaigazolas.pdf';
        }

        dialog.showSaveDialog(win, {defaultPath: fileName, title: 'PDF helye', filters: [{name: 'PDF document', extensions: ['pdf']}]}).then(function(result) {
            if (result.canceled) {
                return;
            }
           
            PrintDoorwindowWindow.webContents.printToPDF({printBackground: true, landscape: false}).then(function(data) {
                fs.writeFile(result.filePath, data, function (error) {
                    shell.openExternal(result.filePath);
                });
            });    
        });
    });

    ipcMain.on('load-price-settings', function(event, data) {
        var priceSettings = loadPriceSettings();
        event.returnValue = priceSettings;
    });

    ipcMain.on('load-handle-positions', function(event, data) {
        var handlePositions = loadHandlePositions();
        event.returnValue = handlePositions;
    });

    // END OF IPC EVENTS

    // START OF MAIN PROCESS FUNCTIONS
    function logText(text) {
        var currentTime = new Date() - startTime;
        var timeText = parseInt(currentTime / 1000) + ':' + parseInt((currentTime % 1000) / 100) + ' - ';
        fs.appendFileSync(basePath + '/log.txt', timeText + text + "\r\n");
    }

    function updateSaveFiles() {
        win.webContents.send('update-save-files');
    }

    function autoPositionDividers() {
        win.webContents.send('auto-position-dividers');
    }

    function autoPositionDividersByDividerDistance() {
        win.webContents.send('auto-position-dividers-by-divider-distance');
    }

    function autoPositionWingDividers() {
        win.webContents.send('auto-position-wing-dividers');
    }

    function printOrderDoorwindowParts() {
        win.webContents.send('print-order-parts');
    }

    function printOffer() {
        win.webContents.send('print-offer');
    }

    function printOrderConfirmation() {
        win.webContents.send('print-order-confirmation');
    }

    function printProductionPage() {
        win.webContents.send('print-production-page');
    }

    function printPrepaymentRequest() {
        win.webContents.send('open-prepayment-request-data-page');
    }

    function printPaymentRequest() {
        win.webContents.send('open-payment-request-data-page');
    }
    
    function showPriceSettingsWindow() {
        win.loadURL(path.join(appPath, '/pages/PriceSettings.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showCommissionFeeSettingsWindow() {
        win.loadURL(path.join(appPath, '/pages/CommissionFeeSettings.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showFittingSettingsWindow() {
        win.loadURL(path.join(appPath, '/pages/FittingSettings.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showWorkFeeSettingsWindow() {
        win.loadURL(path.join(appPath, '/pages/WorkFeeSettings.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showProfitSettingsWindow() {
        win.loadURL(path.join(appPath, '/pages/ProfitSettings.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showOfferTextSettingsWindow() {
        win.loadURL(path.join(appPath, '/pages/OfferTextSettings.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showPartListWindow() {
        win.loadURL(path.join(appPath, '/pages/PartList.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showCalendarWindow() {
        win.loadURL(path.join(appPath, '/pages/Calendar.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showGlassListWindow() {
        win.loadURL(path.join(appPath, '/pages/GlassList.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showProfileCuttingListWindow() {
        win.loadURL(path.join(appPath, '/pages/ProfileCuttingList.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showMetalRodCuttingListWindow() {
        win.loadURL(path.join(appPath, '/pages/MetalRodCuttingList.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showFittingListWindow() {
        win.loadURL(path.join(appPath, '/pages/FittingList.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showFittingListTestWindow() {
        win.loadURL(path.join(appPath, '/pages/FittingListTest.html'));
        win.setMenu(defaultWindowMenuBar);
    }

    function showOrderGlassSettingsWindow() {
        OrderGlassSettingsWindow.show();
    }

    function exportGlassList(data) {
        dialog.showSaveDialog(win, {defaultPath: data.fileName, title: 'XLSX helye', filters: [{name: 'XLSX Document', extensions: ['xlsx']}]}).then(function(result) {
            if (result.canceled) {
                return;
            }

            var workbook = excel.utils.book_new();
            var worksheet = excel.utils.aoa_to_sheet(data.glasses);
            excel.utils.book_append_sheet(workbook, worksheet, 'teszt');
            worksheet['!cols'] = [
                {wch: 7},
                {wch: 7},
                {wch: 12},
                {wch: 10},
            ];

            excel.writeFile(workbook, result.filePath);
        });
    }

    function loadHandlePositions() {
        var handlePositions = [];

        // load price settings
        var lines = fs.readFileSync(basePath + '/data/handle-positions.txt', 'utf-8').split("\r\n");
        for (var i = 0; i < lines.length; i ++) {
            var data = lines[i].split('|');
            var handlePosition = {};
            handlePosition.minHeight = parseInt(data[0])
            handlePosition.maxHeight = parseInt(data[1])
            handlePosition.position = parseInt(data[2])

            handlePositions.push(handlePosition);
        }
        
        return handlePositions;
    }
    
    function loadPriceSettings() {
        var priceSettings = [];

        // load price settings
        var lines = fs.readFileSync(basePath + '/data/prices.txt', 'utf-8').split("\r\n");
        for (var i = 0; i < lines.length; i ++) {
            var priceSetting = {};
            priceSetting.name = lines[i].split('|')[0];
            priceSetting.price = parseInt(lines[i].split('|')[1]);

            priceSettings.push(priceSetting);
        }

        return priceSettings;
    }

    function loadOrders() {
        var orders = [];
        var lines = fs.readFileSync(basePath + '/data/orders.txt', 'utf-8').split("\r\n");
        for (var i = 0; i < lines.length; i++) {
            var data = lines[i].split('|');
            
            if (data.length < 2) {
                continue;
            }

            var order = {
                number: data[0],
                customer: data[1],
                status: data[2],
                date: data[3],
                finishDate: data[4],
                email: data[5],
                phone: data[6],
                address: '',
                comment: '',
                taxNumber: '',
                commissionFee: '',
                installationFeeType: '',
                installationFee: 0,
            };

            if (data.length > 7) {
                order.address = data[7];
            }

            if (data.length > 8) {
                order.comment = data[8];
            }

            if (data.length > 9) {
                order.taxNumber = data[9];
            }

            if (data.length > 10) {
                order.commissionFee = data[10];
            }

            if (data.length > 11) {
                order.installationFee = parseInt(data[11]);
            }

            if (data.length > 12) {
                order.installationFeeType = data[12];
            }

            orders.push(order);
        }

        return orders;
    }

    function updateOrder(order) {
        var orders = loadOrders();

        for (var i = 0; i < orders.length; i++) {
            if (orders[i].number == order.number) {
                orders[i].customer = order.customer;
                orders[i].address = order.address;
                orders[i].status = order.status;
                orders[i].phone = order.phone;
                orders[i].email = order.email;
                orders[i].date = order.date;
                orders[i].finishDate = order.finishDate;
                orders[i].comment = order.comment;
                orders[i].taxNumber = order.taxNumber;
                orders[i].commissionFee = order.commissionFee;
                orders[i].installationFeeType = order.installationFeeType;
                orders[i].installationFee = order.installationFee;
            }
        }

        saveOrders(orders);
    }

    function saveOrders(orders) {
        var ordersString = '';
        for (var i = 0; i < orders.length; i++) {
            if (i !== 0) {
                ordersString += "\r\n";
            }

            ordersString += orders[i].number + '|' + orders[i].customer + '|' + orders[i].status + '|' + orders[i].date +
            '|' + orders[i].finishDate + '|' + orders[i].email + '|' + orders[i].phone + '|' + orders[i].address + '|' + orders[i].comment +
            '|' + orders[i].taxNumber + '|' + orders[i].commissionFee + '|' + orders[i].installationFee + '|' + orders[i].installationFeeType;
        }

        fs.writeFileSync(basePath + '/data/orders.txt', ordersString);
    }

    function updatePrepaymentRequestIndex(newIndex) {
        var currentIndex = parseInt(fs.readFileSync(basePath + '/data/prepayment-index.txt', 'utf-8'));
        if (newIndex == currentIndex) {
            currentIndex ++;
        }

        fs.writeFileSync(basePath + '/data/prepayment-index.txt', currentIndex);
    }

    function updatePaymentRequestIndex(newIndex) {
        var currentIndex = parseInt(fs.readFileSync(basePath + '/data/payment-index.txt', 'utf-8'));
        if (newIndex == currentIndex) {
            currentIndex ++;
        }

        fs.writeFileSync(basePath + '/data/payment-index.txt', currentIndex);
    }

    function loadFittingsListFromExcel(fileName) {
        var fittingsList = [];
        
        var workbook = excel.readFile(fileName);
        var sheetNameList = workbook.SheetNames;
        var list = excel.utils.sheet_to_json(workbook.Sheets[sheetNameList[0]],);

        for (var i=0; i < list.length; i++) {
            var fitting = {};

            fitting.minWidth = -1;
            fitting.maxWidth = -1;
            fitting.minHeight = -1;
            fitting.maxHeight = -1;
            fitting.openingMode = '';
            fitting.openingSide = '';
            fitting.fittingType = '';
            fitting.handleType = '';
            fitting.wingFrame = '';
            fitting.hingeType = '';
            fitting.quantity = 1;
            fitting.code = '';
            fitting.shortName = '';
            fitting.longName = '';
            fitting.price = 0;
            fitting.frame = '';
            fitting.display = 0;

            if (list[i]['min. szélesség'] !== undefined) {
                fitting.minWidth = list[i]['min. szélesség'];
            }

            if (list[i]['max. szélesség'] !== undefined) {
                fitting.maxWidth = list[i]['max. szélesség'];
            }

            if (list[i]['min. magasság'] !== undefined) {
                fitting.minHeight = list[i]['min. magasság'];
            }

            if (list[i]['max. magasság'] !== undefined) {
                fitting.maxHeight = list[i]['max. magasság'];
            }

            if (list[i]['nyitásmód'] !== undefined) {
                fitting.openingMode = list[i]['nyitásmód'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['nyitásirány'] !== undefined) {
                fitting.openingSide = list[i]['nyitásirány'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['nyílászáró vasalat'] !== undefined) {
                fitting.fittingType = list[i]['nyílászáró vasalat'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['nyílászáró kilincs'] !== undefined) {
                fitting.handleType = list[i]['nyílászáró kilincs'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['szárny tipus'] !== undefined) {
                fitting.wingFrame = list[i]['szárny tipus'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['nyílászáró pánt'] !== undefined) {
                fitting.hingeType = list[i]['nyílászáró pánt'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['vasalat cikkszám'] !== undefined) {
                fitting.code = (list[i]['vasalat cikkszám'] + '').split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['rövid vasalatnév'] !== undefined) {
                fitting.shortName = list[i]['rövid vasalatnév'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['hosszú vasalatnév'] !== undefined) {
                fitting.longName = list[i]['hosszú vasalatnév'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['vasalat egységár (nettó)'] !== undefined) {
                fitting.price = list[i]['vasalat egységár (nettó)'];
            }

            if (list[i]['vasalat darabszám'] !== undefined) {
                fitting.quantity = list[i]['vasalat darabszám'];
            }

            if (list[i]['nyílászáró tok'] !== undefined) {
                fitting.frame = list[i]['nyílászáró tok'];
            }

            if (list[i]['megjelenítés'] !== undefined) {
                fitting.display = 1;
            }

            fittingsList.push(fitting);
        }

        return fittingsList;
    }

    function saveFittings(fittingsList) {
        var fittingsString = '';
        
        for (var i = 0; i < fittingsList.length; i++) {
            fittingsString += fittingsList[i].minWidth + '|';
            fittingsString += fittingsList[i].maxWidth + '|';
            fittingsString += fittingsList[i].minHeight + '|';
            fittingsString += fittingsList[i].maxHeight + '|';
            fittingsString += fittingsList[i].openingMode + '|';
            fittingsString += fittingsList[i].openingSide + '|';
            fittingsString += fittingsList[i].quantity + '|';
            fittingsString += fittingsList[i].code + '|';
            fittingsString += fittingsList[i].shortName + '|';
            fittingsString += fittingsList[i].longName + '|';
            fittingsString += fittingsList[i].price + '|';
            fittingsString += fittingsList[i].frame + '|';
            fittingsString += fittingsList[i].fittingType + '|';
            fittingsString += fittingsList[i].handleType + '|';
            fittingsString += fittingsList[i].wingFrame + '|';
            fittingsString += fittingsList[i].hingeType + '|';
            fittingsString += fittingsList[i].display;


            if (i !== fittingsList.length - 1) {
                fittingsString += "\r\n";
            }
        }

        fs.writeFileSync(basePath + '/data/fittings.txt', fittingsString);
    }

    function loadFittings() {
        var fittingsList = [];
        var fittingsFile = fs.readFileSync(basePath + '/data/fittings.txt', 'utf-8').split("\r\n");
        
        for (var i = 0; i < fittingsFile.length; i++) {
            var data = fittingsFile[i].split('|');
            
            // skip empty rows
            if (data.length == 1) {
                continue;
            }

            var fitting = {};

            fitting.minWidth = parseInt(data[0]);
            fitting.maxWidth = parseInt(data[1]);
            fitting.minHeight = parseInt(data[2]);
            fitting.maxHeight = parseInt(data[3]);
            fitting.openingMode = data[4];
            fitting.openingSide = data[5];
            fitting.quantity = parseInt(data[6]);
            fitting.code = data[7];
            fitting.shortName = data[8];
            fitting.longName = data[9];
            fitting.price = parseInt(data[10]);
            fitting.frame = '';
            fitting.fittingType = '';
            fitting.handleType = '';
            fitting.wingFrame = '';
            fitting.hingeType = '';
            fitting.display = 0;
            
            if (data.length > 11) {
                fitting.frame = data[11];
            }

            if (data.length > 12) {
                fitting.fittingType = data[12];
            }

            if (data.length > 13) {
                fitting.handleType = data[13];
            }

            if (data.length > 14) {
                fitting.wingFrame = data[14];
            }

            if (data.length > 15) {
                fitting.hingeType = data[15];
            }

            if (data.length > 16) {
                fitting.display = parseInt(data[16]);
            }

            fittingsList.push(fitting);
        }

        return fittingsList;
    }

    function loadWorkFees() {
        var workFeesList = [];
        var workFeesFile = fs.readFileSync(basePath + '/data/work-fees.txt', 'utf-8').split("\r\n");
        
        for (var i = 0; i < workFeesFile.length; i++) {
            var data = workFeesFile[i].split('|');
            
            // skip empty rows
            if (data.length == 1) {
                continue;
            }

            var workFee = {};

            workFee.fittings = data[0];
            workFee.wingFrame = data[1];
            workFee.openingMode = data[2];
            workFee.price = parseInt(data[3]);

            workFeesList.push(workFee);
        }

        return workFeesList;
    }

    function loadProfits() {
        var profitsList = [];
        var profitsFile = fs.readFileSync(basePath + '/data/profits.txt', 'utf-8').split("\r\n");
        
        for (var i = 0; i < profitsFile.length; i++) {
            var data = profitsFile[i].split('|');
            
            // skip empty rows
            if (data.length == 1) {
                continue;
            }

            var profit = {};

            profit.fittings = data[0];
            profit.wingFrame = data[1];
            profit.openingMode = data[2];
            profit.price = parseInt(data[3]);

            profitsList.push(profit);
        }

        return profitsList;
    }

    function loadWorkFeesFromExcel(fileName) {
        var workFeesList = [];
        
        var workbook = excel.readFile(fileName);
        var sheetNameList = workbook.SheetNames;
        var list = excel.utils.sheet_to_json(workbook.Sheets[sheetNameList[0]]);

        for (var i=0; i < list.length; i++) {
            var workFee = {};

            workFee.fittings = '';
            workFee.wingFrame = '';
            workFee.openingMode = '';
            workFee.price = 0;


            if (list[i]['vasalat'] !== undefined) {
                workFee.fittings = list[i]['vasalat'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['szárny profil'] !== undefined) {
                workFee.wingFrame = list[i]['szárny profil'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['nyitásmód'] !== undefined) {
                workFee.openingMode = list[i]['nyitásmód'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['összeg'] !== undefined) {
                workFee.price = list[i]['összeg'];
            }

            workFeesList.push(workFee);
        }

        return workFeesList;
    }

    function loadProfitsFromExcel(fileName) {
        var profitsList = [];
        
        var workbook = excel.readFile(fileName);
        var sheetNameList = workbook.SheetNames;
        var list = excel.utils.sheet_to_json(workbook.Sheets[sheetNameList[0]]);

        for (var i=0; i < list.length; i++) {
            var profit = {};

            profit.fittings = '';
            profit.wingFrame = '';
            profit.openingMode = '';
            profit.price = 0;


            if (list[i]['vasalat'] !== undefined) {
                profit.fittings = list[i]['vasalat'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['szárny profil'] !== undefined) {
                profit.wingFrame = list[i]['szárny profil'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['nyitásmód'] !== undefined) {
                profit.openingMode = list[i]['nyitásmód'].split("\r\n").join('<br>').split("\n").join('<br>').split('|').join(' ');
            }

            if (list[i]['összeg'] !== undefined) {
                profit.price = list[i]['összeg'];
            }

            profitsList.push(profit);
        }

        return profitsList;
    }
    
    function saveWorkFees(workFeesList) {
        var workFeesString = '';
        
        for (var i = 0; i < workFeesList.length; i++) {
            workFeesString += workFeesList[i].fittings + '|';
            workFeesString += workFeesList[i].wingFrame + '|';
            workFeesString += workFeesList[i].openingMode + '|';
            workFeesString += workFeesList[i].price;

            if (i !== workFeesList.length - 1) {
                workFeesString += "\r\n";
            }
        }

        fs.writeFileSync(basePath + '/data/work-fees.txt', workFeesString);
    }

    function saveProfits(profitsList) {
        var profitsString = '';
        
        for (var i = 0; i < profitsList.length; i++) {
            profitsString += profitsList[i].fittings + '|';
            profitsString += profitsList[i].wingFrame + '|';
            profitsString += profitsList[i].openingMode + '|';
            profitsString += profitsList[i].price;

            if (i !== profitsList.length - 1) {
                profitsString += "\r\n";
            }
        }

        fs.writeFileSync(basePath + '/data/profits.txt', profitsString);
    }

    function loadAdditionalParts() {
        var additionalPartsList = [];
        var additionalPartsFile = fs.readFileSync(basePath + '/data/additional-parts.txt', 'utf-8').split("\r\n");
        
        for (var i = 0; i < additionalPartsFile.length; i++) {
            var data = additionalPartsFile[i].split('|');
            
            // skip empty rows
            if (data.length == 1) {
                continue;
            }

            var additionalPart = {};

            additionalPart.type = data[0];
            if (additionalPart.type == 'kiegészítő') {
                additionalPart.name = data[1];
                additionalPart.hasSize = parseInt(data[2]);
                additionalPart.defaultSize = parseInt(data[3]);
            }

            if (additionalPart.type == 'szúnyogháló') {
                additionalPart.hasSize = parseInt(data[1]);
                additionalPart.name = data[2];
            }
            
            if (additionalPart.type == 'redőny') {
                additionalPart.hasSize = parseInt(data[1]);
                additionalPart.name = data[2];
            }

            if (additionalPart.type == 'párkány') {
                additionalPart.name = data[1];
            }

            additionalPartsList.push(additionalPart);
        }

        return additionalPartsList;
    }

    function loadCommissionFees() {
        var commissionFees = [];
        var lodadedCommissionFees = fs.readFileSync(basePath + '/data/commission-fees.txt', 'utf-8').split("\r\n");

        for (var i = 0; i < lodadedCommissionFees.length; i++) {
            if (lodadedCommissionFees[i] == '') {
                continue;
            }

            var data = lodadedCommissionFees[i].split('|');

            var commissionFee = {};
            commissionFee.name = data[0];
            commissionFee.percentage = parseInt(data[1]);
            commissionFee.visible = parseInt(data[2]);

            commissionFees.push(commissionFee);
        }

        return commissionFees;
    }

    function saveCommissionFees(commissionFees) {
        var commissionFeesString = '';
        for (var i = 0; i < commissionFees.length; i++) {
            if (i !== 0) {
                commissionFeesString += "\r\n";
            }

            commissionFeesString += commissionFees[i].name + '|' + commissionFees[i].percentage + '|' + commissionFees[i].visible;
        }

        fs.writeFileSync(basePath + '/data/commission-fees.txt', commissionFeesString);
    }

    function loadOrdersPageStates() {
        var ordersPageStates = {};
        var data = fs.readFileSync(basePath + '/data/orders-page-states.txt', 'utf-8').split("\r\n");

        ordersPageStates.offers = parseInt(data[0]);
        ordersPageStates.orderedOffers = parseInt(data[1]);
        ordersPageStates.completedOrders = parseInt(data[2]);
        ordersPageStates.selectedOrder = data[3];
        ordersPageStates.selectedDoorWindow = data[4];

        return ordersPageStates;
    }

    function saveOrdersPageStates(ordersPageStates) {
        var ordersPageString = '';
        ordersPageString += (ordersPageStates.offers ? 1 : 0) + "\r\n";
        ordersPageString += (ordersPageStates.orderedOffers ? 1 : 0) + "\r\n";
        ordersPageString += (ordersPageStates.completedOrders ? 1 : 0) + "\r\n";
        ordersPageString += ordersPageStates.selectedOrder + "\r\n";
        ordersPageString += ordersPageStates.selectedDoorWindow;

        fs.writeFileSync(basePath + '/data/orders-page-states.txt', ordersPageString);
    }

    function loadToolPagesStates() {
        var toolPagesStates = {};
        var data = fs.readFileSync(basePath + '/data/tool-pages-states.txt', 'utf-8').split("\r\n");

        toolPagesStates.partsList = {};
        toolPagesStates.partsList.offer = parseInt(data[0]);
        toolPagesStates.partsList.ordered = parseInt(data[1]);
        toolPagesStates.partsList.finished = parseInt(data[2]);

        toolPagesStates.glassList = {};
        toolPagesStates.glassList.offer = parseInt(data[3]);
        toolPagesStates.glassList.ordered = parseInt(data[4]);
        toolPagesStates.glassList.finished = parseInt(data[5]);

        toolPagesStates.cuttingList = {};
        toolPagesStates.cuttingList.offer = parseInt(data[6]);
        toolPagesStates.cuttingList.ordered = parseInt(data[7]);
        toolPagesStates.cuttingList.finished = parseInt(data[8]);

        toolPagesStates.fittingList = {};
        toolPagesStates.fittingList.offer = parseInt(data[9]);
        toolPagesStates.fittingList.ordered = parseInt(data[10]);
        toolPagesStates.fittingList.finished = parseInt(data[11]);

        return toolPagesStates;
    }

    function saveToolPagesStates(toolPagesStates) {
        var toolPagesString = '';

        toolPagesString += toolPagesStates.partsList.offer + "\r\n";
        toolPagesString += toolPagesStates.partsList.ordered + "\r\n";
        toolPagesString += toolPagesStates.partsList.finished + "\r\n";

        toolPagesString += toolPagesStates.glassList.offer + "\r\n";
        toolPagesString += toolPagesStates.glassList.ordered + "\r\n";
        toolPagesString += toolPagesStates.glassList.finished + "\r\n";

        toolPagesString += toolPagesStates.cuttingList.offer + "\r\n";
        toolPagesString += toolPagesStates.cuttingList.ordered + "\r\n";
        toolPagesString += toolPagesStates.cuttingList.finished + "\r\n";

        toolPagesString += toolPagesStates.fittingList.offer + "\r\n";
        toolPagesString += toolPagesStates.fittingList.ordered + "\r\n";
        toolPagesString += toolPagesStates.fittingList.finished;

        fs.writeFileSync(basePath + '/data/tool-pages-states.txt', toolPagesString);
    }
    // END OF MAIN PROCESS FUNCTIONS
});